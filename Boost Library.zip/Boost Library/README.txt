The Boost Graph Library (BGL) 

README Contents
1. The BGL Book (PDF)
2. Supported C++ Compilers
3. Installation
  a. For Microsoft Visual C++ (Windows)
  b. For All Unix-like systems (including MacOS X)
  c. For MacOS 9
4. Bugs, Feature Requests, Contributions
5. License


1. The BGL Book (PDF)

The electronic PDF version of the book (bgl-book.pdf) is fully
hyper-linked, making it a convenient on-line reference.


2. Supported C++ Compilers

We strive to write the Boost Graph Library in Standard C++ (ISO/IEC
14882). Therefore, theoretically, the BGL will compile with any
standards conformant compiler. However, as many compilers are not
standards conforming, we also avoid some unsupported language
constructs and compiler bugs. In general, we apply workarounds when
they do not greatly affect the design of the library. The design of
the BGL uses modern generic programming techniques, which tend to use
newer C++ language features that are less stable on various
compilers. We have spent considerable effort to make sure that the BGL
still compiles on a broad range of C++ compilers despite the modern
design. The C++ compiler vendors have made significant progress
towards standards conformance in the last few years, and we believe
this progress will continue.

The Boost Graph Library has been tested with the following
compilers. We typically test with the latest version of each compiler
(and not with older versions). As new versions of these compilers come
out the BGL will be tested with the newer versions.

 * Visual C++ 6.0 service pack 5
 * Gnu C++ 2.95.2 and 3.02
 * Kuck and Associates C++ 4.0f
 * Comeau C++ 4.2.4.5
 * Metrowerks CodeWarrior 6.0 and 7.0
 * Intel C++ 5.0.1
 * Compaq C++ 6.3
 * SGI MIPSpro 7.3.1.2m


3. Installation

Since the Boost Graph Library is a template library, the vast majority
of the BGL resides in header files (the same is true for many of the
other Boost libraries). This means that you do not need to build and
link in a binary library for your programs to use the BGL. You simply
need to #include the proper files in your program, and set the include
path for your compiler. The following installation instructions mainly
consist of copying the boost headers to a directory on your machine.

There is a useful tool for drawing pictures of graphs called Graphviz
(http://www.graphviz.org). This tool uses a particular file format for
graph input called a dot file. The BGL includes facilities for reading
a dot file to create a BGL graph and for writing a BGL graph to a dot
file. These facilities are provided in a binary library (not just
header files). We provide a pre-built library for Microsoft Windows,
and the instructions for building on UNIX are below.

If you are currently using the LEDA
(http://www.algorithmic-solutions.com/as_html/products/products.html)
or Stanford GraphBase (SGB)
(http://www-cs-faculty.stanford.edu/~knuth/sgb.html), you will be
pleased to find BGL interface components that make it possible to use
LEDA and SGB graphs in BGL algorithms. Of course, to use these BGL
interfacing components, you need to have LEDA and/or SGB installed.


a. For Microsoft Visual C++ (Windows)

Run the Setup.exe program on this CD and follow the instructions. By
default, this will create the directory C:\BGL\ and install into it
the contents of this CD. This includes the source code and
documentation for all of the boost libraries (in
C:\BGL\boost_1_25_1\), the PDF version of the BGL book
(C:\BGL\bgl-book.pdf), and a Visual C++ workspace (C:\BGL\VC++
Projects\AllExamples.dsw) for all of the example programs. To compile
and run the examples, simply open the AllExamples.dsw workspace.

To use BGL from an existing or new Visual C++ project, take the
following steps.

1. Add Boost to the include path for your Visual C++ project. Via the
menu Tools -> Options -> Directories, add C:\BGL\boost_1_15_1 to the
list of include file directories.

2. Compile/Link Flag suggestions: Via the menu Project -> Settings, we
suggest setting the flags /Zm400 to increase the memory allocation
limit and /GX to enable exception handling. We also suggest setting /Ob1
to enable inlining.  Do not use /Gm (minimal
rebuild) as this often is the reason for internal compiler
errors. Also, sometimes using the DLL version of the C++ runtime
system can cause problems.

3. (optional) Add the Graphviz dot-file reader Library. Via the
menu Project -> Settings -> Link, add bglviz.lib (or bglvizdebug.lib
for the debug version) to the project options box. Then go to Tools ->
Options -> Directories and add C:\BGL\Lib to the list of library file
directories.


b. For All Unix-like systems

Copy the boost_1_25_1.tar.gz archive file to a location of your
choosing on your computer and gunzip then untar the archive. You can
then start using the BGL immediately in your programs by #include'ing
the appropriate BGL headers files and adding boost_1_25_1 to your
compiler's include path. If you are using Gnu C++ we recommend using
the flags -ftemplate-depth-100 and -Wno-long-long.

The source file for the BGL examples is in the
boost_1_25_1/libs/graph/example directory. To compile all of the
examples, please do the following.

set CXX to be your compiler command. For example(in tcsh shell):
setenv CXX "g++ -ftemplate-depth-100 -Wno-long-long"
or (in bash shell):
export CXX="g++ -ftemplate-depth-100 -Wno-long-long"

Some of the examples use the Graphviz file reader functions, so
you will need to first build the libbglviz.a library.

cd boost_1_25_/libs/graph/src
$CXX -I../../../ -I. -c *.cpp
ar -rc libbglviz.a *.o
ranlib libbglviz.a 

Note that for some compilers, the process to build libraries is
slightly different. You should follow your compiler manual. For example,
to use Kuck and Associates C++ compiler to build the library:
KCC +K0 --one_instantiation_per_object -I../../../ -I. -c *.cpp
KCC +K0 --one_instantiation_per_object -o libbglviz.a *.o

This will create the library libbglviz.a which you can then link into
your program. Note that you can use Graphviz dot file write facilities
without the library.

To compile a specific example, do the following:
cd boost_1_25_1/libs/graph/example
$CXX -I../../../ accum-compile-times.cpp -o accum-compile-times

Some of the examples require the Graphviz dot file read library. For example:
$CXX -I../../../ reachable-loop-head.cpp -o reachable-loop-head \
       -L../src -lbglviz 


c. For MacOS 9

Copy over the boost_1_25_1.tgz file to your computer and then
uncompress it (using Stuffit Expander for example).

You can then start using the Boost Graph Library by adding
the copied boost_1_25_1 directory to the include path
for you compiler and #include'ing the appropriate
BGL header files.

The source files for the examples are in the directory
boost_1_25_1/libs/graph/example. We have not created
Metroworks projects, so if you wish to compile the examples you will
need to create your own project. In addition, some of the examples use
the Graphviz read/write functions. The source code for these functions
is in the boost_1_25_1/libs/graph/src directory.

4. Boost Software and Documentation Updates

The latest release of the Boost libraries (including the Boost
Graph Library) can be obtained at the Boost Web site:

http://www.boost.org/more/download.html


5. Bugs, Feature Requests, Contributions

There is a Tracker (http://sourceforge.net/tracker/?group_id=7586) at
Sourceforge for reporting bugs and requesting features. Boost is a
volunteer organization, so there are no guarantees on when
bugs/features will be addressed.  However, due to the large number of
highly experienced volunteers, bugs tend to be address quickly, and
new features are often considered. Additionally, we highly encourage
users to get involved by contributing to the Boost libraries
(http://www.boost.org). The Boost Graph Library has already benefitted
greatly from contributions. In addition, there is a web page that
lists There is also a trouble shooting page that describes some common
problems and workarounds.  Also there are several Boost mailing lists
(http://www.boost.org/more/mailing_lists.htm). There is a Boost users
list, a developers list, and an announcement list.


6. License

See the LICENSE.txt file.
