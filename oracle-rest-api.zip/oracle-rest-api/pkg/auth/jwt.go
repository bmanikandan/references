// Package auth provides JWT-based authentication utilities for OAuth 2.0 Bearer token validation.
package auth

import (
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/golang-jwt/jwt/v5"
)

// Sentinel errors for JWT operations.
var (
	ErrTokenExpired          = errors.New("token has expired")
	ErrInvalidToken          = errors.New("invalid token")
	ErrInvalidSigningMethod  = errors.New("invalid signing method")
	ErrEmptyAuthHeader       = errors.New("authorization header is required")
	ErrInvalidAuthHeaderFmt  = errors.New("authorization header must be in the format: Bearer <token>")
	ErrEmptyBearerToken      = errors.New("bearer token must not be empty")
)

// Claims represents JWT claims with OAuth 2.0 scope support.
type Claims struct {
	Subject  string   `json:"sub"`
	ClientID string   `json:"client_id,omitempty"`
	Scopes   []string `json:"scopes,omitempty"`
	jwt.RegisteredClaims
}

// JWTService defines the interface for JWT operations.
type JWTService interface {
	GenerateToken(subject, clientID string, scopes []string, expiry time.Duration) (string, error)
	ValidateToken(tokenString string) (*Claims, error)
}

type jwtService struct {
	secretKey []byte
	issuer    string
}

// NewJWTService creates a new JWT service with the provided secret key and issuer.
func NewJWTService(secretKey, issuer string) JWTService {
	return &jwtService{
		secretKey: []byte(secretKey),
		issuer:    issuer,
	}
}

// GenerateToken creates a signed JWT token with the given subject, clientID, scopes and expiry.
func (j *jwtService) GenerateToken(subject, clientID string, scopes []string, expiry time.Duration) (string, error) {
	now := time.Now().UTC()
	claims := &Claims{
		Subject:  subject,
		ClientID: clientID,
		Scopes:   scopes,
		RegisteredClaims: jwt.RegisteredClaims{
			Issuer:    j.issuer,
			Subject:   subject,
			IssuedAt:  jwt.NewNumericDate(now),
			ExpiresAt: jwt.NewNumericDate(now.Add(expiry)),
			NotBefore: jwt.NewNumericDate(now),
		},
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	signed, err := token.SignedString(j.secretKey)
	if err != nil {
		return "", fmt.Errorf("failed to sign token: %w", err)
	}
	return signed, nil
}

// ValidateToken parses and validates a JWT token string, returning the embedded claims.
func (j *jwtService) ValidateToken(tokenString string) (*Claims, error) {
	token, err := jwt.ParseWithClaims(tokenString, &Claims{}, func(token *jwt.Token) (interface{}, error) {
		if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, fmt.Errorf("%w: %v", ErrInvalidSigningMethod, token.Header["alg"])
		}
		return j.secretKey, nil
	})

	if err != nil {
		if errors.Is(err, jwt.ErrTokenExpired) {
			return nil, ErrTokenExpired
		}
		return nil, fmt.Errorf("%w: %v", ErrInvalidToken, err)
	}

	claims, ok := token.Claims.(*Claims)
	if !ok || !token.Valid {
		return nil, ErrInvalidToken
	}

	return claims, nil
}

// HasScope reports whether the given claims contain the required scope.
func HasScope(claims *Claims, requiredScope string) bool {
	for _, scope := range claims.Scopes {
		if scope == requiredScope {
			return true
		}
	}
	return false
}

// HasAllScopes reports whether the given claims contain all required scopes.
func HasAllScopes(claims *Claims, requiredScopes []string) bool {
	if len(requiredScopes) == 0 {
		return true
	}
	scopeSet := make(map[string]struct{}, len(claims.Scopes))
	for _, scope := range claims.Scopes {
		scopeSet[scope] = struct{}{}
	}
	for _, required := range requiredScopes {
		if _, ok := scopeSet[required]; !ok {
			return false
		}
	}
	return true
}

// ExtractBearerToken extracts and returns the token string from an Authorization header value.
// Expects the format: "Bearer <token>"
func ExtractBearerToken(authHeader string) (string, error) {
	if strings.TrimSpace(authHeader) == "" {
		return "", ErrEmptyAuthHeader
	}

	parts := strings.SplitN(authHeader, " ", 2)
	if len(parts) != 2 || !strings.EqualFold(parts[0], "Bearer") {
		return "", ErrInvalidAuthHeaderFmt
	}

	token := strings.TrimSpace(parts[1])
	if token == "" {
		return "", ErrEmptyBearerToken
	}

	return token, nil
}
