package auth_test

import (
	"strings"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"github.com/yourorg/oracle-rest-api/pkg/auth"
)

const (
	testSecretKey = "test-secret-key-that-is-long-enough-32c"
	testIssuer    = "test-issuer"
)

func newTestJWTService() auth.JWTService {
	return auth.NewJWTService(testSecretKey, testIssuer)
}

// ---------------------------------------------------------------------------
// GenerateToken
// ---------------------------------------------------------------------------

func TestJWTService_GenerateToken_Success(t *testing.T) {
	svc := newTestJWTService()
	token, err := svc.GenerateToken("user-1", "client-a", []string{"users:read"}, time.Hour)
	require.NoError(t, err)
	assert.NotEmpty(t, token)
	// JWT tokens have 3 dot-separated parts
	parts := strings.Split(token, ".")
	assert.Len(t, parts, 3)
}

func TestJWTService_GenerateToken_EmptyScopes(t *testing.T) {
	svc := newTestJWTService()
	token, err := svc.GenerateToken("user-1", "", []string{}, time.Hour)
	require.NoError(t, err)
	assert.NotEmpty(t, token)
}

func TestJWTService_GenerateToken_MultipleScopes(t *testing.T) {
	svc := newTestJWTService()
	scopes := []string{"users:read", "users:write", "users:delete"}
	token, err := svc.GenerateToken("admin", "admin-client", scopes, time.Hour)
	require.NoError(t, err)
	assert.NotEmpty(t, token)

	claims, err := svc.ValidateToken(token)
	require.NoError(t, err)
	assert.Equal(t, scopes, claims.Scopes)
}

// ---------------------------------------------------------------------------
// ValidateToken
// ---------------------------------------------------------------------------

func TestJWTService_ValidateToken_Success(t *testing.T) {
	svc := newTestJWTService()
	scopes := []string{"users:read", "users:write"}
	token, err := svc.GenerateToken("user-42", "my-client", scopes, time.Hour)
	require.NoError(t, err)

	claims, err := svc.ValidateToken(token)
	require.NoError(t, err)
	assert.Equal(t, "user-42", claims.Subject)
	assert.Equal(t, "my-client", claims.ClientID)
	assert.Equal(t, scopes, claims.Scopes)
	assert.Equal(t, testIssuer, claims.Issuer)
}

func TestJWTService_ValidateToken_Expired(t *testing.T) {
	svc := newTestJWTService()
	token, err := svc.GenerateToken("user-1", "", nil, -time.Second) // already expired
	require.NoError(t, err)

	_, err = svc.ValidateToken(token)
	assert.ErrorIs(t, err, auth.ErrTokenExpired)
}

func TestJWTService_ValidateToken_InvalidSignature(t *testing.T) {
	svc := newTestJWTService()
	token, err := svc.GenerateToken("user-1", "", nil, time.Hour)
	require.NoError(t, err)

	// Tamper with the token signature
	parts := strings.Split(token, ".")
	parts[2] = "invalidsignature"
	tampered := strings.Join(parts, ".")

	_, err = svc.ValidateToken(tampered)
	assert.ErrorIs(t, err, auth.ErrInvalidToken)
}

func TestJWTService_ValidateToken_MalformedToken(t *testing.T) {
	svc := newTestJWTService()
	_, err := svc.ValidateToken("not.a.valid.jwt.string")
	assert.ErrorIs(t, err, auth.ErrInvalidToken)
}

func TestJWTService_ValidateToken_EmptyToken(t *testing.T) {
	svc := newTestJWTService()
	_, err := svc.ValidateToken("")
	assert.ErrorIs(t, err, auth.ErrInvalidToken)
}

func TestJWTService_ValidateToken_WrongSecretKey(t *testing.T) {
	svc1 := auth.NewJWTService("secret-one-xxxxxxxxxxxxxxxxxxxxxxxx", testIssuer)
	svc2 := auth.NewJWTService("secret-two-xxxxxxxxxxxxxxxxxxxxxxxx", testIssuer)

	token, err := svc1.GenerateToken("user-1", "", nil, time.Hour)
	require.NoError(t, err)

	_, err = svc2.ValidateToken(token)
	assert.ErrorIs(t, err, auth.ErrInvalidToken)
}

// ---------------------------------------------------------------------------
// HasScope
// ---------------------------------------------------------------------------

func TestHasScope(t *testing.T) {
	tests := []struct {
		name          string
		claimScopes   []string
		requiredScope string
		want          bool
	}{
		{"match", []string{"users:read", "users:write"}, "users:read", true},
		{"no match", []string{"users:read"}, "users:write", false},
		{"empty claims", []string{}, "users:read", false},
		{"nil claims", nil, "users:read", false},
	}
	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			claims := &auth.Claims{Scopes: tc.claimScopes}
			assert.Equal(t, tc.want, auth.HasScope(claims, tc.requiredScope))
		})
	}
}

// ---------------------------------------------------------------------------
// HasAllScopes
// ---------------------------------------------------------------------------

func TestHasAllScopes(t *testing.T) {
	tests := []struct {
		name           string
		claimScopes    []string
		requiredScopes []string
		want           bool
	}{
		{"all present", []string{"users:read", "users:write"}, []string{"users:read", "users:write"}, true},
		{"superset present", []string{"users:read", "users:write", "users:delete"}, []string{"users:read"}, true},
		{"one missing", []string{"users:read"}, []string{"users:read", "users:write"}, false},
		{"all missing", []string{}, []string{"users:read"}, false},
		{"empty required", []string{}, []string{}, true},
		{"nil required", []string{"users:read"}, nil, true},
	}
	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			claims := &auth.Claims{Scopes: tc.claimScopes}
			assert.Equal(t, tc.want, auth.HasAllScopes(claims, tc.requiredScopes))
		})
	}
}

// ---------------------------------------------------------------------------
// ExtractBearerToken
// ---------------------------------------------------------------------------

func TestExtractBearerToken(t *testing.T) {
	tests := []struct {
		name       string
		header     string
		wantToken  string
		wantErrIs  error
	}{
		{"valid", "Bearer mytoken123", "mytoken123", nil},
		{"valid uppercase", "BEARER mytoken123", "mytoken123", nil},
		{"valid with spaces", "Bearer   mytoken123  ", "mytoken123", nil},
		{"empty header", "", "", auth.ErrEmptyAuthHeader},
		{"whitespace header", "   ", "", auth.ErrEmptyAuthHeader},
		{"no bearer prefix", "Token mytoken123", "", auth.ErrInvalidAuthHeaderFmt},
		{"only bearer", "Bearer", "", auth.ErrInvalidAuthHeaderFmt},
		{"bearer empty token", "Bearer  ", "", auth.ErrEmptyBearerToken},
	}
	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			got, err := auth.ExtractBearerToken(tc.header)
			if tc.wantErrIs != nil {
				assert.ErrorIs(t, err, tc.wantErrIs)
				assert.Empty(t, got)
			} else {
				require.NoError(t, err)
				assert.Equal(t, tc.wantToken, got)
			}
		})
	}
}
