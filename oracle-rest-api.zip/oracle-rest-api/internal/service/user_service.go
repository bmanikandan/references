package service

import (
	"context"
	"errors"
	"fmt"
	"time"

	"github.com/google/uuid"
	"github.com/yourorg/oracle-rest-api/internal/model"
	"github.com/yourorg/oracle-rest-api/internal/repository"
)

// Business-level sentinel errors.
var (
	ErrNotFound     = errors.New("user not found")
	ErrEmailExists  = errors.New("email address already in use")
)

type userService struct {
	repo repository.UserRepository
}

// NewUserService creates a UserService backed by the given repository.
func NewUserService(repo repository.UserRepository) UserService {
	return &userService{repo: repo}
}

// GetUsers returns a paginated, optionally filtered slice of users.
func (s *userService) GetUsers(ctx context.Context, filter model.UserFilter) ([]model.User, int64, error) {
	filter.Validate()
	users, total, err := s.repo.FindAll(ctx, filter)
	if err != nil {
		return nil, 0, fmt.Errorf("get users: %w", err)
	}
	return users, total, nil
}

// GetUserByID returns the user with the given ID.
func (s *userService) GetUserByID(ctx context.Context, id string) (*model.User, error) {
	user, err := s.repo.FindByID(ctx, id)
	if err != nil {
		if errors.Is(err, repository.ErrNotFound) {
			return nil, ErrNotFound
		}
		return nil, fmt.Errorf("get user by id: %w", err)
	}
	return user, nil
}

// CreateUser validates uniqueness and persists a new user.
func (s *userService) CreateUser(ctx context.Context, req model.CreateUserRequest) (*model.User, error) {
	// Enforce unique e-mail.
	_, err := s.repo.FindByEmail(ctx, req.Email)
	if err == nil {
		return nil, ErrEmailExists
	}
	if !errors.Is(err, repository.ErrNotFound) {
		return nil, fmt.Errorf("check email uniqueness: %w", err)
	}

	role := req.Role
	if role == "" {
		role = string(model.RoleUser)
	}

	now := time.Now().UTC()
	user := &model.User{
		ID:        uuid.New().String(),
		Name:      req.Name,
		Email:     req.Email,
		Role:      role,
		Status:    string(model.StatusActive),
		CreatedAt: now,
		UpdatedAt: now,
	}

	if err := s.repo.Create(ctx, user); err != nil {
		return nil, fmt.Errorf("persist new user: %w", err)
	}
	return user, nil
}

// UpdateUser applies a partial update to the user identified by id.
func (s *userService) UpdateUser(ctx context.Context, id string, req model.UpdateUserRequest) (*model.User, error) {
	user, err := s.repo.FindByID(ctx, id)
	if err != nil {
		if errors.Is(err, repository.ErrNotFound) {
			return nil, ErrNotFound
		}
		return nil, fmt.Errorf("fetch user for update: %w", err)
	}

	// If the e-mail is changing, ensure the new address is not taken by another user.
	if req.Email != "" && req.Email != user.Email {
		existing, emailErr := s.repo.FindByEmail(ctx, req.Email)
		if emailErr == nil && existing.ID != id {
			return nil, ErrEmailExists
		}
		if emailErr != nil && !errors.Is(emailErr, repository.ErrNotFound) {
			return nil, fmt.Errorf("check email uniqueness: %w", emailErr)
		}
	}

	if req.Name != "" {
		user.Name = req.Name
	}
	if req.Email != "" {
		user.Email = req.Email
	}
	if req.Role != "" {
		user.Role = req.Role
	}
	if req.Status != "" {
		user.Status = req.Status
	}
	user.UpdatedAt = time.Now().UTC()

	if err := s.repo.Update(ctx, user); err != nil {
		if errors.Is(err, repository.ErrNotFound) {
			return nil, ErrNotFound
		}
		return nil, fmt.Errorf("persist user update: %w", err)
	}
	return user, nil
}

// DeleteUser removes the user identified by id.
func (s *userService) DeleteUser(ctx context.Context, id string) error {
	if err := s.repo.Delete(ctx, id); err != nil {
		if errors.Is(err, repository.ErrNotFound) {
			return ErrNotFound
		}
		return fmt.Errorf("delete user: %w", err)
	}
	return nil
}
