// Package service implements the business-logic layer.
package service

import (
	"context"

	"github.com/yourorg/oracle-rest-api/internal/model"
)

// UserService defines the contract for user business operations.
type UserService interface {
	// GetUsers returns a paginated list of users matching the filter.
	GetUsers(ctx context.Context, filter model.UserFilter) ([]model.User, int64, error)
	// GetUserByID returns the user identified by id, or an error.
	GetUserByID(ctx context.Context, id string) (*model.User, error)
	// CreateUser validates the request and persists a new user.
	CreateUser(ctx context.Context, req model.CreateUserRequest) (*model.User, error)
	// UpdateUser applies the patch to the user identified by id.
	UpdateUser(ctx context.Context, id string, req model.UpdateUserRequest) (*model.User, error)
	// DeleteUser removes the user identified by id.
	DeleteUser(ctx context.Context, id string) error
}
