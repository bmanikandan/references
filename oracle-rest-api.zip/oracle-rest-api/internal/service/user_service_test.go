package service_test

import (
	"context"
	"errors"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"
	"github.com/yourorg/oracle-rest-api/internal/mocks"
	"github.com/yourorg/oracle-rest-api/internal/model"
	"github.com/yourorg/oracle-rest-api/internal/repository"
	"github.com/yourorg/oracle-rest-api/internal/service"
)

// ---------------------------------------------------------------------------
// helpers
// ---------------------------------------------------------------------------

func newTestService() (service.UserService, *mocks.MockUserRepository) {
	repo := &mocks.MockUserRepository{}
	svc := service.NewUserService(repo)
	return svc, repo
}

func sampleUser(id string) *model.User {
	return &model.User{
		ID:        id,
		Name:      "Alice",
		Email:     "alice@example.com",
		Role:      "user",
		Status:    "active",
		CreatedAt: time.Now().UTC(),
		UpdatedAt: time.Now().UTC(),
	}
}

// ---------------------------------------------------------------------------
// GetUsers
// ---------------------------------------------------------------------------

func TestUserService_GetUsers_Success(t *testing.T) {
	svc, repo := newTestService()
	filter := model.UserFilter{Page: 1, Limit: 10}
	users := []model.User{*sampleUser("1"), *sampleUser("2")}

	repo.On("FindAll", mock.Anything, filter).Return(users, int64(2), nil)

	got, total, err := svc.GetUsers(context.Background(), filter)
	require.NoError(t, err)
	assert.Equal(t, int64(2), total)
	assert.Len(t, got, 2)
	repo.AssertExpectations(t)
}

func TestUserService_GetUsers_RepoError(t *testing.T) {
	svc, repo := newTestService()
	filter := model.UserFilter{Page: 1, Limit: 10}
	repoErr := errors.New("db error")

	repo.On("FindAll", mock.Anything, filter).Return(nil, int64(0), repoErr)

	_, _, err := svc.GetUsers(context.Background(), filter)
	require.Error(t, err)
	assert.ErrorContains(t, err, "db error")
	repo.AssertExpectations(t)
}

func TestUserService_GetUsers_DefaultsApplied(t *testing.T) {
	svc, repo := newTestService()
	// Zero-value filter should be normalised by Validate() before reaching repo.
	normalised := model.UserFilter{Page: 1, Limit: 10}

	repo.On("FindAll", mock.Anything, normalised).Return([]model.User{}, int64(0), nil)

	_, _, err := svc.GetUsers(context.Background(), model.UserFilter{})
	require.NoError(t, err)
	repo.AssertExpectations(t)
}

// ---------------------------------------------------------------------------
// GetUserByID
// ---------------------------------------------------------------------------

func TestUserService_GetUserByID_Success(t *testing.T) {
	svc, repo := newTestService()
	expected := sampleUser("uuid-1")

	repo.On("FindByID", mock.Anything, "uuid-1").Return(expected, nil)

	got, err := svc.GetUserByID(context.Background(), "uuid-1")
	require.NoError(t, err)
	assert.Equal(t, expected, got)
	repo.AssertExpectations(t)
}

func TestUserService_GetUserByID_NotFound(t *testing.T) {
	svc, repo := newTestService()

	repo.On("FindByID", mock.Anything, "missing").Return(nil, repository.ErrNotFound)

	_, err := svc.GetUserByID(context.Background(), "missing")
	assert.ErrorIs(t, err, service.ErrNotFound)
	repo.AssertExpectations(t)
}

func TestUserService_GetUserByID_RepoError(t *testing.T) {
	svc, repo := newTestService()

	repo.On("FindByID", mock.Anything, "id-1").Return(nil, errors.New("db error"))

	_, err := svc.GetUserByID(context.Background(), "id-1")
	require.Error(t, err)
	assert.ErrorContains(t, err, "db error")
}

// ---------------------------------------------------------------------------
// CreateUser
// ---------------------------------------------------------------------------

func TestUserService_CreateUser_Success(t *testing.T) {
	svc, repo := newTestService()
	req := model.CreateUserRequest{Name: "Bob", Email: "bob@example.com", Role: "viewer"}

	repo.On("FindByEmail", mock.Anything, req.Email).Return(nil, repository.ErrNotFound)
	repo.On("Create", mock.Anything, mock.AnythingOfType("*model.User")).Return(nil)

	user, err := svc.CreateUser(context.Background(), req)
	require.NoError(t, err)
	assert.NotEmpty(t, user.ID)
	assert.Equal(t, "Bob", user.Name)
	assert.Equal(t, "bob@example.com", user.Email)
	assert.Equal(t, "viewer", user.Role)
	assert.Equal(t, "active", user.Status)
	repo.AssertExpectations(t)
}

func TestUserService_CreateUser_DefaultRole(t *testing.T) {
	svc, repo := newTestService()
	req := model.CreateUserRequest{Name: "Bob", Email: "bob@example.com"}

	repo.On("FindByEmail", mock.Anything, req.Email).Return(nil, repository.ErrNotFound)
	repo.On("Create", mock.Anything, mock.AnythingOfType("*model.User")).Return(nil)

	user, err := svc.CreateUser(context.Background(), req)
	require.NoError(t, err)
	assert.Equal(t, "user", user.Role)
}

func TestUserService_CreateUser_EmailAlreadyExists(t *testing.T) {
	svc, repo := newTestService()
	req := model.CreateUserRequest{Name: "Bob", Email: "existing@example.com"}
	existing := sampleUser("other-id")

	repo.On("FindByEmail", mock.Anything, req.Email).Return(existing, nil)

	_, err := svc.CreateUser(context.Background(), req)
	assert.ErrorIs(t, err, service.ErrEmailExists)
	repo.AssertExpectations(t)
}

func TestUserService_CreateUser_EmailCheckError(t *testing.T) {
	svc, repo := newTestService()
	req := model.CreateUserRequest{Name: "Bob", Email: "bob@example.com"}

	repo.On("FindByEmail", mock.Anything, req.Email).Return(nil, errors.New("db error"))

	_, err := svc.CreateUser(context.Background(), req)
	require.Error(t, err)
	assert.ErrorContains(t, err, "db error")
}

func TestUserService_CreateUser_PersistError(t *testing.T) {
	svc, repo := newTestService()
	req := model.CreateUserRequest{Name: "Bob", Email: "bob@example.com"}

	repo.On("FindByEmail", mock.Anything, req.Email).Return(nil, repository.ErrNotFound)
	repo.On("Create", mock.Anything, mock.AnythingOfType("*model.User")).Return(errors.New("insert failed"))

	_, err := svc.CreateUser(context.Background(), req)
	assert.ErrorContains(t, err, "insert failed")
}

// ---------------------------------------------------------------------------
// UpdateUser
// ---------------------------------------------------------------------------

func TestUserService_UpdateUser_Success(t *testing.T) {
	svc, repo := newTestService()
	existing := sampleUser("id-1")
	req := model.UpdateUserRequest{Name: "Alice Updated", Role: "admin"}

	repo.On("FindByID", mock.Anything, "id-1").Return(existing, nil)
	repo.On("Update", mock.Anything, mock.AnythingOfType("*model.User")).Return(nil)

	user, err := svc.UpdateUser(context.Background(), "id-1", req)
	require.NoError(t, err)
	assert.Equal(t, "Alice Updated", user.Name)
	assert.Equal(t, "admin", user.Role)
	repo.AssertExpectations(t)
}

func TestUserService_UpdateUser_NotFound(t *testing.T) {
	svc, repo := newTestService()
	req := model.UpdateUserRequest{Name: "X"}

	repo.On("FindByID", mock.Anything, "bad-id").Return(nil, repository.ErrNotFound)

	_, err := svc.UpdateUser(context.Background(), "bad-id", req)
	assert.ErrorIs(t, err, service.ErrNotFound)
}

func TestUserService_UpdateUser_EmailConflict(t *testing.T) {
	svc, repo := newTestService()
	existing := sampleUser("id-1")
	otherUser := sampleUser("id-2")
	otherUser.Email = "taken@example.com"

	req := model.UpdateUserRequest{Email: "taken@example.com"}

	repo.On("FindByID", mock.Anything, "id-1").Return(existing, nil)
	repo.On("FindByEmail", mock.Anything, "taken@example.com").Return(otherUser, nil)

	_, err := svc.UpdateUser(context.Background(), "id-1", req)
	assert.ErrorIs(t, err, service.ErrEmailExists)
}

func TestUserService_UpdateUser_EmailSameAsOwn(t *testing.T) {
	svc, repo := newTestService()
	existing := sampleUser("id-1")
	req := model.UpdateUserRequest{Email: existing.Email} // same email → no conflict check needed

	repo.On("FindByID", mock.Anything, "id-1").Return(existing, nil)
	repo.On("Update", mock.Anything, mock.AnythingOfType("*model.User")).Return(nil)

	_, err := svc.UpdateUser(context.Background(), "id-1", req)
	require.NoError(t, err)
}

func TestUserService_UpdateUser_EmailCheckError(t *testing.T) {
	svc, repo := newTestService()
	existing := sampleUser("id-1")
	req := model.UpdateUserRequest{Email: "new@example.com"}

	repo.On("FindByID", mock.Anything, "id-1").Return(existing, nil)
	repo.On("FindByEmail", mock.Anything, "new@example.com").Return(nil, errors.New("db error"))

	_, err := svc.UpdateUser(context.Background(), "id-1", req)
	assert.ErrorContains(t, err, "db error")
}

func TestUserService_UpdateUser_PersistError(t *testing.T) {
	svc, repo := newTestService()
	existing := sampleUser("id-1")
	req := model.UpdateUserRequest{Name: "New Name"}

	repo.On("FindByID", mock.Anything, "id-1").Return(existing, nil)
	repo.On("Update", mock.Anything, mock.AnythingOfType("*model.User")).Return(errors.New("update failed"))

	_, err := svc.UpdateUser(context.Background(), "id-1", req)
	assert.ErrorContains(t, err, "update failed")
}

func TestUserService_UpdateUser_PersistNotFound(t *testing.T) {
	svc, repo := newTestService()
	existing := sampleUser("id-1")
	req := model.UpdateUserRequest{Name: "New Name"}

	repo.On("FindByID", mock.Anything, "id-1").Return(existing, nil)
	repo.On("Update", mock.Anything, mock.AnythingOfType("*model.User")).Return(repository.ErrNotFound)

	_, err := svc.UpdateUser(context.Background(), "id-1", req)
	assert.ErrorIs(t, err, service.ErrNotFound)
}

// ---------------------------------------------------------------------------
// DeleteUser
// ---------------------------------------------------------------------------

func TestUserService_DeleteUser_Success(t *testing.T) {
	svc, repo := newTestService()

	repo.On("Delete", mock.Anything, "id-1").Return(nil)

	err := svc.DeleteUser(context.Background(), "id-1")
	require.NoError(t, err)
	repo.AssertExpectations(t)
}

func TestUserService_DeleteUser_NotFound(t *testing.T) {
	svc, repo := newTestService()

	repo.On("Delete", mock.Anything, "bad").Return(repository.ErrNotFound)

	err := svc.DeleteUser(context.Background(), "bad")
	assert.ErrorIs(t, err, service.ErrNotFound)
}

func TestUserService_DeleteUser_RepoError(t *testing.T) {
	svc, repo := newTestService()

	repo.On("Delete", mock.Anything, "id-1").Return(errors.New("db error"))

	err := svc.DeleteUser(context.Background(), "id-1")
	assert.ErrorContains(t, err, "db error")
}
