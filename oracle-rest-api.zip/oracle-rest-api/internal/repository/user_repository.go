package repository

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strings"

	"github.com/yourorg/oracle-rest-api/internal/model"
)

// ErrNotFound is returned when a requested record does not exist.
var ErrNotFound = errors.New("record not found")

type userRepository struct {
	db *sql.DB
}

// NewUserRepository creates a UserRepository backed by the given *sql.DB.
func NewUserRepository(db *sql.DB) UserRepository {
	return &userRepository{db: db}
}

// FindAll returns a filtered, paginated list of users along with the total matching count.
func (r *userRepository) FindAll(ctx context.Context, filter model.UserFilter) ([]model.User, int64, error) {
	filter.Validate()

	var (
		conditions []string
		args       []interface{}
		argIdx     = 1
	)

	if filter.Status != "" {
		conditions = append(conditions, fmt.Sprintf("status = :%d", argIdx))
		args = append(args, filter.Status)
		argIdx++
	}
	if filter.Role != "" {
		conditions = append(conditions, fmt.Sprintf("role = :%d", argIdx))
		args = append(args, filter.Role)
		argIdx++
	}

	whereClause := ""
	if len(conditions) > 0 {
		whereClause = " WHERE " + strings.Join(conditions, " AND ")
	}

	// Count total matching rows.
	var total int64
	countSQL := "SELECT COUNT(*) FROM users" + whereClause
	if err := r.db.QueryRowContext(ctx, countSQL, args...).Scan(&total); err != nil {
		return nil, 0, fmt.Errorf("count users: %w", err)
	}

	// Fetch the requested page (Oracle 12c+ syntax).
	dataSQL := fmt.Sprintf(
		`SELECT id, name, email, role, status, created_at, updated_at
		   FROM users%s
		  ORDER BY created_at DESC
		  OFFSET :%d ROWS FETCH NEXT :%d ROWS ONLY`,
		whereClause, argIdx, argIdx+1,
	)
	args = append(args, filter.Offset(), filter.Limit)

	rows, err := r.db.QueryContext(ctx, dataSQL, args...)
	if err != nil {
		return nil, 0, fmt.Errorf("query users: %w", err)
	}
	defer rows.Close()

	users := make([]model.User, 0)
	for rows.Next() {
		var u model.User
		if err := rows.Scan(&u.ID, &u.Name, &u.Email, &u.Role, &u.Status, &u.CreatedAt, &u.UpdatedAt); err != nil {
			return nil, 0, fmt.Errorf("scan user row: %w", err)
		}
		users = append(users, u)
	}
	if err := rows.Err(); err != nil {
		return nil, 0, fmt.Errorf("iterate user rows: %w", err)
	}

	return users, total, nil
}

// FindByID retrieves a single user by primary key.
func (r *userRepository) FindByID(ctx context.Context, id string) (*model.User, error) {
	const q = `SELECT id, name, email, role, status, created_at, updated_at
	             FROM users WHERE id = :1`

	var u model.User
	err := r.db.QueryRowContext(ctx, q, id).
		Scan(&u.ID, &u.Name, &u.Email, &u.Role, &u.Status, &u.CreatedAt, &u.UpdatedAt)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, ErrNotFound
		}
		return nil, fmt.Errorf("find user by id: %w", err)
	}
	return &u, nil
}

// FindByEmail retrieves a single user by unique e-mail address.
func (r *userRepository) FindByEmail(ctx context.Context, email string) (*model.User, error) {
	const q = `SELECT id, name, email, role, status, created_at, updated_at
	             FROM users WHERE email = :1`

	var u model.User
	err := r.db.QueryRowContext(ctx, q, email).
		Scan(&u.ID, &u.Name, &u.Email, &u.Role, &u.Status, &u.CreatedAt, &u.UpdatedAt)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, ErrNotFound
		}
		return nil, fmt.Errorf("find user by email: %w", err)
	}
	return &u, nil
}

// Create inserts a new user record.
func (r *userRepository) Create(ctx context.Context, user *model.User) error {
	const q = `INSERT INTO users (id, name, email, role, status, created_at, updated_at)
	           VALUES (:1, :2, :3, :4, :5, :6, :7)`

	_, err := r.db.ExecContext(ctx, q,
		user.ID, user.Name, user.Email, user.Role, user.Status,
		user.CreatedAt, user.UpdatedAt,
	)
	if err != nil {
		return fmt.Errorf("create user: %w", err)
	}
	return nil
}

// Update applies changes to an existing user record.
func (r *userRepository) Update(ctx context.Context, user *model.User) error {
	const q = `UPDATE users
	              SET name = :1, email = :2, role = :3, status = :4, updated_at = :5
	            WHERE id = :6`

	result, err := r.db.ExecContext(ctx, q,
		user.Name, user.Email, user.Role, user.Status, user.UpdatedAt, user.ID,
	)
	if err != nil {
		return fmt.Errorf("update user: %w", err)
	}
	n, err := result.RowsAffected()
	if err != nil {
		return fmt.Errorf("rows affected after update: %w", err)
	}
	if n == 0 {
		return ErrNotFound
	}
	return nil
}

// Delete removes a user by primary key.
func (r *userRepository) Delete(ctx context.Context, id string) error {
	const q = `DELETE FROM users WHERE id = :1`

	result, err := r.db.ExecContext(ctx, q, id)
	if err != nil {
		return fmt.Errorf("delete user: %w", err)
	}
	n, err := result.RowsAffected()
	if err != nil {
		return fmt.Errorf("rows affected after delete: %w", err)
	}
	if n == 0 {
		return ErrNotFound
	}
	return nil
}
