// Package repository defines data-access interfaces and their Oracle implementations.
package repository

import (
	"context"

	"github.com/yourorg/oracle-rest-api/internal/model"
)

// UserRepository defines the contract for user persistence operations.
type UserRepository interface {
	// FindAll returns a paginated, optionally filtered list of users and the total count.
	FindAll(ctx context.Context, filter model.UserFilter) ([]model.User, int64, error)
	// FindByID returns the user with the given ID, or ErrNotFound.
	FindByID(ctx context.Context, id string) (*model.User, error)
	// FindByEmail returns the user with the given email, or ErrNotFound.
	FindByEmail(ctx context.Context, email string) (*model.User, error)
	// Create persists a new user record.
	Create(ctx context.Context, user *model.User) error
	// Update updates an existing user record.
	Update(ctx context.Context, user *model.User) error
	// Delete removes a user record by ID.
	Delete(ctx context.Context, id string) error
}
