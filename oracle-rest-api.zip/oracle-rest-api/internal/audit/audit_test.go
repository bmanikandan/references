package audit_test

import (
	"context"
	"errors"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/yourorg/oracle-rest-api/internal/audit"
)

// ---------------------------------------------------------------------------
// Mock Logger — exercises the interface contract
// ---------------------------------------------------------------------------

type mockLogger struct{ mock.Mock }

func (m *mockLogger) Log(ctx context.Context, record audit.Record) error {
	return m.Called(ctx, record).Error(0)
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

func TestAuditLogger_Log_Success(t *testing.T) {
	l := &mockLogger{}
	rec := audit.Record{
		RequestID:  "req-1",
		ActorID:    "user-1",
		Method:     "POST",
		Path:       "/api/v1/users",
		StatusCode: 201,
		DurationMs: 42,
		Timestamp:  time.Now().UTC(),
	}
	l.On("Log", mock.Anything, rec).Return(nil)

	err := l.Log(context.Background(), rec)
	assert.NoError(t, err)
	l.AssertExpectations(t)
}

func TestAuditLogger_Log_Error(t *testing.T) {
	l := &mockLogger{}
	rec := audit.Record{RequestID: "req-fail"}
	l.On("Log", mock.Anything, rec).Return(errors.New("mongo down"))

	err := l.Log(context.Background(), rec)
	assert.ErrorContains(t, err, "mongo down")
}

func TestAuditRecord_Timestamps(t *testing.T) {
	now := time.Now().UTC()
	rec := audit.Record{
		RequestID:  "r1",
		Method:     "DELETE",
		Path:       "/api/v1/users/id-1",
		StatusCode: 200,
		Timestamp:  now,
	}
	assert.Equal(t, now, rec.Timestamp)
	assert.Equal(t, "DELETE", rec.Method)
}

func TestAuditRecord_WithRequestBody(t *testing.T) {
	body := map[string]string{"name": "Alice", "email": "a@b.com"}
	rec := audit.Record{
		Method:      "POST",
		RequestBody: body,
		StatusCode:  201,
	}
	assert.NotNil(t, rec.RequestBody)
}

func TestAuditRecord_WithResponse(t *testing.T) {
	resp := map[string]interface{}{"id": "uuid-1", "name": "Alice"}
	rec := audit.Record{
		Method:     "PUT",
		Response:   resp,
		StatusCode: 200,
	}
	assert.NotNil(t, rec.Response)
}
