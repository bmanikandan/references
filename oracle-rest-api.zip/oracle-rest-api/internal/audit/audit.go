// Package audit provides MongoDB-backed audit logging for all write operations.
// Every HTTP write (POST / PUT / DELETE) records its request body, response,
// actor, duration, and outcome into the configured MongoDB collection.
package audit

import (
	"context"
	"fmt"
	"time"

	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"

	"github.com/yourorg/oracle-rest-api/internal/config"
)

// Record is a single write-operation audit entry stored in MongoDB.
type Record struct {
	ID          primitive.ObjectID `bson:"_id,omitempty"  json:"-"`
	RequestID   string             `bson:"request_id"     json:"request_id"`
	ActorID     string             `bson:"actor_id"       json:"actor_id"`
	Method      string             `bson:"method"         json:"method"`
	Path        string             `bson:"path"           json:"path"`
	TargetID    string             `bson:"target_id,omitempty" json:"target_id,omitempty"`
	RequestBody interface{}        `bson:"request_body,omitempty" json:"request_body,omitempty"`
	Response    interface{}        `bson:"response,omitempty"    json:"response,omitempty"`
	StatusCode  int                `bson:"status_code"    json:"status_code"`
	DurationMs  int64              `bson:"duration_ms"    json:"duration_ms"`
	Timestamp   time.Time          `bson:"timestamp"      json:"timestamp"`
}

// Logger defines the contract for audit logging.
type Logger interface {
	Log(ctx context.Context, record Record) error
}

// ------------------------------ MongoDB implementation ----------------------------------

type mongoLogger struct {
	collection *mongo.Collection
}

// NewMongoLogger connects to MongoDB and returns a Logger backed by the
// configured database and collection.
func NewMongoLogger(cfg *config.MongoConfig) (Logger, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	client, err := mongo.Connect(ctx, options.Client().ApplyURI(cfg.URI))
	if err != nil {
		return nil, fmt.Errorf("mongodb connect: %w", err)
	}
	if err := client.Ping(ctx, nil); err != nil {
		return nil, fmt.Errorf("mongodb ping: %w", err)
	}

	coll := client.Database(cfg.Database).Collection(cfg.AuditCollection)
	return &mongoLogger{collection: coll}, nil
}

// Log inserts an audit record into MongoDB.
func (l *mongoLogger) Log(ctx context.Context, record Record) error {
	if record.ID.IsZero() {
		record.ID = primitive.NewObjectID()
	}
	if record.Timestamp.IsZero() {
		record.Timestamp = time.Now().UTC()
	}

	if _, err := l.collection.InsertOne(ctx, record); err != nil {
		return fmt.Errorf("audit log insert: %w", err)
	}
	return nil
}
