package messaging

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	"github.com/google/uuid"
	"github.com/segmentio/kafka-go"
	"github.com/yourorg/oracle-rest-api/internal/config"
)

// EventProducer publishes Events to a Kafka topic.
type EventProducer interface {
	// Publish sends a single event to the configured topic.
	// Errors are returned to the caller; the handler should log and continue.
	Publish(ctx context.Context, event Event) error
	// Close flushes pending messages and releases resources.
	Close() error
}

// kafkaProducer wraps a kafka-go Writer.
type kafkaProducer struct {
	writer *kafka.Writer
}

// NewKafkaProducer creates an EventProducer backed by the kafka-go Writer.
// The writer is configured for synchronous, at-least-once delivery.
func NewKafkaProducer(cfg *config.KafkaConfig) EventProducer {
	w := &kafka.Writer{
		Addr:                   kafka.TCP(cfg.Brokers...),
		Topic:                  cfg.Topic,
		Balancer:               &kafka.LeastBytes{},
		RequiredAcks:           kafka.RequireOne,
		Async:                  false,
		AllowAutoTopicCreation: true,
	}
	return &kafkaProducer{writer: w}
}

// Publish serialises the event to JSON and writes it to Kafka.
func (p *kafkaProducer) Publish(ctx context.Context, event Event) error {
	if event.ID == "" {
		event.ID = uuid.New().String()
	}
	if event.Timestamp.IsZero() {
		event.Timestamp = time.Now().UTC()
	}

	payload, err := json.Marshal(event)
	if err != nil {
		return fmt.Errorf("marshal event: %w", err)
	}

	return p.writer.WriteMessages(ctx, kafka.Message{
		Key:   []byte(event.ID),
		Value: payload,
		Headers: []kafka.Header{
			{Key: "event-type", Value: []byte(event.Type)},
			{Key: "content-type", Value: []byte("application/json")},
		},
	})
}

// Close shuts the underlying Kafka writer down gracefully.
func (p *kafkaProducer) Close() error {
	if err := p.writer.Close(); err != nil {
		return fmt.Errorf("kafka producer close: %w", err)
	}
	return nil
}
