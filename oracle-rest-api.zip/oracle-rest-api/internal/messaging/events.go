// Package messaging defines Kafka event contracts and provides producer / consumer implementations.
package messaging

import "time"

// Event type constants — one Kafka topic, discriminated by EventType.
const (
	EventUserCreated = "user.created"
	EventUserUpdated = "user.updated"
	EventUserDeleted = "user.deleted"

	// TopicUserEvents is the default Kafka topic for all user-domain events.
	TopicUserEvents = "user-events"
)

// Event is the canonical envelope for every message published to Kafka.
type Event struct {
	// ID is a unique identifier (UUID) for this event instance.
	ID string `json:"id"`
	// Type distinguishes the kind of domain event (e.g. "user.created").
	Type string `json:"type"`
	// RequestID links the event back to the originating HTTP request.
	RequestID string `json:"request_id"`
	// ActorID is the subject claim from the JWT that triggered the operation.
	ActorID string `json:"actor_id,omitempty"`
	// Timestamp records when the event was emitted (UTC).
	Timestamp time.Time `json:"timestamp"`
	// Payload carries the domain-specific data for the event.
	Payload interface{} `json:"payload"`
}

// UserPayload is the payload carried inside user-domain events.
type UserPayload struct {
	UserID string      `json:"user_id"`
	Data   interface{} `json:"data,omitempty"`
}
