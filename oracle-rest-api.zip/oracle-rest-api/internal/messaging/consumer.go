package messaging

import (
	"context"
	"encoding/json"
	"fmt"

	"github.com/segmentio/kafka-go"
	"go.uber.org/zap"

	"github.com/yourorg/oracle-rest-api/internal/config"
)

// MessageHandler is a function that processes a consumed Kafka event.
// Implementations should be idempotent and return an error only when
// the message should be retried (or sent to a dead-letter topic).
type MessageHandler func(ctx context.Context, event Event) error

// Consumer wraps a kafka-go Reader and dispatches events to registered handlers.
type Consumer struct {
	reader   *kafka.Reader
	handlers map[string]MessageHandler
	logger   *zap.Logger
}

// NewKafkaConsumer creates a Consumer for the topic configured in cfg.
func NewKafkaConsumer(cfg *config.KafkaConfig, logger *zap.Logger) *Consumer {
	r := kafka.NewReader(kafka.ReaderConfig{
		Brokers:        cfg.Brokers,
		GroupID:        cfg.ConsumerGroup,
		Topic:          cfg.Topic,
		MaxBytes:       10 * 1024 * 1024, // 10 MB
		StartOffset:    kafka.LastOffset,
		CommitInterval: 0, // manual commit
	})
	return &Consumer{
		reader:   r,
		handlers: make(map[string]MessageHandler),
		logger:   logger,
	}
}

// RegisterHandler wires a MessageHandler to a specific event type.
// If no handler is registered for a type, the message is logged and skipped.
func (c *Consumer) RegisterHandler(eventType string, h MessageHandler) {
	c.handlers[eventType] = h
}

// Start begins consuming messages from Kafka in a blocking loop.
// It returns when ctx is cancelled (graceful shutdown signal).
func (c *Consumer) Start(ctx context.Context) {
	c.logger.Info("kafka consumer started",
		zap.String("topic", c.reader.Config().Topic),
		zap.String("group", c.reader.Config().GroupID),
	)

	for {
		msg, err := c.reader.FetchMessage(ctx)
		if err != nil {
			if ctx.Err() != nil {
				c.logger.Info("kafka consumer shutting down gracefully")
				return
			}
			c.logger.Error("kafka fetch error", zap.Error(err))
			continue
		}

		c.dispatch(ctx, msg)

		if err := c.reader.CommitMessages(ctx, msg); err != nil {
			c.logger.Error("kafka commit error",
				zap.Error(err),
				zap.Int("partition", msg.Partition),
				zap.Int64("offset", msg.Offset),
			)
		}
	}
}

// dispatch deserialises the raw message, finds the correct handler, and calls it.
func (c *Consumer) dispatch(ctx context.Context, msg kafka.Message) {
	var event Event
	if err := json.Unmarshal(msg.Value, &event); err != nil {
		c.logger.Error("kafka unmarshal error",
			zap.Error(err),
			zap.ByteString("raw", msg.Value),
		)
		return
	}

	c.logger.Info("kafka event received",
		zap.String("event_id", event.ID),
		zap.String("event_type", event.Type),
		zap.String("request_id", event.RequestID),
		zap.String("actor_id", event.ActorID),
		zap.Time("timestamp", event.Timestamp),
		zap.Int("partition", msg.Partition),
		zap.Int64("offset", msg.Offset),
	)

	h, ok := c.handlers[event.Type]
	if !ok {
		c.logger.Warn("no handler registered for event type", zap.String("type", event.Type))
		return
	}

	if err := h(ctx, event); err != nil {
		c.logger.Error("event handler error",
			zap.String("event_type", event.Type),
			zap.String("event_id", event.ID),
			zap.Error(err),
		)
	}
}

// Close shuts down the reader and releases resources.
func (c *Consumer) Close() error {
	if err := c.reader.Close(); err != nil {
		return fmt.Errorf("kafka consumer close: %w", err)
	}
	c.logger.Info("kafka consumer closed")
	return nil
}
