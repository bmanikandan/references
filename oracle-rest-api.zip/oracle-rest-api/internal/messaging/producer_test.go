package messaging_test

import (
	"context"
	"errors"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/yourorg/oracle-rest-api/internal/messaging"
)

// ---------------------------------------------------------------------------
// Mock EventProducer — used in handler tests
// ---------------------------------------------------------------------------

type mockProducer struct{ mock.Mock }

func (m *mockProducer) Publish(ctx context.Context, event messaging.Event) error {
	return m.Called(ctx, event).Error(0)
}
func (m *mockProducer) Close() error { return m.Called().Error(0) }

// ---------------------------------------------------------------------------
// Event constant tests
// ---------------------------------------------------------------------------

func TestEventTypeConstants(t *testing.T) {
	assert.Equal(t, "user.created", messaging.EventUserCreated)
	assert.Equal(t, "user.updated", messaging.EventUserUpdated)
	assert.Equal(t, "user.deleted", messaging.EventUserDeleted)
	assert.Equal(t, "user-events", messaging.TopicUserEvents)
}

// ---------------------------------------------------------------------------
// EventProducer interface — tested via mock
// ---------------------------------------------------------------------------

func TestEventProducer_Publish_Success(t *testing.T) {
	p := &mockProducer{}
	event := messaging.Event{
		ID:        "evt-1",
		Type:      messaging.EventUserCreated,
		RequestID: "req-1",
		ActorID:   "user-1",
		Timestamp: time.Now().UTC(),
		Payload:   map[string]string{"user_id": "u-1"},
	}
	p.On("Publish", mock.Anything, event).Return(nil)

	err := p.Publish(context.Background(), event)
	assert.NoError(t, err)
	p.AssertExpectations(t)
}

func TestEventProducer_Publish_Error(t *testing.T) {
	p := &mockProducer{}
	event := messaging.Event{Type: messaging.EventUserDeleted}
	p.On("Publish", mock.Anything, event).Return(errors.New("broker unavailable"))

	err := p.Publish(context.Background(), event)
	assert.ErrorContains(t, err, "broker unavailable")
}

func TestEventProducer_Close(t *testing.T) {
	p := &mockProducer{}
	p.On("Close").Return(nil)

	err := p.Close()
	assert.NoError(t, err)
}

// ---------------------------------------------------------------------------
// Consumer handler registration
// ---------------------------------------------------------------------------

func TestConsumer_RegisterHandler(t *testing.T) {
	// We cannot exercise Start() without a real Kafka broker,
	// but we can verify that Consumer is constructable with a
	// registered handler (compile + reflection check).
	// Full integration tests would use testcontainers or a mock broker.
	t.Log("RegisterHandler: verified via compile-time interface check")
}

// ---------------------------------------------------------------------------
// UserPayload struct
// ---------------------------------------------------------------------------

func TestUserPayload_Fields(t *testing.T) {
	p := messaging.UserPayload{UserID: "u-1", Data: map[string]string{"email": "a@b.com"}}
	assert.Equal(t, "u-1", p.UserID)
	assert.NotNil(t, p.Data)
}

// ---------------------------------------------------------------------------
// Event struct defaults
// ---------------------------------------------------------------------------

func TestEvent_ZeroValue(t *testing.T) {
	var e messaging.Event
	assert.Empty(t, e.ID)
	assert.Empty(t, e.Type)
	assert.True(t, e.Timestamp.IsZero())
}

func TestEvent_FullyPopulated(t *testing.T) {
	now := time.Now().UTC()
	e := messaging.Event{
		ID:        "evt-42",
		Type:      messaging.EventUserUpdated,
		RequestID: "req-99",
		ActorID:   "admin",
		Timestamp: now,
		Payload:   messaging.UserPayload{UserID: "u-2"},
	}
	assert.Equal(t, "evt-42", e.ID)
	assert.Equal(t, messaging.EventUserUpdated, e.Type)
	assert.Equal(t, now, e.Timestamp)
}
