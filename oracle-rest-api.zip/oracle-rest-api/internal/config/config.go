// Package config loads and validates application configuration from environment variables.
package config

import (
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/joho/godotenv"
)

// Config aggregates all application configuration.
type Config struct {
	Server   ServerConfig
	Database DatabaseConfig
	JWT      JWTConfig
	Redis    RedisConfig
	Mongo    MongoConfig
	Kafka    KafkaConfig
}

// ServerConfig holds HTTP server settings.
type ServerConfig struct {
	Host         string
	Port         string
	Environment  string
	ReadTimeout  time.Duration
	WriteTimeout time.Duration
}

// DatabaseConfig holds Oracle database connection settings.
type DatabaseConfig struct {
	Host     string
	Port     string
	User     string
	Password string
	DBName   string
	MaxOpen  int
	MaxIdle  int
}

// JWTConfig holds JWT / OAuth 2.0 settings.
type JWTConfig struct {
	SecretKey string
	Issuer    string
	Expiry    time.Duration
}

// RedisConfig holds Redis connection settings.
type RedisConfig struct {
	Host     string
	Port     string
	Password string
	DB       int
	// UserCacheTTL is the TTL for individual user cache entries.
	UserCacheTTL time.Duration
	// ListCacheTTL is the shorter TTL for paginated list cache entries.
	ListCacheTTL time.Duration
}

// MongoConfig holds MongoDB connection settings.
type MongoConfig struct {
	URI             string
	Database        string
	AuditCollection string
}

// KafkaConfig holds Kafka producer / consumer settings.
type KafkaConfig struct {
	// Brokers is a comma-separated list of Kafka broker addresses.
	Brokers       []string
	Topic         string
	ConsumerGroup string
}

// Load reads configuration from environment variables (and an optional .env file).
func Load() (*Config, error) {
	_ = godotenv.Load() // non-critical; ignore missing .env

	dbMaxOpen, _ := strconv.Atoi(getEnv("DB_MAX_OPEN_CONNS", "25"))
	dbMaxIdle, _ := strconv.Atoi(getEnv("DB_MAX_IDLE_CONNS", "10"))
	redisDB, _ := strconv.Atoi(getEnv("REDIS_DB", "0"))

	cfg := &Config{
		Server: ServerConfig{
			Host:         getEnv("SERVER_HOST", "0.0.0.0"),
			Port:         getEnv("SERVER_PORT", "8080"),
			Environment:  getEnv("APP_ENV", "development"),
			ReadTimeout:  getDurationEnv("SERVER_READ_TIMEOUT", 30*time.Second),
			WriteTimeout: getDurationEnv("SERVER_WRITE_TIMEOUT", 30*time.Second),
		},
		Database: DatabaseConfig{
			Host:     getEnv("DB_HOST", "localhost"),
			Port:     getEnv("DB_PORT", "1521"),
			User:     getEnv("DB_USER", ""),
			Password: getEnv("DB_PASSWORD", ""),
			DBName:   getEnv("DB_NAME", "ORCL"),
			MaxOpen:  dbMaxOpen,
			MaxIdle:  dbMaxIdle,
		},
		Redis: RedisConfig{
			Host:         getEnv("REDIS_HOST", "localhost"),
			Port:         getEnv("REDIS_PORT", "6379"),
			Password:     getEnv("REDIS_PASSWORD", ""),
			DB:           redisDB,
			UserCacheTTL: getDurationEnv("REDIS_USER_CACHE_TTL", 10*time.Minute),
			ListCacheTTL: getDurationEnv("REDIS_LIST_CACHE_TTL", 1*time.Minute),
		},
		Mongo: MongoConfig{
			URI:             getEnv("MONGO_URI", "mongodb://localhost:27017"),
			Database:        getEnv("MONGO_DB", "oracle_rest_api"),
			AuditCollection: getEnv("MONGO_AUDIT_COLLECTION", "audit_logs"),
		},
		Kafka: KafkaConfig{
			Brokers:       splitCSV(getEnv("KAFKA_BROKERS", "localhost:9092")),
			Topic:         getEnv("KAFKA_TOPIC", "user-events"),
			ConsumerGroup: getEnv("KAFKA_CONSUMER_GROUP", "oracle-rest-api"),
		},
	}

	if cfg.Database.User == "" {
		return nil, fmt.Errorf("DB_USER is required")
	}
	if cfg.Database.Password == "" {
		return nil, fmt.Errorf("DB_PASSWORD is required")
	}

	secretKey := getEnv("JWT_SECRET_KEY", "")
	if secretKey == "" {
		return nil, fmt.Errorf("JWT_SECRET_KEY is required")
	}
	cfg.JWT = JWTConfig{
		SecretKey: secretKey,
		Issuer:    getEnv("JWT_ISSUER", "oracle-rest-api"),
		Expiry:    getDurationEnv("JWT_EXPIRY", time.Hour),
	}

	return cfg, nil
}

// DSN returns the Oracle connection string for database/sql.
func (d *DatabaseConfig) DSN() string {
	return fmt.Sprintf("oracle://%s:%s@%s:%s/%s",
		d.User, d.Password, d.Host, d.Port, d.DBName)
}

// Addr returns the server listen address.
func (s *ServerConfig) Addr() string {
	return s.Host + ":" + s.Port
}

// Addr returns the Redis address string.
func (r *RedisConfig) Addr() string {
	return r.Host + ":" + r.Port
}

func getEnv(key, defaultValue string) string {
	if val := os.Getenv(key); val != "" {
		return val
	}
	return defaultValue
}

func getDurationEnv(key string, defaultValue time.Duration) time.Duration {
	if val := os.Getenv(key); val != "" {
		if d, err := time.ParseDuration(val); err == nil {
			return d
		}
	}
	return defaultValue
}

func splitCSV(s string) []string {
	parts := strings.Split(s, ",")
	out := make([]string, 0, len(parts))
	for _, p := range parts {
		if t := strings.TrimSpace(p); t != "" {
			out = append(out, t)
		}
	}
	return out
}
