package mocks

import (
	"context"

	"github.com/stretchr/testify/mock"
	"github.com/yourorg/oracle-rest-api/internal/model"
)

// MockUserService is a testify mock for service.UserService.
type MockUserService struct {
	mock.Mock
}

func (m *MockUserService) GetUsers(ctx context.Context, filter model.UserFilter) ([]model.User, int64, error) {
	args := m.Called(ctx, filter)
	users, _ := args.Get(0).([]model.User)
	return users, args.Get(1).(int64), args.Error(2)
}

func (m *MockUserService) GetUserByID(ctx context.Context, id string) (*model.User, error) {
	args := m.Called(ctx, id)
	user, _ := args.Get(0).(*model.User)
	return user, args.Error(1)
}

func (m *MockUserService) CreateUser(ctx context.Context, req model.CreateUserRequest) (*model.User, error) {
	args := m.Called(ctx, req)
	user, _ := args.Get(0).(*model.User)
	return user, args.Error(1)
}

func (m *MockUserService) UpdateUser(ctx context.Context, id string, req model.UpdateUserRequest) (*model.User, error) {
	args := m.Called(ctx, id, req)
	user, _ := args.Get(0).(*model.User)
	return user, args.Error(1)
}

func (m *MockUserService) DeleteUser(ctx context.Context, id string) error {
	args := m.Called(ctx, id)
	return args.Error(0)
}
