package mocks

import (
	"context"

	"github.com/stretchr/testify/mock"
	"github.com/yourorg/oracle-rest-api/internal/messaging"
)

// MockEventProducer is a testify mock for messaging.EventProducer.
type MockEventProducer struct {
	mock.Mock
}

var _ messaging.EventProducer = (*MockEventProducer)(nil)

func (m *MockEventProducer) Publish(ctx context.Context, event messaging.Event) error {
	return m.Called(ctx, event).Error(0)
}

func (m *MockEventProducer) Close() error {
	return m.Called().Error(0)
}
