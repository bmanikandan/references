package mocks

import (
	"context"
	"time"

	"github.com/stretchr/testify/mock"
	"github.com/yourorg/oracle-rest-api/internal/cache"
)

// MockCacheStore is a testify mock for cache.CacheStore.
type MockCacheStore struct {
	mock.Mock
}

var _ cache.CacheStore = (*MockCacheStore)(nil)

func (m *MockCacheStore) Get(ctx context.Context, key string) ([]byte, error) {
	args := m.Called(ctx, key)
	data, _ := args.Get(0).([]byte)
	return data, args.Error(1)
}

func (m *MockCacheStore) Set(ctx context.Context, key string, value []byte, ttl time.Duration) error {
	return m.Called(ctx, key, value, ttl).Error(0)
}

func (m *MockCacheStore) Delete(ctx context.Context, keys ...string) error {
	iargs := make([]interface{}, len(keys)+1)
	iargs[0] = ctx
	for i, k := range keys {
		iargs[i+1] = k
	}
	return m.Called(iargs...).Error(0)
}

func (m *MockCacheStore) FlushByPattern(ctx context.Context, pattern string) error {
	return m.Called(ctx, pattern).Error(0)
}
