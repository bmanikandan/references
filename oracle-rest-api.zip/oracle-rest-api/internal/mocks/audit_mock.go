package mocks

import (
	"context"

	"github.com/stretchr/testify/mock"
	"github.com/yourorg/oracle-rest-api/internal/audit"
)

// MockAuditLogger is a testify mock for audit.Logger.
type MockAuditLogger struct {
	mock.Mock
}

var _ audit.Logger = (*MockAuditLogger)(nil)

func (m *MockAuditLogger) Log(ctx context.Context, record audit.Record) error {
	return m.Called(ctx, record).Error(0)
}
