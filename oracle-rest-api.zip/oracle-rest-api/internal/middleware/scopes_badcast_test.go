package middleware_test

import (
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"

	"github.com/yourorg/oracle-rest-api/internal/middleware"
)

// TestRequireScopes_BadClaimsType ensures the 500 path is exercised when
// the value stored under ClaimsKey is not *auth.Claims.
func TestRequireScopes_BadClaimsType(t *testing.T) {
	r := gin.New()
	r.GET("/test",
		// Inject a wrong type into the context instead of using RequireAuth.
		func(c *gin.Context) {
			c.Set(middleware.ClaimsKey, "this-is-not-a-claims-struct")
			c.Next()
		},
		middleware.RequireScopes("users:read"),
		func(c *gin.Context) { c.Status(http.StatusOK) },
	)

	req := httptest.NewRequest(http.MethodGet, "/test", nil)
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)

	assert.Equal(t, http.StatusInternalServerError, w.Code)
}
