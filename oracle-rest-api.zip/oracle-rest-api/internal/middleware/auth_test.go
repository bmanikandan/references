package middleware_test

import (
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"go.uber.org/zap"

	"github.com/yourorg/oracle-rest-api/internal/middleware"
	"github.com/yourorg/oracle-rest-api/pkg/auth"
)

func init() { gin.SetMode(gin.TestMode) }

// ---------------------------------------------------------------------------
// helpers
// ---------------------------------------------------------------------------

const (
	testSecret = "auth-middleware-test-secret-key-32c"
	testIssuer = "test"
)

func newJWTService() auth.JWTService {
	return auth.NewJWTService(testSecret, testIssuer)
}

func validToken(t *testing.T, scopes []string) string {
	t.Helper()
	svc := newJWTService()
	tok, err := svc.GenerateToken("user-1", "client-a", scopes, time.Hour)
	require.NoError(t, err)
	return tok
}

func expiredToken(t *testing.T) string {
	t.Helper()
	svc := newJWTService()
	tok, err := svc.GenerateToken("user-1", "client-a", []string{"users:read"}, -time.Second)
	require.NoError(t, err)
	return tok
}

// buildRouter wires up RequireAuth (and optionally RequireScopes) with a
// trivial success handler at GET /test.
func buildRouter(jwtSvc auth.JWTService, scopes ...string) *gin.Engine {
	r := gin.New()
	mw := []gin.HandlerFunc{middleware.RequireAuth(jwtSvc, zap.NewNop())}
	if len(scopes) > 0 {
		mw = append(mw, middleware.RequireScopes(scopes...))
	}
	r.GET("/test", append(mw, func(c *gin.Context) {
		claims, ok := middleware.GetClaims(c)
		if ok {
			c.JSON(http.StatusOK, gin.H{"sub": claims.Subject})
		} else {
			c.Status(http.StatusOK)
		}
	})...)
	return r
}

func performGet(r *gin.Engine, authHeader string) *httptest.ResponseRecorder {
	req := httptest.NewRequest(http.MethodGet, "/test", nil)
	if authHeader != "" {
		req.Header.Set("Authorization", authHeader)
	}
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)
	return w
}

// ---------------------------------------------------------------------------
// RequireAuth tests
// ---------------------------------------------------------------------------

func TestRequireAuth_MissingHeader(t *testing.T) {
	r := buildRouter(newJWTService())
	w := performGet(r, "")
	assert.Equal(t, http.StatusUnauthorized, w.Code)
}

func TestRequireAuth_InvalidHeaderFormat(t *testing.T) {
	r := buildRouter(newJWTService())
	w := performGet(r, "Token sometoken")
	assert.Equal(t, http.StatusUnauthorized, w.Code)
}

func TestRequireAuth_EmptyBearerToken(t *testing.T) {
	r := buildRouter(newJWTService())
	w := performGet(r, "Bearer  ")
	assert.Equal(t, http.StatusUnauthorized, w.Code)
}

func TestRequireAuth_InvalidToken(t *testing.T) {
	r := buildRouter(newJWTService())
	w := performGet(r, "Bearer this.is.garbage")
	assert.Equal(t, http.StatusUnauthorized, w.Code)
}

func TestRequireAuth_ExpiredToken(t *testing.T) {
	r := buildRouter(newJWTService())
	w := performGet(r, "Bearer "+expiredToken(t))
	assert.Equal(t, http.StatusUnauthorized, w.Code)
}

func TestRequireAuth_WrongSigningKey(t *testing.T) {
	// Token signed with a different key.
	otherSvc := auth.NewJWTService("completely-different-secret-key-32c", testIssuer)
	tok, err := otherSvc.GenerateToken("u1", "", nil, time.Hour)
	require.NoError(t, err)

	r := buildRouter(newJWTService())
	w := performGet(r, "Bearer "+tok)
	assert.Equal(t, http.StatusUnauthorized, w.Code)
}

func TestRequireAuth_ValidToken(t *testing.T) {
	tok := validToken(t, []string{"users:read"})
	r := buildRouter(newJWTService())
	w := performGet(r, "Bearer "+tok)
	assert.Equal(t, http.StatusOK, w.Code)
}

func TestRequireAuth_ClaimsStoredInContext(t *testing.T) {
	tok := validToken(t, []string{"users:read"})
	r := buildRouter(newJWTService())
	w := performGet(r, "Bearer "+tok)
	assert.Equal(t, http.StatusOK, w.Code)
	assert.Contains(t, w.Body.String(), "user-1")
}

// ---------------------------------------------------------------------------
// RequireScopes tests
// ---------------------------------------------------------------------------

func TestRequireScopes_SufficientScopes(t *testing.T) {
	tok := validToken(t, []string{"users:read", "users:write"})
	r := buildRouter(newJWTService(), "users:read")
	w := performGet(r, "Bearer "+tok)
	assert.Equal(t, http.StatusOK, w.Code)
}

func TestRequireScopes_InsufficientScopes(t *testing.T) {
	tok := validToken(t, []string{"users:read"})
	r := buildRouter(newJWTService(), "users:write")
	w := performGet(r, "Bearer "+tok)
	assert.Equal(t, http.StatusForbidden, w.Code)
}

func TestRequireScopes_MultipleRequired_AllPresent(t *testing.T) {
	tok := validToken(t, []string{"users:read", "users:write", "users:delete"})
	r := buildRouter(newJWTService(), "users:read", "users:write")
	w := performGet(r, "Bearer "+tok)
	assert.Equal(t, http.StatusOK, w.Code)
}

func TestRequireScopes_MultipleRequired_OneMissing(t *testing.T) {
	tok := validToken(t, []string{"users:read"})
	r := buildRouter(newJWTService(), "users:read", "users:delete")
	w := performGet(r, "Bearer "+tok)
	assert.Equal(t, http.StatusForbidden, w.Code)
}

func TestRequireScopes_NoScopesRequired(t *testing.T) {
	tok := validToken(t, []string{})
	r := buildRouter(newJWTService() /* no scope args */)
	w := performGet(r, "Bearer "+tok)
	assert.Equal(t, http.StatusOK, w.Code)
}

// ---------------------------------------------------------------------------
// RequireScopes without prior RequireAuth (missing claims key)
// ---------------------------------------------------------------------------

func TestRequireScopes_NoClaims(t *testing.T) {
	r := gin.New()
	// Wire RequireScopes WITHOUT RequireAuth so claims are not in context.
	r.GET("/test", middleware.RequireScopes("users:read"), func(c *gin.Context) {
		c.Status(http.StatusOK)
	})

	req := httptest.NewRequest(http.MethodGet, "/test", nil)
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)

	assert.Equal(t, http.StatusUnauthorized, w.Code)
}

// ---------------------------------------------------------------------------
// GetClaims helper
// ---------------------------------------------------------------------------

func TestGetClaims_NotPresent(t *testing.T) {
	c, _ := gin.CreateTestContext(httptest.NewRecorder())
	claims, ok := middleware.GetClaims(c)
	assert.False(t, ok)
	assert.Nil(t, claims)
}
