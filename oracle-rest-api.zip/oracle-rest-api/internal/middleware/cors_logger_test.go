package middleware_test

import (
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"go.uber.org/zap"
	"go.uber.org/zap/zaptest"

	"github.com/yourorg/oracle-rest-api/internal/middleware"
)

// ---------------------------------------------------------------------------
// CORS middleware tests
// ---------------------------------------------------------------------------

func corsTestRouter() *gin.Engine {
	r := gin.New()
	r.Use(middleware.CORS())
	r.GET("/test", func(c *gin.Context) { c.Status(http.StatusOK) })
	r.POST("/test", func(c *gin.Context) { c.Status(http.StatusCreated) })
	return r
}

func TestCORS_HeadersOnNormalRequest(t *testing.T) {
	r := corsTestRouter()
	req := httptest.NewRequest(http.MethodGet, "/test", nil)
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)

	assert.Equal(t, http.StatusOK, w.Code)
	assert.Equal(t, "*", w.Header().Get("Access-Control-Allow-Origin"))
	assert.NotEmpty(t, w.Header().Get("Access-Control-Allow-Methods"))
	assert.NotEmpty(t, w.Header().Get("Access-Control-Allow-Headers"))
}

func TestCORS_PreflightReturns204(t *testing.T) {
	r := corsTestRouter()
	req := httptest.NewRequest(http.MethodOptions, "/test", nil)
	req.Header.Set("Origin", "https://example.com")
	req.Header.Set("Access-Control-Request-Method", "POST")
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)

	assert.Equal(t, http.StatusNoContent, w.Code)
	assert.Equal(t, "*", w.Header().Get("Access-Control-Allow-Origin"))
}

func TestCORS_MaxAgeHeader(t *testing.T) {
	r := corsTestRouter()
	req := httptest.NewRequest(http.MethodGet, "/test", nil)
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)

	assert.Equal(t, "86400", w.Header().Get("Access-Control-Max-Age"))
}

// ---------------------------------------------------------------------------
// RequestLogger middleware tests
// ---------------------------------------------------------------------------

func loggerTestRouter(logger *zap.Logger) *gin.Engine {
	r := gin.New()
	r.Use(middleware.RequestLogger(logger))
	r.GET("/ok", func(c *gin.Context) { c.Status(http.StatusOK) })
	r.GET("/warn", func(c *gin.Context) { c.Status(http.StatusBadRequest) })
	r.GET("/error", func(c *gin.Context) { c.Status(http.StatusInternalServerError) })
	return r
}

func TestRequestLogger_200(t *testing.T) {
	logger := zaptest.NewLogger(t)
	r := loggerTestRouter(logger)

	req := httptest.NewRequest(http.MethodGet, "/ok", nil)
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)

	assert.Equal(t, http.StatusOK, w.Code)
}

func TestRequestLogger_400(t *testing.T) {
	logger := zaptest.NewLogger(t)
	r := loggerTestRouter(logger)

	req := httptest.NewRequest(http.MethodGet, "/warn", nil)
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)

	assert.Equal(t, http.StatusBadRequest, w.Code)
}

func TestRequestLogger_500(t *testing.T) {
	logger := zaptest.NewLogger(t)
	r := loggerTestRouter(logger)

	req := httptest.NewRequest(http.MethodGet, "/error", nil)
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)

	assert.Equal(t, http.StatusInternalServerError, w.Code)
}

func TestRequestLogger_WithQueryString(t *testing.T) {
	logger := zaptest.NewLogger(t)
	r := loggerTestRouter(logger)

	req := httptest.NewRequest(http.MethodGet, "/ok?foo=bar&baz=qux", nil)
	req.Header.Set("User-Agent", "test-agent/1.0")
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)

	assert.Equal(t, http.StatusOK, w.Code)
}
