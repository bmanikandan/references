// Package middleware provides Gin middleware for authentication, logging, and CORS.
package middleware

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
	"github.com/yourorg/oracle-rest-api/internal/model"
	"github.com/yourorg/oracle-rest-api/pkg/auth"
	"go.uber.org/zap"
)

// ClaimsKey is the context key under which JWT claims are stored.
const ClaimsKey = "jwt_claims"

// RequireAuth validates the Bearer JWT token present in the Authorization header.
// On success it stores the parsed *auth.Claims in the Gin context under ClaimsKey.
func RequireAuth(jwtSvc auth.JWTService, logger *zap.Logger) gin.HandlerFunc {
	return func(c *gin.Context) {
		authHeader := c.GetHeader("Authorization")
		tokenString, err := auth.ExtractBearerToken(authHeader)
		if err != nil {
			logger.Warn("auth: bearer token extraction failed", zap.Error(err))
			c.AbortWithStatusJSON(http.StatusUnauthorized, model.NewErrorResponse(
				"UNAUTHORIZED", "Authentication required", err.Error(),
			))
			return
		}

		claims, err := jwtSvc.ValidateToken(tokenString)
		if err != nil {
			code := "INVALID_TOKEN"
			msg := "Invalid token"
			if err == auth.ErrTokenExpired {
				code = "TOKEN_EXPIRED"
				msg = "Token has expired"
			}
			logger.Warn("auth: token validation failed", zap.String("code", code), zap.Error(err))
			c.AbortWithStatusJSON(http.StatusUnauthorized, model.NewErrorResponse(code, msg, ""))
			return
		}

		c.Set(ClaimsKey, claims)
		c.Next()
	}
}

// RequireScopes returns a middleware that asserts the authenticated principal has
// all of the listed scopes. Must be chained after RequireAuth.
func RequireScopes(requiredScopes ...string) gin.HandlerFunc {
	return func(c *gin.Context) {
		raw, exists := c.Get(ClaimsKey)
		if !exists {
			c.AbortWithStatusJSON(http.StatusUnauthorized, model.NewErrorResponse(
				"UNAUTHORIZED", "Authentication required", "no claims in context",
			))
			return
		}

		claims, ok := raw.(*auth.Claims)
		if !ok {
			c.AbortWithStatusJSON(http.StatusInternalServerError, model.NewErrorResponse(
				"INTERNAL_ERROR", "Internal server error", "failed to cast claims",
			))
			return
		}

		if !auth.HasAllScopes(claims, requiredScopes) {
			c.AbortWithStatusJSON(http.StatusForbidden, model.NewErrorResponse(
				"FORBIDDEN",
				"Insufficient permissions",
				"required scopes: "+strings.Join(requiredScopes, ", "),
			))
			return
		}

		c.Next()
	}
}

// GetClaims is a convenience helper that retrieves *auth.Claims from a Gin context.
func GetClaims(c *gin.Context) (*auth.Claims, bool) {
	raw, exists := c.Get(ClaimsKey)
	if !exists {
		return nil, false
	}
	claims, ok := raw.(*auth.Claims)
	return claims, ok
}
