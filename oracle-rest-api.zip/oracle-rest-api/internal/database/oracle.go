// Package database provides Oracle database connectivity using the go-ora pure-Go driver.
package database

import (
	"database/sql"
	"fmt"
	"time"

	// Register the Oracle driver.
	_ "github.com/sijms/go-ora/v2"
	"github.com/yourorg/oracle-rest-api/internal/config"
)

// NewOracleDB opens and configures an Oracle connection pool.
// The caller is responsible for calling db.Close() when done.
func NewOracleDB(cfg *config.DatabaseConfig) (*sql.DB, error) {
	db, err := sql.Open("oracle", cfg.DSN())
	if err != nil {
		return nil, fmt.Errorf("failed to open oracle connection: %w", err)
	}

	db.SetMaxOpenConns(cfg.MaxOpen)
	db.SetMaxIdleConns(cfg.MaxIdle)
	db.SetConnMaxLifetime(5 * time.Minute)
	db.SetConnMaxIdleTime(2 * time.Minute)

	if err := db.Ping(); err != nil {
		_ = db.Close()
		return nil, fmt.Errorf("failed to ping oracle database: %w", err)
	}

	return db, nil
}
