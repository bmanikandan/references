package cache_test

import (
	"context"
	"errors"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/yourorg/oracle-rest-api/internal/cache"
)

// ---------------------------------------------------------------------------
// Mock — used to test consumer code that depends on CacheStore
// ---------------------------------------------------------------------------

type mockCache struct{ mock.Mock }

func (m *mockCache) Get(ctx context.Context, key string) ([]byte, error) {
	args := m.Called(ctx, key)
	b, _ := args.Get(0).([]byte)
	return b, args.Error(1)
}
func (m *mockCache) Set(ctx context.Context, key string, value []byte, ttl time.Duration) error {
	return m.Called(ctx, key, value, ttl).Error(0)
}
func (m *mockCache) Delete(ctx context.Context, keys ...string) error {
	args := make([]interface{}, len(keys)+1)
	args[0] = ctx
	for i, k := range keys {
		args[i+1] = k
	}
	return m.Called(args...).Error(0)
}
func (m *mockCache) FlushByPattern(ctx context.Context, pattern string) error {
	return m.Called(ctx, pattern).Error(0)
}

// ---------------------------------------------------------------------------
// ErrCacheMiss sentinel
// ---------------------------------------------------------------------------

func TestErrCacheMiss_IsSentinel(t *testing.T) {
	var target = cache.ErrCacheMiss
	assert.True(t, errors.Is(target, cache.ErrCacheMiss))
	assert.EqualError(t, target, "cache miss")
}

// ---------------------------------------------------------------------------
// CacheStore interface contract — tested via mock
// ---------------------------------------------------------------------------

func TestCacheStore_GetMiss(t *testing.T) {
	m := &mockCache{}
	m.On("Get", mock.Anything, "no-such-key").Return(nil, cache.ErrCacheMiss)

	_, err := m.Get(context.Background(), "no-such-key")
	assert.ErrorIs(t, err, cache.ErrCacheMiss)
}

func TestCacheStore_GetHit(t *testing.T) {
	m := &mockCache{}
	m.On("Get", mock.Anything, "my-key").Return([]byte(`{"ok":true}`), nil)

	data, err := m.Get(context.Background(), "my-key")
	assert.NoError(t, err)
	assert.Equal(t, []byte(`{"ok":true}`), data)
}

func TestCacheStore_Set(t *testing.T) {
	m := &mockCache{}
	m.On("Set", mock.Anything, "my-key", []byte("val"), 5*time.Minute).Return(nil)

	err := m.Set(context.Background(), "my-key", []byte("val"), 5*time.Minute)
	assert.NoError(t, err)
}

func TestCacheStore_Set_Error(t *testing.T) {
	m := &mockCache{}
	m.On("Set", mock.Anything, "bad-key", mock.Anything, mock.Anything).Return(errors.New("redis down"))

	err := m.Set(context.Background(), "bad-key", []byte("val"), time.Minute)
	assert.ErrorContains(t, err, "redis down")
}

func TestCacheStore_Delete(t *testing.T) {
	m := &mockCache{}
	m.On("Delete", mock.Anything, "k1", "k2").Return(nil)

	err := m.Delete(context.Background(), "k1", "k2")
	assert.NoError(t, err)
}

func TestCacheStore_FlushByPattern(t *testing.T) {
	m := &mockCache{}
	m.On("FlushByPattern", mock.Anything, "api:users:list:*").Return(nil)

	err := m.FlushByPattern(context.Background(), "api:users:list:*")
	assert.NoError(t, err)
}

func TestCacheStore_FlushByPattern_Error(t *testing.T) {
	m := &mockCache{}
	m.On("FlushByPattern", mock.Anything, "api:users:*").Return(errors.New("scan error"))

	err := m.FlushByPattern(context.Background(), "api:users:*")
	assert.ErrorContains(t, err, "scan error")
}
