// Package cache defines caching abstractions and provides a Redis-backed implementation.
// GET endpoints use the cache to avoid repeated Oracle queries; write operations
// actively invalidate the affected keys.
package cache

import (
	"context"
	"errors"
	"time"
)

// ErrCacheMiss is returned by Get when the requested key does not exist.
var ErrCacheMiss = errors.New("cache miss")

// CacheStore is the interface that wraps basic cache operations.
type CacheStore interface {
	// Get retrieves the value for key. Returns ErrCacheMiss when the key is absent.
	Get(ctx context.Context, key string) ([]byte, error)
	// Set stores value under key with the given TTL.
	Set(ctx context.Context, key string, value []byte, ttl time.Duration) error
	// Delete removes one or more keys.
	Delete(ctx context.Context, keys ...string) error
	// FlushByPattern deletes all keys whose name matches the glob pattern
	// using a cursor-based SCAN to avoid blocking the Redis server.
	FlushByPattern(ctx context.Context, pattern string) error
}
