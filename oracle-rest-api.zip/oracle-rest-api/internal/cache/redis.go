package cache

import (
	"context"
	"errors"
	"fmt"
	"time"

	"github.com/redis/go-redis/v9"
	"github.com/yourorg/oracle-rest-api/internal/config"
)

type redisCache struct {
	client *redis.Client
}

// NewRedisCache creates a Redis-backed CacheStore and verifies connectivity.
func NewRedisCache(cfg *config.RedisConfig) (CacheStore, error) {
	client := redis.NewClient(&redis.Options{
		Addr:     cfg.Addr(),
		Password: cfg.Password,
		DB:       cfg.DB,
	})

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	if err := client.Ping(ctx).Err(); err != nil {
		return nil, fmt.Errorf("redis ping failed: %w", err)
	}
	return &redisCache{client: client}, nil
}

// Get retrieves a cached value by key.
func (r *redisCache) Get(ctx context.Context, key string) ([]byte, error) {
	val, err := r.client.Get(ctx, key).Bytes()
	if err != nil {
		if errors.Is(err, redis.Nil) {
			return nil, ErrCacheMiss
		}
		return nil, fmt.Errorf("redis get %q: %w", key, err)
	}
	return val, nil
}

// Set stores a value with the specified TTL. A zero TTL means no expiration.
func (r *redisCache) Set(ctx context.Context, key string, value []byte, ttl time.Duration) error {
	if err := r.client.Set(ctx, key, value, ttl).Err(); err != nil {
		return fmt.Errorf("redis set %q: %w", key, err)
	}
	return nil
}

// Delete removes one or more keys atomically.
func (r *redisCache) Delete(ctx context.Context, keys ...string) error {
	if len(keys) == 0 {
		return nil
	}
	if err := r.client.Del(ctx, keys...).Err(); err != nil {
		return fmt.Errorf("redis del %v: %w", keys, err)
	}
	return nil
}

// FlushByPattern deletes all keys matching the given glob pattern using
// an incremental SCAN loop (safe for large key spaces).
func (r *redisCache) FlushByPattern(ctx context.Context, pattern string) error {
	var (
		cursor uint64
		keys   []string
	)
	for {
		batch, nextCursor, err := r.client.Scan(ctx, cursor, pattern, 100).Result()
		if err != nil {
			return fmt.Errorf("redis scan pattern %q: %w", pattern, err)
		}
		keys = append(keys, batch...)
		cursor = nextCursor
		if cursor == 0 {
			break
		}
	}
	if len(keys) == 0 {
		return nil
	}
	if err := r.client.Del(ctx, keys...).Err(); err != nil {
		return fmt.Errorf("redis del scanned keys: %w", err)
	}
	return nil
}
