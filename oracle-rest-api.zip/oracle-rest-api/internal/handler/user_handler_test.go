package handler_test

import (
	"bytes"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"
	"go.uber.org/zap"

	"github.com/yourorg/oracle-rest-api/internal/cache"
	"github.com/yourorg/oracle-rest-api/internal/handler"
	"github.com/yourorg/oracle-rest-api/internal/mocks"
	"github.com/yourorg/oracle-rest-api/internal/model"
	"github.com/yourorg/oracle-rest-api/internal/service"
)

func init() { gin.SetMode(gin.TestMode) }

// ─── helpers ──────────────────────────────────────────────────────────────

type deps struct {
	svc      *mocks.MockUserService
	cs       *mocks.MockCacheStore
	al       *mocks.MockAuditLogger
	producer *mocks.MockEventProducer
	h        *handler.UserHandler
}

func newDeps() deps {
	svc := &mocks.MockUserService{}
	cs := &mocks.MockCacheStore{}
	al := &mocks.MockAuditLogger{}
	ep := &mocks.MockEventProducer{}
	h := handler.NewUserHandler(svc, cs, al, ep, zap.NewNop())
	return deps{svc, cs, al, ep, h}
}

func newRouter(h *handler.UserHandler) *gin.Engine {
	r := gin.New()
	v1 := r.Group("/api/v1")
	v1.GET("/users", h.ListUsers)
	v1.GET("/users/:id", h.GetUser)
	v1.POST("/users", h.CreateUser)
	v1.PUT("/users/:id", h.UpdateUser)
	v1.DELETE("/users/:id", h.DeleteUser)
	return r
}

func doRequest(r *gin.Engine, method, path string, body interface{}) *httptest.ResponseRecorder {
	var buf bytes.Buffer
	if body != nil {
		_ = json.NewEncoder(&buf).Encode(body)
	}
	req := httptest.NewRequest(method, path, &buf)
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("X-Request-ID", "test-request-id")
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)
	return w
}

func sampleUser(id string) model.User {
	return model.User{
		ID: id, Name: "Alice", Email: "alice@example.com",
		Role: "user", Status: "active",
		CreatedAt: time.Now().UTC(), UpdatedAt: time.Now().UTC(),
	}
}

// cacheMiss returns a mock.Call chain that simulates a Redis cache miss.
func (d *deps) cacheMiss(key string) {
	d.cs.On("Get", mock.Anything, key).Return(nil, cache.ErrCacheMiss)
}
func (d *deps) cacheSetOK() {
	d.cs.On("Set", mock.Anything, mock.AnythingOfType("string"), mock.Anything, mock.AnythingOfType("time.Duration")).Return(nil)
}
func (d *deps) flushListOK() {
	d.cs.On("FlushByPattern", mock.Anything, "api:users:list:*").Return(nil)
}
func (d *deps) deleteUserKeyOK(id string) {
	d.cs.On("Delete", mock.Anything, "api:user:"+id).Return(nil)
}
func (d *deps) auditOK() {
	d.al.On("Log", mock.Anything, mock.AnythingOfType("audit.Record")).Return(nil)
}
func (d *deps) publishOK() {
	d.producer.On("Publish", mock.Anything, mock.AnythingOfType("messaging.Event")).Return(nil)
}

// ─── ListUsers ────────────────────────────────────────────────────────────

func TestListUsers_CacheHit(t *testing.T) {
	d := newDeps()
	r := newRouter(d.h)

	filter := model.UserFilter{Page: 1, Limit: 10}
	expectedResp := model.NewPaginatedResponse([]model.User{sampleUser("1")}, 1, 10, 1)
	raw, _ := json.Marshal(expectedResp)

	d.cs.On("Get", mock.Anything, "api:users:list:p1:l10:s:r").Return(raw, nil)

	w := doRequest(r, http.MethodGet, "/api/v1/users", nil)

	assert.Equal(t, http.StatusOK, w.Code)
	assert.Equal(t, "HIT", w.Header().Get("X-Cache"))
	_ = filter
}

func TestListUsers_CacheMissSuccess(t *testing.T) {
	d := newDeps()
	r := newRouter(d.h)
	users := []model.User{sampleUser("1"), sampleUser("2")}

	d.cs.On("Get", mock.Anything, "api:users:list:p1:l10:s:r").Return(nil, cache.ErrCacheMiss)
	d.svc.On("GetUsers", mock.Anything, model.UserFilter{Page: 1, Limit: 10}).Return(users, int64(2), nil)
	d.cacheSetOK()

	w := doRequest(r, http.MethodGet, "/api/v1/users", nil)

	assert.Equal(t, http.StatusOK, w.Code)
	assert.Equal(t, "MISS", w.Header().Get("X-Cache"))
	var resp model.PaginatedResponse
	require.NoError(t, json.Unmarshal(w.Body.Bytes(), &resp))
	assert.Equal(t, int64(2), resp.Pagination.Total)
}

func TestListUsers_ServiceError(t *testing.T) {
	d := newDeps()
	r := newRouter(d.h)

	d.cs.On("Get", mock.Anything, mock.AnythingOfType("string")).Return(nil, cache.ErrCacheMiss)
	d.svc.On("GetUsers", mock.Anything, mock.AnythingOfType("model.UserFilter")).Return(nil, int64(0), errors.New("db error"))

	w := doRequest(r, http.MethodGet, "/api/v1/users", nil)
	assert.Equal(t, http.StatusInternalServerError, w.Code)
}

// ─── GetUser ──────────────────────────────────────────────────────────────

func TestGetUser_CacheHit(t *testing.T) {
	d := newDeps()
	r := newRouter(d.h)

	u := sampleUser("uuid-1")
	raw, _ := json.Marshal(u)
	d.cs.On("Get", mock.Anything, "api:user:uuid-1").Return(raw, nil)

	w := doRequest(r, http.MethodGet, "/api/v1/users/uuid-1", nil)

	assert.Equal(t, http.StatusOK, w.Code)
	assert.Equal(t, "HIT", w.Header().Get("X-Cache"))
}

func TestGetUser_CacheMissSuccess(t *testing.T) {
	d := newDeps()
	r := newRouter(d.h)
	u := sampleUser("uuid-1")

	d.cs.On("Get", mock.Anything, "api:user:uuid-1").Return(nil, cache.ErrCacheMiss)
	d.svc.On("GetUserByID", mock.Anything, "uuid-1").Return(&u, nil)
	d.cacheSetOK()

	w := doRequest(r, http.MethodGet, "/api/v1/users/uuid-1", nil)

	assert.Equal(t, http.StatusOK, w.Code)
	assert.Equal(t, "MISS", w.Header().Get("X-Cache"))
}

func TestGetUser_NotFound(t *testing.T) {
	d := newDeps()
	r := newRouter(d.h)

	d.cs.On("Get", mock.Anything, "api:user:missing").Return(nil, cache.ErrCacheMiss)
	d.svc.On("GetUserByID", mock.Anything, "missing").Return(nil, service.ErrNotFound)

	w := doRequest(r, http.MethodGet, "/api/v1/users/missing", nil)
	assert.Equal(t, http.StatusNotFound, w.Code)
}

func TestGetUser_InternalError(t *testing.T) {
	d := newDeps()
	r := newRouter(d.h)

	d.cs.On("Get", mock.Anything, "api:user:id-1").Return(nil, cache.ErrCacheMiss)
	d.svc.On("GetUserByID", mock.Anything, "id-1").Return(nil, errors.New("db error"))

	w := doRequest(r, http.MethodGet, "/api/v1/users/id-1", nil)
	assert.Equal(t, http.StatusInternalServerError, w.Code)
}

// ─── CreateUser ───────────────────────────────────────────────────────────

func TestCreateUser_Success(t *testing.T) {
	d := newDeps()
	r := newRouter(d.h)

	req := model.CreateUserRequest{Name: "Bob", Email: "bob@example.com", Role: "user"}
	created := sampleUser("new-uuid")
	d.svc.On("CreateUser", mock.Anything, req).Return(&created, nil)
	d.flushListOK()
	d.publishOK()
	d.auditOK()

	w := doRequest(r, http.MethodPost, "/api/v1/users", req)
	assert.Equal(t, http.StatusCreated, w.Code)
}

func TestCreateUser_ValidationError(t *testing.T) {
	d := newDeps()
	r := newRouter(d.h)

	w := doRequest(r, http.MethodPost, "/api/v1/users", map[string]string{"email": "bad"})
	assert.Equal(t, http.StatusBadRequest, w.Code)
}

func TestCreateUser_EmailConflict(t *testing.T) {
	d := newDeps()
	r := newRouter(d.h)

	req := model.CreateUserRequest{Name: "Bob", Email: "taken@example.com"}
	d.svc.On("CreateUser", mock.Anything, req).Return(nil, service.ErrEmailExists)

	w := doRequest(r, http.MethodPost, "/api/v1/users", req)
	assert.Equal(t, http.StatusConflict, w.Code)
}

func TestCreateUser_InternalError(t *testing.T) {
	d := newDeps()
	r := newRouter(d.h)

	req := model.CreateUserRequest{Name: "Bob", Email: "bob@example.com"}
	d.svc.On("CreateUser", mock.Anything, req).Return(nil, errors.New("db error"))

	w := doRequest(r, http.MethodPost, "/api/v1/users", req)
	assert.Equal(t, http.StatusInternalServerError, w.Code)
}

func TestCreateUser_InvalidJSON(t *testing.T) {
	d := newDeps()
	r := newRouter(d.h)

	req := httptest.NewRequest(http.MethodPost, "/api/v1/users", bytes.NewBufferString("{bad json}"))
	req.Header.Set("Content-Type", "application/json")
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)

	assert.Equal(t, http.StatusBadRequest, w.Code)
}

// ─── UpdateUser ───────────────────────────────────────────────────────────

func TestUpdateUser_Success(t *testing.T) {
	d := newDeps()
	r := newRouter(d.h)

	req := model.UpdateUserRequest{Name: "Alice Updated"}
	updated := sampleUser("id-1")
	updated.Name = "Alice Updated"
	d.svc.On("UpdateUser", mock.Anything, "id-1", req).Return(&updated, nil)
	d.deleteUserKeyOK("id-1")
	d.flushListOK()
	d.publishOK()
	d.auditOK()

	w := doRequest(r, http.MethodPut, "/api/v1/users/id-1", req)
	assert.Equal(t, http.StatusOK, w.Code)
}

func TestUpdateUser_NotFound(t *testing.T) {
	d := newDeps()
	r := newRouter(d.h)

	req := model.UpdateUserRequest{Name: "X"}
	d.svc.On("UpdateUser", mock.Anything, "bad", req).Return(nil, service.ErrNotFound)

	w := doRequest(r, http.MethodPut, "/api/v1/users/bad", req)
	assert.Equal(t, http.StatusNotFound, w.Code)
}

func TestUpdateUser_EmailConflict(t *testing.T) {
	d := newDeps()
	r := newRouter(d.h)

	req := model.UpdateUserRequest{Email: "taken@example.com"}
	d.svc.On("UpdateUser", mock.Anything, "id-1", req).Return(nil, service.ErrEmailExists)

	w := doRequest(r, http.MethodPut, "/api/v1/users/id-1", req)
	assert.Equal(t, http.StatusConflict, w.Code)
}

func TestUpdateUser_InternalError(t *testing.T) {
	d := newDeps()
	r := newRouter(d.h)

	req := model.UpdateUserRequest{Name: "X"}
	d.svc.On("UpdateUser", mock.Anything, "id-1", req).Return(nil, errors.New("db error"))

	w := doRequest(r, http.MethodPut, "/api/v1/users/id-1", req)
	assert.Equal(t, http.StatusInternalServerError, w.Code)
}

func TestUpdateUser_ValidationError(t *testing.T) {
	d := newDeps()
	r := newRouter(d.h)

	w := doRequest(r, http.MethodPut, "/api/v1/users/id-1", map[string]string{"role": "superuser"})
	assert.Equal(t, http.StatusBadRequest, w.Code)
}

// ─── DeleteUser ───────────────────────────────────────────────────────────

func TestDeleteUser_Success(t *testing.T) {
	d := newDeps()
	r := newRouter(d.h)

	d.svc.On("DeleteUser", mock.Anything, "id-1").Return(nil)
	d.deleteUserKeyOK("id-1")
	d.flushListOK()
	d.publishOK()
	d.auditOK()

	w := doRequest(r, http.MethodDelete, "/api/v1/users/id-1", nil)
	assert.Equal(t, http.StatusOK, w.Code)
}

func TestDeleteUser_NotFound(t *testing.T) {
	d := newDeps()
	r := newRouter(d.h)

	d.svc.On("DeleteUser", mock.Anything, "bad").Return(service.ErrNotFound)

	w := doRequest(r, http.MethodDelete, "/api/v1/users/bad", nil)
	assert.Equal(t, http.StatusNotFound, w.Code)
}

func TestDeleteUser_InternalError(t *testing.T) {
	d := newDeps()
	r := newRouter(d.h)

	d.svc.On("DeleteUser", mock.Anything, "id-1").Return(errors.New("db error"))

	w := doRequest(r, http.MethodDelete, "/api/v1/users/id-1", nil)
	assert.Equal(t, http.StatusInternalServerError, w.Code)
}

// ─── Cache error paths (best-effort — should not affect HTTP status) ──────

func TestCreateUser_CacheFlushError_StillReturns201(t *testing.T) {
	d := newDeps()
	r := newRouter(d.h)

	req := model.CreateUserRequest{Name: "Bob", Email: "bob@example.com"}
	created := sampleUser("new-uuid")
	d.svc.On("CreateUser", mock.Anything, req).Return(&created, nil)
	d.cs.On("FlushByPattern", mock.Anything, "api:users:list:*").Return(errors.New("redis down"))
	d.publishOK()
	d.auditOK()

	w := doRequest(r, http.MethodPost, "/api/v1/users", req)
	assert.Equal(t, http.StatusCreated, w.Code)
}

func TestUpdateUser_CacheDeleteError_StillReturns200(t *testing.T) {
	d := newDeps()
	r := newRouter(d.h)

	req := model.UpdateUserRequest{Name: "New Name"}
	updated := sampleUser("id-1")
	d.svc.On("UpdateUser", mock.Anything, "id-1", req).Return(&updated, nil)
	d.cs.On("Delete", mock.Anything, "api:user:id-1").Return(errors.New("redis down"))
	d.flushListOK()
	d.publishOK()
	d.auditOK()

	w := doRequest(r, http.MethodPut, "/api/v1/users/id-1", req)
	assert.Equal(t, http.StatusOK, w.Code)
}

func TestGetUser_CacheSetError_StillReturns200(t *testing.T) {
	d := newDeps()
	r := newRouter(d.h)
	u := sampleUser("uuid-1")

	d.cs.On("Get", mock.Anything, "api:user:uuid-1").Return(nil, cache.ErrCacheMiss)
	d.svc.On("GetUserByID", mock.Anything, "uuid-1").Return(&u, nil)
	d.cs.On("Set", mock.Anything, mock.AnythingOfType("string"), mock.Anything, mock.AnythingOfType("time.Duration")).Return(errors.New("redis down"))

	w := doRequest(r, http.MethodGet, "/api/v1/users/uuid-1", nil)
	assert.Equal(t, http.StatusOK, w.Code)
}
