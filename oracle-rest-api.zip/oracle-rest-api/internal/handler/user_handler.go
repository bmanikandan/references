// Package handler provides HTTP handler functions for the REST API.
package handler

import (
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"go.uber.org/zap"

	"github.com/yourorg/oracle-rest-api/internal/audit"
	"github.com/yourorg/oracle-rest-api/internal/cache"
	"github.com/yourorg/oracle-rest-api/internal/messaging"
	"github.com/yourorg/oracle-rest-api/internal/middleware"
	"github.com/yourorg/oracle-rest-api/internal/model"
	"github.com/yourorg/oracle-rest-api/internal/service"
)

const (
	userCacheKeyFmt      = "api:user:%s"
	userListCachePattern = "api:users:list:*"
)

// UserHandler handles all user-related HTTP requests.
type UserHandler struct {
	svc          service.UserService
	cache        cache.CacheStore
	audit        audit.Logger
	producer     messaging.EventProducer
	logger       *zap.Logger
	userCacheTTL time.Duration
	listCacheTTL time.Duration
}

// NewUserHandler creates a UserHandler with all four dependencies.
func NewUserHandler(
	svc service.UserService,
	cs cache.CacheStore,
	al audit.Logger,
	ep messaging.EventProducer,
	logger *zap.Logger,
) *UserHandler {
	return &UserHandler{
		svc:          svc,
		cache:        cs,
		audit:        al,
		producer:     ep,
		logger:       logger,
		userCacheTTL: 10 * time.Minute,
		listCacheTTL: 1 * time.Minute,
	}
}

// ListUsers godoc
// @Summary      List users
// @Description  Returns a paginated list of users. Results are cached in Redis. Requires scope users:read.
// @Tags         users
// @Produce      json
// @Security     BearerAuth
// @Param        page    query     int     false  "Page number"
// @Param        limit   query     int     false  "Items per page"
// @Param        status  query     string  false  "Filter: active|inactive"
// @Param        role    query     string  false  "Filter: admin|user|viewer"
// @Success      200     {object}  model.PaginatedResponse
// @Failure      400     {object}  model.Response
// @Failure      401     {object}  model.Response
// @Failure      403     {object}  model.Response
// @Failure      500     {object}  model.Response
// @Router       /users [get]
func (h *UserHandler) ListUsers(c *gin.Context) {
	var filter model.UserFilter
	if err := c.ShouldBindQuery(&filter); err != nil {
		c.JSON(http.StatusBadRequest, model.NewErrorResponse("INVALID_QUERY", "Invalid query parameters", err.Error()))
		return
	}
	filter.Validate()

	cacheKey := userListKey(filter)

	// Redis HIT
	if raw, err := h.cache.Get(c.Request.Context(), cacheKey); err == nil {
		var cached model.PaginatedResponse
		if json.Unmarshal(raw, &cached) == nil {
			c.Header("X-Cache", "HIT")
			c.JSON(http.StatusOK, cached)
			return
		}
	}

	users, total, err := h.svc.GetUsers(c.Request.Context(), filter)
	if err != nil {
		h.logger.Error("list users", zap.Error(err))
		c.JSON(http.StatusInternalServerError, model.NewErrorResponse("INTERNAL_ERROR", "Failed to retrieve users", ""))
		return
	}

	resp := model.NewPaginatedResponse(users, filter.Page, filter.Limit, total)

	// Populate cache (best-effort)
	if data, mErr := json.Marshal(resp); mErr == nil {
		if sErr := h.cache.Set(c.Request.Context(), cacheKey, data, h.listCacheTTL); sErr != nil {
			h.logger.Warn("list users: cache set failed", zap.Error(sErr))
		}
	}

	c.Header("X-Cache", "MISS")
	c.JSON(http.StatusOK, resp)
}

// GetUser godoc
// @Summary      Get user by ID
// @Description  Returns a single user by ID. Result is cached in Redis. Requires scope users:read.
// @Tags         users
// @Produce      json
// @Security     BearerAuth
// @Param        id   path      string  true  "User ID"
// @Success      200  {object}  model.Response{data=model.User}
// @Failure      401  {object}  model.Response
// @Failure      403  {object}  model.Response
// @Failure      404  {object}  model.Response
// @Failure      500  {object}  model.Response
// @Router       /users/{id} [get]
func (h *UserHandler) GetUser(c *gin.Context) {
	id := c.Param("id")
	if id == "" {
		c.JSON(http.StatusBadRequest, model.NewErrorResponse("BAD_REQUEST", "User ID is required", ""))
		return
	}

	cacheKey := fmt.Sprintf(userCacheKeyFmt, id)

	// Redis HIT
	if raw, err := h.cache.Get(c.Request.Context(), cacheKey); err == nil {
		var user model.User
		if json.Unmarshal(raw, &user) == nil {
			c.Header("X-Cache", "HIT")
			c.JSON(http.StatusOK, model.NewSuccessResponse("User retrieved successfully", &user))
			return
		}
	}

	user, err := h.svc.GetUserByID(c.Request.Context(), id)
	if err != nil {
		if errors.Is(err, service.ErrNotFound) {
			c.JSON(http.StatusNotFound, model.NewErrorResponse("NOT_FOUND", "User not found", ""))
			return
		}
		h.logger.Error("get user", zap.String("id", id), zap.Error(err))
		c.JSON(http.StatusInternalServerError, model.NewErrorResponse("INTERNAL_ERROR", "Failed to retrieve user", ""))
		return
	}

	// Populate cache (best-effort)
	if data, mErr := json.Marshal(user); mErr == nil {
		if sErr := h.cache.Set(c.Request.Context(), cacheKey, data, h.userCacheTTL); sErr != nil {
			h.logger.Warn("get user: cache set failed", zap.Error(sErr))
		}
	}

	c.Header("X-Cache", "MISS")
	c.JSON(http.StatusOK, model.NewSuccessResponse("User retrieved successfully", user))
}

// CreateUser godoc
// @Summary      Create user
// @Description  Creates a new user. Audited to MongoDB. Publishes user.created Kafka event. Requires scope users:write.
// @Tags         users
// @Accept       json
// @Produce      json
// @Security     BearerAuth
// @Param        body  body      model.CreateUserRequest  true  "User payload"
// @Success      201   {object}  model.Response{data=model.User}
// @Failure      400   {object}  model.Response
// @Failure      401   {object}  model.Response
// @Failure      403   {object}  model.Response
// @Failure      409   {object}  model.Response
// @Failure      500   {object}  model.Response
// @Router       /users [post]
func (h *UserHandler) CreateUser(c *gin.Context) {
	start := time.Now()

	var req model.CreateUserRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, model.NewErrorResponse("VALIDATION_ERROR", "Invalid request body", err.Error()))
		return
	}

	user, err := h.svc.CreateUser(c.Request.Context(), req)
	if err != nil {
		if errors.Is(err, service.ErrEmailExists) {
			c.JSON(http.StatusConflict, model.NewErrorResponse("CONFLICT", "Email address already in use", ""))
			return
		}
		h.logger.Error("create user", zap.Error(err))
		c.JSON(http.StatusInternalServerError, model.NewErrorResponse("INTERNAL_ERROR", "Failed to create user", ""))
		return
	}

	resp := model.NewSuccessResponse("User created successfully", user)
	c.JSON(http.StatusCreated, resp)

	h.invalidateListCache(c)
	h.emitEvent(c, messaging.EventUserCreated, user.ID, user)
	h.logAudit(c, start, req, resp, http.StatusCreated, user.ID)
}

// UpdateUser godoc
// @Summary      Update user
// @Description  Applies a partial update. Invalidates Redis cache. Audited to MongoDB. Publishes user.updated Kafka event. Requires scope users:write.
// @Tags         users
// @Accept       json
// @Produce      json
// @Security     BearerAuth
// @Param        id    path      string                  true  "User ID"
// @Param        body  body      model.UpdateUserRequest true  "Fields to update"
// @Success      200   {object}  model.Response{data=model.User}
// @Failure      400   {object}  model.Response
// @Failure      401   {object}  model.Response
// @Failure      403   {object}  model.Response
// @Failure      404   {object}  model.Response
// @Failure      409   {object}  model.Response
// @Failure      500   {object}  model.Response
// @Router       /users/{id} [put]
func (h *UserHandler) UpdateUser(c *gin.Context) {
	start := time.Now()
	id := c.Param("id")
	if id == "" {
		c.JSON(http.StatusBadRequest, model.NewErrorResponse("BAD_REQUEST", "User ID is required", ""))
		return
	}

	var req model.UpdateUserRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, model.NewErrorResponse("VALIDATION_ERROR", "Invalid request body", err.Error()))
		return
	}

	user, err := h.svc.UpdateUser(c.Request.Context(), id, req)
	if err != nil {
		switch {
		case errors.Is(err, service.ErrNotFound):
			c.JSON(http.StatusNotFound, model.NewErrorResponse("NOT_FOUND", "User not found", ""))
		case errors.Is(err, service.ErrEmailExists):
			c.JSON(http.StatusConflict, model.NewErrorResponse("CONFLICT", "Email address already in use", ""))
		default:
			h.logger.Error("update user", zap.String("id", id), zap.Error(err))
			c.JSON(http.StatusInternalServerError, model.NewErrorResponse("INTERNAL_ERROR", "Failed to update user", ""))
		}
		return
	}

	resp := model.NewSuccessResponse("User updated successfully", user)
	c.JSON(http.StatusOK, resp)

	h.invalidateUserCache(c, id)
	h.invalidateListCache(c)
	h.emitEvent(c, messaging.EventUserUpdated, id, user)
	h.logAudit(c, start, req, resp, http.StatusOK, id)
}

// DeleteUser godoc
// @Summary      Delete user
// @Description  Permanently removes a user. Invalidates Redis cache. Audited to MongoDB. Publishes user.deleted Kafka event. Requires scope users:delete.
// @Tags         users
// @Produce      json
// @Security     BearerAuth
// @Param        id   path      string  true  "User ID"
// @Success      200  {object}  model.Response
// @Failure      401  {object}  model.Response
// @Failure      403  {object}  model.Response
// @Failure      404  {object}  model.Response
// @Failure      500  {object}  model.Response
// @Router       /users/{id} [delete]
func (h *UserHandler) DeleteUser(c *gin.Context) {
	start := time.Now()
	id := c.Param("id")
	if id == "" {
		c.JSON(http.StatusBadRequest, model.NewErrorResponse("BAD_REQUEST", "User ID is required", ""))
		return
	}

	if err := h.svc.DeleteUser(c.Request.Context(), id); err != nil {
		if errors.Is(err, service.ErrNotFound) {
			c.JSON(http.StatusNotFound, model.NewErrorResponse("NOT_FOUND", "User not found", ""))
			return
		}
		h.logger.Error("delete user", zap.String("id", id), zap.Error(err))
		c.JSON(http.StatusInternalServerError, model.NewErrorResponse("INTERNAL_ERROR", "Failed to delete user", ""))
		return
	}

	resp := model.NewSuccessResponse("User deleted successfully", nil)
	c.JSON(http.StatusOK, resp)

	h.invalidateUserCache(c, id)
	h.invalidateListCache(c)
	h.emitEvent(c, messaging.EventUserDeleted, id, nil)
	h.logAudit(c, start, nil, resp, http.StatusOK, id)
}

// ── helpers ──────────────────────────────────────────────────────────────

func userListKey(f model.UserFilter) string {
	return fmt.Sprintf("api:users:list:p%d:l%d:s%s:r%s", f.Page, f.Limit, f.Status, f.Role)
}

func (h *UserHandler) invalidateUserCache(c *gin.Context, id string) {
	key := fmt.Sprintf(userCacheKeyFmt, id)
	if err := h.cache.Delete(c.Request.Context(), key); err != nil {
		h.logger.Warn("cache: delete user key failed", zap.String("key", key), zap.Error(err))
	}
}

func (h *UserHandler) invalidateListCache(c *gin.Context) {
	if err := h.cache.FlushByPattern(c.Request.Context(), userListCachePattern); err != nil {
		h.logger.Warn("cache: flush list pattern failed", zap.Error(err))
	}
}

func (h *UserHandler) emitEvent(c *gin.Context, eventType, targetID string, payload interface{}) {
	claims, _ := middleware.GetClaims(c)
	actorID := ""
	if claims != nil {
		actorID = claims.Subject
	}
	event := messaging.Event{
		ID:        uuid.New().String(),
		Type:      eventType,
		RequestID: requestID(c),
		ActorID:   actorID,
		Timestamp: time.Now().UTC(),
		Payload:   messaging.UserPayload{UserID: targetID, Data: payload},
	}
	if err := h.producer.Publish(c.Request.Context(), event); err != nil {
		h.logger.Error("kafka: publish failed", zap.String("event_type", eventType), zap.Error(err))
	}
}

func (h *UserHandler) logAudit(c *gin.Context, start time.Time, reqBody, respBody interface{}, statusCode int, targetID string) {
	claims, _ := middleware.GetClaims(c)
	actorID := ""
	if claims != nil {
		actorID = claims.Subject
	}
	rec := audit.Record{
		RequestID:   requestID(c),
		ActorID:     actorID,
		Method:      c.Request.Method,
		Path:        c.Request.URL.Path,
		TargetID:    targetID,
		RequestBody: reqBody,
		Response:    respBody,
		StatusCode:  statusCode,
		DurationMs:  time.Since(start).Milliseconds(),
		Timestamp:   time.Now().UTC(),
	}
	if err := h.audit.Log(c.Request.Context(), rec); err != nil {
		h.logger.Error("audit: log failed", zap.Error(err))
	}
}

func requestID(c *gin.Context) string {
	if id := c.GetHeader("X-Request-ID"); id != "" {
		return id
	}
	return uuid.New().String()
}
