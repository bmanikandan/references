package handler

import (
	"database/sql"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/yourorg/oracle-rest-api/internal/model"
)

// HealthHandler handles infrastructure health checks.
type HealthHandler struct {
	db *sql.DB
}

// NewHealthHandler creates a new HealthHandler.
func NewHealthHandler(db *sql.DB) *HealthHandler {
	return &HealthHandler{db: db}
}

// HealthResponse represents the health check payload.
// swagger:model HealthResponse
type HealthResponse struct {
	Status    string    `json:"status"`
	Timestamp time.Time `json:"timestamp"`
	Database  string    `json:"database"`
}

// Health godoc
// @Summary      Health check
// @Description  Returns the liveness status of the API and its database connection.
// @Tags         infrastructure
// @Produce      json
// @Success      200  {object}  model.Response{data=handler.HealthResponse}
// @Failure      503  {object}  model.Response
// @Router       /health [get]
func (h *HealthHandler) Health(c *gin.Context) {
	resp := HealthResponse{
		Timestamp: time.Now().UTC(),
		Status:    "ok",
		Database:  "ok",
	}

	if err := h.db.PingContext(c.Request.Context()); err != nil {
		resp.Status = "degraded"
		resp.Database = "unavailable"
		c.JSON(http.StatusServiceUnavailable,
			model.NewErrorResponse("SERVICE_UNAVAILABLE", "Database is unavailable", err.Error()))
		return
	}

	c.JSON(http.StatusOK, model.NewSuccessResponse("Service is healthy", resp))
}
