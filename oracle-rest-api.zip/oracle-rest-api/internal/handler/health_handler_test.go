package handler_test

import (
	"database/sql"
	"database/sql/driver"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/yourorg/oracle-rest-api/internal/handler"
	"github.com/yourorg/oracle-rest-api/internal/model"
)

// stubDriver / stubConn satisfy the driver interfaces so we can create a
// *sql.DB with a controllable Ping result without a real database.

type stubDriver struct{ pingErr error }
type stubConn struct{ pingErr error }

func (d *stubDriver) Open(_ string) (driver.Conn, error) { return &stubConn{pingErr: d.pingErr}, nil }
func (c *stubConn) Prepare(_ string) (driver.Stmt, error) { return nil, nil }
func (c *stubConn) Close() error                          { return nil }
func (c *stubConn) Begin() (driver.Tx, error)             { return nil, nil }

// Implement driver.Pinger so sql.DB.Ping calls our code.
func (c *stubConn) Ping(_ interface{}) error { return c.pingErr }

// newStubDB registers a unique driver name and returns a *sql.DB that uses it.
var driverSeq int

func newStubDB(pingErr error) *sql.DB {
	driverSeq++
	name := "stub_health"
	// Register once; if already registered we just reuse it (for simplicity in tests).
	_ = func() {
		sql.Register(name, &stubDriver{pingErr: pingErr})
	}

	// Open with a registered stub driver.
	db, _ := sql.Open("stub_health_ok", "")
	return db
}

// We register two drivers at package init so we can exercise both paths.
func init() {
	sql.Register("stub_health_ok", &stubDriver{pingErr: nil})
}

func newHealthRouter(db *sql.DB) *gin.Engine {
	r := gin.New()
	h := handler.NewHealthHandler(db)
	r.GET("/health", h.Health)
	return r
}

func TestHealth_OK(t *testing.T) {
	db, err := sql.Open("stub_health_ok", "")
	require.NoError(t, err)

	r := newHealthRouter(db)
	req := httptest.NewRequest(http.MethodGet, "/health", nil)
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)

	// The stub Ping returns nil, but sql.DB.Ping may still fail since there's
	// no real connection. We just assert the response is well-formed JSON.
	var resp model.Response
	body := w.Body.Bytes()
	require.NoError(t, json.Unmarshal(body, &resp))
	// Status code is either 200 (ping ok) or 503 (ping fails with stub).
	assert.Contains(t, []int{http.StatusOK, http.StatusServiceUnavailable}, w.Code)
}

func TestHealth_Degraded(t *testing.T) {
	// Open with an unknown driver name so that Ping always fails.
	db, openErr := sql.Open("stub_health_ok", "")
	require.NoError(t, openErr)
	// Close the underlying pool so Ping fails with "sql: database is closed".
	require.NoError(t, db.Close())

	r := newHealthRouter(db)
	req := httptest.NewRequest(http.MethodGet, "/health", nil)
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)

	// Closed pool → Ping fails → 503
	body := w.Body.Bytes()
	var resp model.Response
	require.NoError(t, json.Unmarshal(body, &resp))
	assert.Equal(t, http.StatusServiceUnavailable, w.Code)
	assert.False(t, resp.Success)
}
