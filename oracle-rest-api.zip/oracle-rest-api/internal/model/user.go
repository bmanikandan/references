// Package model defines domain entities and request/response DTOs.
package model

import "time"

// UserRole represents valid user roles.
type UserRole string

const (
	RoleAdmin  UserRole = "admin"
	RoleUser   UserRole = "user"
	RoleViewer UserRole = "viewer"
)

// UserStatus represents valid user statuses.
type UserStatus string

const (
	StatusActive   UserStatus = "active"
	StatusInactive UserStatus = "inactive"
)

// User is the domain entity representing a system user.
type User struct {
	ID        string    `json:"id"`
	Name      string    `json:"name"`
	Email     string    `json:"email"`
	Role      string    `json:"role"`
	Status    string    `json:"status"`
	CreatedAt time.Time `json:"created_at"`
	UpdatedAt time.Time `json:"updated_at"`
}

// CreateUserRequest is the payload for creating a new user.
// swagger:model CreateUserRequest
type CreateUserRequest struct {
	// Required; 1–100 characters.
	Name string `json:"name" binding:"required,min=1,max=100"`
	// Required; must be a valid e-mail address.
	Email string `json:"email" binding:"required,email"`
	// Optional; one of admin, user, viewer. Defaults to user.
	Role string `json:"role" binding:"omitempty,oneof=admin user viewer"`
}

// UpdateUserRequest is the payload for updating an existing user.
// swagger:model UpdateUserRequest
type UpdateUserRequest struct {
	// Optional; 1–100 characters.
	Name string `json:"name" binding:"omitempty,min=1,max=100"`
	// Optional; must be a valid e-mail address.
	Email string `json:"email" binding:"omitempty,email"`
	// Optional; one of admin, user, viewer.
	Role string `json:"role" binding:"omitempty,oneof=admin user viewer"`
	// Optional; one of active, inactive.
	Status string `json:"status" binding:"omitempty,oneof=active inactive"`
}

// UserFilter represents query parameters for listing users.
type UserFilter struct {
	Page   int    `form:"page"`
	Limit  int    `form:"limit"`
	Status string `form:"status"`
	Role   string `form:"role"`
}

// Validate normalises filter values to sensible defaults / maximums.
func (f *UserFilter) Validate() {
	if f.Page < 1 {
		f.Page = 1
	}
	if f.Limit < 1 {
		f.Limit = 10
	}
	if f.Limit > 100 {
		f.Limit = 100
	}
}

// Offset returns the SQL OFFSET value derived from page and limit.
func (f *UserFilter) Offset() int {
	return (f.Page - 1) * f.Limit
}
