-- =============================================================================
-- Oracle DDL – Oracle REST API
-- =============================================================================
-- Execute as a DBA user (or the target schema owner).
-- Tested on Oracle Database 19c / 21c.
-- =============================================================================

-- Drop table if it exists from a previous setup.
BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE users CASCADE CONSTRAINTS';
EXCEPTION
    WHEN OTHERS THEN
        IF SQLCODE != -942 THEN RAISE; END IF;
END;
/

-- -----------------------------------------------------------------------------
-- Users table
-- -----------------------------------------------------------------------------
CREATE TABLE users (
    id          VARCHAR2(36)  NOT NULL,
    name        VARCHAR2(100) NOT NULL,
    email       VARCHAR2(200) NOT NULL,
    role        VARCHAR2(50)  DEFAULT 'user'   NOT NULL,
    status      VARCHAR2(20)  DEFAULT 'active' NOT NULL,
    created_at  TIMESTAMP     DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at  TIMESTAMP     DEFAULT CURRENT_TIMESTAMP NOT NULL,

    CONSTRAINT pk_users        PRIMARY KEY (id),
    CONSTRAINT uq_users_email  UNIQUE      (email),
    CONSTRAINT chk_users_role  CHECK       (role   IN ('admin', 'user', 'viewer')),
    CONSTRAINT chk_users_status CHECK      (status IN ('active', 'inactive'))
);

-- Indexes for common query patterns
CREATE INDEX idx_users_status ON users (status);
CREATE INDEX idx_users_role   ON users (role);
CREATE INDEX idx_users_created ON users (created_at);

-- -----------------------------------------------------------------------------
-- Seed data (optional – useful for local development)
-- -----------------------------------------------------------------------------
INSERT INTO users (id, name, email, role, status)
VALUES ('00000000-0000-0000-0000-000000000001', 'Admin User',   'admin@example.com',   'admin',  'active');

INSERT INTO users (id, name, email, role, status)
VALUES ('00000000-0000-0000-0000-000000000002', 'Regular User', 'user@example.com',    'user',   'active');

INSERT INTO users (id, name, email, role, status)
VALUES ('00000000-0000-0000-0000-000000000003', 'View Only',    'viewer@example.com',  'viewer', 'active');

INSERT INTO users (id, name, email, role, status)
VALUES ('00000000-0000-0000-0000-000000000004', 'Inactive User','inactive@example.com','user',   'inactive');

COMMIT;

-- Verify
SELECT id, name, email, role, status FROM users;
