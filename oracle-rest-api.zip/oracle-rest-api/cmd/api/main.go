// Package main is the application entry point.
//
// @title           Oracle REST API
// @version         1.0.0
// @description     RESTful API with Oracle DB, Redis caching, MongoDB audit logs, and Kafka events. Protected by OAuth 2.0 Bearer tokens.
// @termsOfService  http://swagger.io/terms/
//
// @contact.name   API Support
// @contact.email  support@yourorg.com
//
// @license.name  Apache 2.0
// @license.url   https://www.apache.org/licenses/LICENSE-2.0
//
// @host      localhost:8080
// @BasePath  /api/v1
//
// @securityDefinitions.apikey BearerAuth
// @in header
// @name Authorization
// @description OAuth 2.0 Bearer token. Format: "Bearer <token>"
package main

import (
	"context"
	"errors"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/gin-gonic/gin"
	swaggerFiles "github.com/swaggo/files"
	ginSwagger "github.com/swaggo/gin-swagger"
	"go.uber.org/zap"
	"go.uber.org/zap/zapcore"

	_ "github.com/yourorg/oracle-rest-api/docs"
	"github.com/yourorg/oracle-rest-api/internal/audit"
	"github.com/yourorg/oracle-rest-api/internal/cache"
	"github.com/yourorg/oracle-rest-api/internal/config"
	"github.com/yourorg/oracle-rest-api/internal/database"
	"github.com/yourorg/oracle-rest-api/internal/handler"
	"github.com/yourorg/oracle-rest-api/internal/messaging"
	"github.com/yourorg/oracle-rest-api/internal/middleware"
	"github.com/yourorg/oracle-rest-api/internal/repository"
	"github.com/yourorg/oracle-rest-api/internal/service"
	"github.com/yourorg/oracle-rest-api/pkg/auth"
)

func main() {
	logger := buildLogger()
	defer func() { _ = logger.Sync() }()

	// ── Configuration ──────────────────────────────────────────────────────
	cfg, err := config.Load()
	if err != nil {
		logger.Fatal("failed to load configuration", zap.Error(err))
	}

	// ── Oracle DB ──────────────────────────────────────────────────────────
	db, err := database.NewOracleDB(&cfg.Database)
	if err != nil {
		logger.Fatal("failed to connect to oracle", zap.Error(err))
	}
	defer func() { _ = db.Close() }()
	logger.Info("oracle connected")

	// ── Redis cache ────────────────────────────────────────────────────────
	redisCache, err := cache.NewRedisCache(&cfg.Redis)
	if err != nil {
		logger.Fatal("failed to connect to redis", zap.Error(err))
	}
	logger.Info("redis connected")

	// ── MongoDB audit logger ───────────────────────────────────────────────
	auditLogger, err := audit.NewMongoLogger(&cfg.Mongo)
	if err != nil {
		logger.Fatal("failed to connect to mongodb", zap.Error(err))
	}
	logger.Info("mongodb connected")

	// ── Kafka producer ─────────────────────────────────────────────────────
	producer := messaging.NewKafkaProducer(&cfg.Kafka)
	defer func() {
		if err := producer.Close(); err != nil {
			logger.Error("kafka producer close error", zap.Error(err))
		}
	}()
	logger.Info("kafka producer initialised", zap.Strings("brokers", cfg.Kafka.Brokers))

	// ── Kafka consumer (background) ────────────────────────────────────────
	consumer := messaging.NewKafkaConsumer(&cfg.Kafka, logger)
	// Register domain-specific handlers.
	consumer.RegisterHandler(messaging.EventUserCreated, func(ctx context.Context, event messaging.Event) error {
		logger.Info("consumed user.created event", zap.String("event_id", event.ID), zap.String("actor", event.ActorID))
		return nil
	})
	consumer.RegisterHandler(messaging.EventUserUpdated, func(ctx context.Context, event messaging.Event) error {
		logger.Info("consumed user.updated event", zap.String("event_id", event.ID))
		return nil
	})
	consumer.RegisterHandler(messaging.EventUserDeleted, func(ctx context.Context, event messaging.Event) error {
		logger.Info("consumed user.deleted event", zap.String("event_id", event.ID))
		return nil
	})

	consumerCtx, cancelConsumer := context.WithCancel(context.Background())
	go func() {
		consumer.Start(consumerCtx)
		if err := consumer.Close(); err != nil {
			logger.Error("kafka consumer close error", zap.Error(err))
		}
	}()

	// ── Dependency wiring ──────────────────────────────────────────────────
	jwtSvc := auth.NewJWTService(cfg.JWT.SecretKey, cfg.JWT.Issuer)

	userRepo := repository.NewUserRepository(db)
	userSvc := service.NewUserService(userRepo)

	userH := handler.NewUserHandler(userSvc, redisCache, auditLogger, producer, logger)
	healthH := handler.NewHealthHandler(db)

	// ── Router ─────────────────────────────────────────────────────────────
	if cfg.Server.Environment == "production" {
		gin.SetMode(gin.ReleaseMode)
	}

	r := gin.New()
	r.Use(middleware.CORS())
	r.Use(middleware.RequestLogger(logger))
	r.Use(gin.Recovery())

	r.GET("/swagger/*any", ginSwagger.WrapHandler(swaggerFiles.Handler))
	r.GET("/health", healthH.Health)

	v1 := r.Group("/api/v1")
	{
		users := v1.Group("/users")
		users.Use(middleware.RequireAuth(jwtSvc, logger))
		{
			users.GET("", middleware.RequireScopes("users:read"), userH.ListUsers)
			users.GET("/:id", middleware.RequireScopes("users:read"), userH.GetUser)
			users.POST("", middleware.RequireScopes("users:write"), userH.CreateUser)
			users.PUT("/:id", middleware.RequireScopes("users:write"), userH.UpdateUser)
			users.DELETE("/:id", middleware.RequireScopes("users:delete"), userH.DeleteUser)
		}
	}

	// ── HTTP server (graceful shutdown) ────────────────────────────────────
	srv := &http.Server{
		Addr:         cfg.Server.Addr(),
		Handler:      r,
		ReadTimeout:  cfg.Server.ReadTimeout,
		WriteTimeout: cfg.Server.WriteTimeout,
		IdleTimeout:  60 * time.Second,
	}

	go func() {
		logger.Info("http server starting", zap.String("addr", srv.Addr))
		if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			logger.Fatal("server listen error", zap.Error(err))
		}
	}()

	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit
	logger.Info("shutdown signal received")

	cancelConsumer() // stop Kafka consumer

	shutCtx, shutCancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer shutCancel()
	if err := srv.Shutdown(shutCtx); err != nil {
		logger.Error("http server shutdown error", zap.Error(err))
	}
	logger.Info("server stopped gracefully")
}

func buildLogger() *zap.Logger {
	enc := zap.NewProductionEncoderConfig()
	enc.TimeKey = "time"
	enc.EncodeTime = zapcore.ISO8601TimeEncoder

	cfg := zap.NewProductionConfig()
	cfg.EncoderConfig = enc
	if os.Getenv("APP_ENV") != "production" {
		cfg = zap.NewDevelopmentConfig()
		cfg.EncoderConfig.EncodeLevel = zapcore.CapitalColorLevelEncoder
	}
	l, _ := cfg.Build()
	return l
}
