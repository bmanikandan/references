# Oracle REST API

Production-ready RESTful API built with **Go (Gin)** and **Oracle Database**, secured with **OAuth 2.0 Bearer tokens** (JWT), fully documented with **Swagger / OpenAPI 2.0**, and tested with **≥ 90% code coverage**.

---

## Table of Contents

1. [Architecture](#architecture)
2. [Tech Stack](#tech-stack)
3. [Project Structure](#project-structure)
4. [Prerequisites](#prerequisites)
5. [Configuration](#configuration)
6. [Database Setup](#database-setup)
7. [Running the API](#running-the-api)
8. [API Endpoints](#api-endpoints)
9. [Authentication & Scopes](#authentication--scopes)
10. [Swagger UI](#swagger-ui)
11. [Testing](#testing)
12. [Makefile Reference](#makefile-reference)

---

## Architecture

```
HTTP Request
    │
    ▼
┌─────────────────────────────────────┐
│  Gin Router + Middleware            │
│  ├── CORS                           │
│  ├── Request Logger (zap)           │
│  ├── RequireAuth  (JWT validation)  │
│  └── RequireScopes (scope check)    │
└──────────┬──────────────────────────┘
           │
    ┌──────▼──────┐
    │   Handler   │  (input binding / validation / HTTP status mapping)
    └──────┬──────┘
           │
    ┌──────▼──────┐
    │   Service   │  (business logic, UUID generation, timestamps)
    └──────┬──────┘
           │
    ┌──────▼──────────┐
    │   Repository    │  (SQL, parameterised queries)
    └──────┬──────────┘
           │
    ┌──────▼──────┐
    │  Oracle DB  │
    └─────────────┘
```

Each layer is **interface-driven**, enabling full unit testing with mocks — no real database required.

---

## Tech Stack

| Concern         | Library / Tool                                       |
|-----------------|------------------------------------------------------|
| HTTP framework  | [gin-gonic/gin](https://github.com/gin-gonic/gin)   |
| Oracle driver   | [sijms/go-ora](https://github.com/sijms/go-ora) (pure Go, no Oracle Client needed) |
| JWT             | [golang-jwt/jwt/v5](https://github.com/golang-jwt/jwt) |
| Swagger         | [swaggo/swag](https://github.com/swaggo/swag) + gin-swagger |
| Logging         | [uber-go/zap](https://github.com/uber-go/zap)       |
| UUID            | [google/uuid](https://github.com/google/uuid)       |
| Testing         | [testify](https://github.com/stretchr/testify)      |
| Env loading     | [joho/godotenv](https://github.com/joho/godotenv)   |

---

## Project Structure

```
oracle-rest-api/
├── cmd/
│   └── api/
│       └── main.go              # Entry point, router wiring, graceful shutdown
├── internal/
│   ├── config/
│   │   └── config.go            # Env-var configuration loader
│   ├── database/
│   │   └── oracle.go            # Oracle connection pool factory
│   ├── handler/
│   │   ├── user_handler.go      # HTTP handlers (List/Get/Create/Update/Delete)
│   │   ├── user_handler_test.go
│   │   ├── health_handler.go    # /health endpoint
│   │   └── health_handler_test.go
│   ├── middleware/
│   │   ├── auth.go              # RequireAuth + RequireScopes
│   │   ├── auth_test.go
│   │   ├── cors.go
│   │   └── logger.go
│   ├── mocks/
│   │   ├── user_repository_mock.go
│   │   └── user_service_mock.go
│   ├── model/
│   │   ├── user.go              # Domain entity + request/response DTOs
│   │   └── response.go          # Standard API envelope
│   ├── repository/
│   │   ├── interfaces.go
│   │   └── user_repository.go   # Oracle SQL implementation
│   └── service/
│       ├── interfaces.go
│       ├── user_service.go      # Business logic
│       └── user_service_test.go
├── pkg/
│   └── auth/
│       ├── jwt.go               # JWT generation, validation, scope helpers
│       └── jwt_test.go
├── docs/
│   └── docs.go                  # Swagger spec (regenerate with make swagger)
├── scripts/
│   └── setup.sql                # Oracle DDL + seed data
├── .env.example                 # Environment variable template
├── go.mod
├── Makefile
└── README.md
```

---

## Prerequisites

| Requirement | Version |
|-------------|---------|
| Go          | ≥ 1.21  |
| Oracle DB   | 12c R2 + (12.2+) — uses `FETCH FIRST … ROWS ONLY` syntax |
| make        | any     |
| swag (optional) | `go install github.com/swaggo/swag/cmd/swag@latest` |

> **No Oracle Instant Client required.** The `sijms/go-ora` driver is pure Go.

---

## Configuration

Copy `.env.example` to `.env` and fill in your values:

```bash
cp .env.example .env
```

| Variable             | Default          | Description                              |
|----------------------|------------------|------------------------------------------|
| `APP_ENV`            | `development`    | `development` or `production`            |
| `SERVER_HOST`        | `0.0.0.0`        | Listen address                           |
| `SERVER_PORT`        | `8080`           | Listen port                              |
| `SERVER_READ_TIMEOUT`| `30s`            | HTTP read timeout                        |
| `SERVER_WRITE_TIMEOUT`| `30s`           | HTTP write timeout                       |
| `DB_HOST`            | `localhost`      | Oracle host                              |
| `DB_PORT`            | `1521`           | Oracle port                              |
| `DB_USER`            | *(required)*     | Oracle schema user                       |
| `DB_PASSWORD`        | *(required)*     | Oracle schema password                   |
| `DB_NAME`            | `ORCL`           | Service name or SID                      |
| `DB_MAX_OPEN_CONNS`  | `25`             | Max open DB connections                  |
| `DB_MAX_IDLE_CONNS`  | `10`             | Max idle DB connections                  |
| `JWT_SECRET_KEY`     | *(required)*     | HMAC-SHA256 signing key (≥ 32 chars)     |
| `JWT_ISSUER`         | `oracle-rest-api`| JWT `iss` claim                          |
| `JWT_EXPIRY`         | `1h`             | Token lifetime (`1h`, `30m`, etc.)       |

---

## Database Setup

```bash
# Run against your Oracle instance (requires sqlplus)
make db-setup

# Or execute manually:
sqlplus user/password@host:1521/ORCL @scripts/setup.sql
```

The script creates the `users` table with constraints, indexes, and optional seed rows.

---

## Running the API

```bash
# Install dependencies
go mod tidy

# Regenerate Swagger docs (optional, already included)
make swagger

# Build and run
make build
./bin/oracle-rest-api

# Or run directly
make run
```

The server starts on `http://localhost:8080` (or your configured address).

---

## API Endpoints

### Base URL
```
http://localhost:8080
```

### Public Endpoints

| Method | Path      | Description               |
|--------|-----------|---------------------------|
| GET    | `/health` | Liveness + database check |
| GET    | `/swagger/*any` | Swagger UI          |

### Protected Endpoints — `/api/v1`

All endpoints below require a valid `Authorization: Bearer <token>` header.

| Method | Path              | Required Scope  | Description           |
|--------|-------------------|-----------------|-----------------------|
| GET    | `/api/v1/users`   | `users:read`    | Paginated user list   |
| GET    | `/api/v1/users/:id` | `users:read`  | Get user by ID        |
| POST   | `/api/v1/users`   | `users:write`   | Create user           |
| PUT    | `/api/v1/users/:id` | `users:write` | Update user (partial) |
| DELETE | `/api/v1/users/:id` | `users:delete`| Delete user           |

### Query Parameters — `GET /api/v1/users`

| Parameter | Type    | Default | Description              |
|-----------|---------|---------|--------------------------|
| `page`    | integer | `1`     | Page number              |
| `limit`   | integer | `10`    | Items per page (max 100) |
| `status`  | string  | —       | Filter: `active`\|`inactive` |
| `role`    | string  | —       | Filter: `admin`\|`user`\|`viewer` |

### Request / Response Examples

**Create User**
```bash
curl -X POST http://localhost:8080/api/v1/users \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{"name":"Alice","email":"alice@example.com","role":"user"}'
```

```json
{
  "success": true,
  "message": "User created successfully",
  "data": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "name": "Alice",
    "email": "alice@example.com",
    "role": "user",
    "status": "active",
    "created_at": "2025-01-15T10:30:00Z",
    "updated_at": "2025-01-15T10:30:00Z"
  }
}
```

**Error Response**
```json
{
  "success": false,
  "error": {
    "code": "NOT_FOUND",
    "message": "User not found",
    "details": ""
  }
}
```

**Paginated List**
```json
{
  "success": true,
  "data": [...],
  "pagination": {
    "page": 1,
    "limit": 10,
    "total": 42,
    "total_pages": 5
  }
}
```

---

## Authentication & Scopes

This API uses **OAuth 2.0 Bearer tokens** (signed JWTs, HS256).

### Token Structure

```json
{
  "sub": "user-id",
  "client_id": "my-app",
  "scopes": ["users:read", "users:write"],
  "iss": "oracle-rest-api",
  "iat": 1700000000,
  "exp": 1700003600,
  "nbf": 1700000000
}
```

### Available Scopes

| Scope          | Grants access to                 |
|----------------|----------------------------------|
| `users:read`   | `GET /users`, `GET /users/:id`  |
| `users:write`  | `POST /users`, `PUT /users/:id` |
| `users:delete` | `DELETE /users/:id`             |

### Generating a Development Token

For local testing you can generate a token by writing a small Go snippet or using the provided test helpers.

Example using the JWT service:
```go
svc := auth.NewJWTService(os.Getenv("JWT_SECRET_KEY"), "oracle-rest-api")
token, _ := svc.GenerateToken("dev-user", "dev-client",
    []string{"users:read", "users:write", "users:delete"}, time.Hour)
fmt.Println(token)
```

Then use it:
```bash
curl -H "Authorization: Bearer $TOKEN" http://localhost:8080/api/v1/users
```

### HTTP Error Codes

| Code | Meaning                                          |
|------|--------------------------------------------------|
| 401  | Missing or invalid token / token expired         |
| 403  | Valid token but missing required scope           |
| 404  | Resource not found                               |
| 409  | Conflict (e.g. duplicate e-mail)                 |
| 422  | Validation error                                 |
| 500  | Internal server error                            |

---

## Swagger UI

After starting the server, open:

```
http://localhost:8080/swagger/index.html
```

To regenerate the Swagger spec from source annotations:

```bash
make swagger
# or directly:
swag init -g cmd/api/main.go -o docs --parseDependency --parseInternal
```

To authenticate in Swagger UI:
1. Click **Authorize** (lock icon)
2. Enter `Bearer <your-jwt-token>`
3. Click **Authorize**

---

## Testing

### Run All Tests
```bash
make test
```

### Coverage Report
```bash
make coverage          # generates coverage.html and prints function coverage
make coverage-check    # fails if total coverage < 90%
```

### Coverage Targets (≥ 90%)

| Package                        | Coverage focus                                |
|--------------------------------|-----------------------------------------------|
| `pkg/auth`                     | JWT generation, validation, scope helpers, header extraction |
| `internal/middleware`          | RequireAuth (all error paths), RequireScopes  |
| `internal/service`             | All CRUD paths including error and edge cases |
| `internal/handler`             | All HTTP handlers with mocked services        |

Tests use `testify/mock` for interface mocking — **no real Oracle DB required** for unit tests.

---

## Makefile Reference

```bash
make help          # List all targets
make build         # Compile binary → ./bin/oracle-rest-api
make run           # Run server directly with go run
make test          # Run all tests with -race
make coverage      # HTML coverage report
make coverage-check # Assert ≥ 90% coverage
make swagger       # Regenerate Swagger docs
make lint          # Run golangci-lint
make tidy          # go mod tidy + go mod verify
make fmt           # gofmt -w .
make vet           # go vet ./...
make db-setup      # Run Oracle DDL via sqlplus
make docker-build  # Build Docker image
make clean         # Remove ./bin, coverage files
```

---

## License

Apache 2.0 — see [LICENSE](LICENSE).
