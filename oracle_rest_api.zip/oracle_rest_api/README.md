# Oracle REST API — C++17 / OCI

A production-style RESTful API server written in **C++17** backed by **Oracle Database** via the native **OCI (Oracle Call Interface)** C library.

## Architecture

```
oracle_rest_api/
├── CMakeLists.txt            # CMake build (auto-fetches httplib + json)
├── sql/
│   └── schema.sql            # Table, sequence, seed data
├── include/
│   ├── db_connection.h       # OCI wrapper (OracleDB, OracleStmt)
│   ├── employee.h            # Domain model + DAO interface
│   └── api_server.h          # HTTP server + route declarations
├── src/
│   ├── main.cpp              # Entry point, signal handling
│   ├── db_connection.cpp     # OCI connection, statement, fetch
│   ├── employee_dao.cpp      # SQL queries (CRUD, pagination)
│   └── api_server.cpp        # Route handlers, JSON responses
└── scripts/
    ├── build.sh              # CMake build helper
    ├── run.sh                # Launch with env-var config
    └── test_api.sh           # curl smoke tests
```

### Third-party libraries (fetched automatically by CMake)

| Library | Version | Purpose |
|---|---|---|
| [cpp-httplib](https://github.com/yhirose/cpp-httplib) | v0.15.3 | Header-only HTTP/1.1 server |
| [nlohmann/json](https://github.com/nlohmann/json) | v3.11.3 | Header-only JSON parser |
| Oracle OCI | system | Native Oracle C call interface |

---

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/api/v1/health` | Health check |
| `GET` | `/api/v1/employees` | List employees (paginated) |
| `GET` | `/api/v1/employees/:id` | Get employee by ID |
| `POST` | `/api/v1/employees` | Create employee |
| `PUT` | `/api/v1/employees/:id` | Full update |
| `PATCH` | `/api/v1/employees/:id` | Partial update |
| `DELETE` | `/api/v1/employees/:id` | Delete employee |

### Query parameters for `GET /employees`

| Param | Default | Description |
|-------|---------|-------------|
| `dept` | *(all)* | Filter by department |
| `limit` | `100` | Max rows (capped at 500) |
| `offset` | `0` | Pagination offset |

### Request / Response format

```json
// Success
{
  "success": true,
  "data": { "id": 1, "name": "Alice", "email": "alice@example.com",
            "department": "Engineering", "salary": 95000, "created_at": "..." },
  "meta": { "total": 5, "limit": 100, "offset": 0, "count": 5 }
}

// Error
{
  "success": false,
  "error": { "code": 404, "message": "Employee 99 not found" }
}
```

---

## Prerequisites

- **C++17** compiler: GCC 9+ or Clang 9+
- **CMake** 3.16+
- **Oracle Instant Client** (Basic + SDK packages) — [download](https://www.oracle.com/database/technologies/instant-client/downloads.html)
- Internet access (CMake downloads httplib + json automatically)

### Install Oracle Instant Client (Linux example)

```bash
# Extract Basic + SDK packages to the same directory
sudo mkdir -p /opt/oracle
sudo unzip instantclient-basic-linux.x64-21.9.0.0.0dbru.zip  -d /opt/oracle
sudo unzip instantclient-sdk-linux.x64-21.9.0.0.0dbru.zip    -d /opt/oracle
sudo mv /opt/oracle/instantclient_21_9 /opt/oracle/instantclient_21_9   # rename if needed

# ldconfig so the linker can find libclntsh
echo /opt/oracle/instantclient_21_9 | sudo tee /etc/ld.so.conf.d/oracle.conf
sudo ldconfig
```

---

## Build

```bash
export ORACLE_HOME=/opt/oracle/instantclient_21_9

# Debug (default)
./scripts/build.sh

# Release
./scripts/build.sh Release
```

---

## Database setup

```bash
# Run as the schema owner (adjust connection string as needed)
sqlplus hr/hr@localhost:1521/XEPDB1 @sql/schema.sql
```

---

## Run

```bash
export DB_USER=hr
export DB_PASSWORD=hr
export DB_DSN=localhost:1521/XEPDB1
export SERVER_PORT=8080

./scripts/run.sh
```

---

## Test

```bash
# Run smoke tests against the live server
./scripts/test_api.sh http://localhost:8080

# Or use curl manually:
curl http://localhost:8080/api/v1/health

curl http://localhost:8080/api/v1/employees?dept=Engineering&limit=3

curl -X POST http://localhost:8080/api/v1/employees \
     -H "Content-Type: application/json" \
     -d '{"name":"John Doe","email":"john@example.com","department":"IT","salary":75000}'
```

---

## Key design decisions

| Decision | Rationale |
|---|---|
| **Native OCI** | Maximum Oracle feature coverage (no ODBC translation layer) |
| **`OCIStmtPrepare2`** | Uses Oracle's built-in statement cache (better performance) |
| **Bind variables** | Prevents SQL injection; OCI `OCIBindByPos` for positional params |
| **`RETURNING id INTO :ret_id`** | Reliably retrieves generated ID in a single round-trip |
| **Auto-commit per DML** | Simple model; wrap in `OCITransStart`/`OCITransCommit` for multi-statement transactions |
| **`OCI_THREADED`** | Environment created thread-safe for the HTTP server's thread pool |
| **cpp-httplib** | Single-header, no Boost dependency, built-in thread pool |
