#pragma once

#include "http_client.h"
#include <nlohmann/json.hpp>

#include <string>
#include <vector>

// ---------------------------------------------------------------------------
// ExternalApiService — integrates with a downstream REST API
//
// Configured by environment variables:
//   EXTERNAL_API_BASE_URL  — base URL of the remote service
//                            (default: http://jsonplaceholder.typicode.com)
//   EXTERNAL_API_TOKEN     — Bearer token (optional)
//
// Exposed REST routes (added to our API server):
//   GET  /api/v1/external/posts           — list posts from remote service
//   GET  /api/v1/external/posts/:id       — get single post
//   POST /api/v1/external/posts           — create post on remote service
//   GET  /api/v1/external/users           — list users from remote service
//   GET  /api/v1/external/users/:id       — get single user
// ---------------------------------------------------------------------------
class ExternalApiService {
public:
    /**
     * @param baseUrl   Base URL of the downstream REST API.
     * @param authToken Optional Bearer token; pass "" to skip auth header.
     */
    ExternalApiService(const std::string& baseUrl,
                       const std::string& authToken = "");

    // --- Posts ---
    nlohmann::json listPosts (int limit = 20, int page = 1);
    nlohmann::json getPost   (int id);
    nlohmann::json createPost(const nlohmann::json& body);

    // --- Users ---
    nlohmann::json listUsers ();
    nlohmann::json getUser   (int id);

private:
    HttpClient client_;
};
