#pragma once

// CPPHTTPLIB_OPENSSL_SUPPORT is injected by CMake if OpenSSL is found.
// It must be defined BEFORE including httplib.h.
#include <httplib.h>
#include <nlohmann/json.hpp>

#include <map>
#include <memory>
#include <stdexcept>
#include <string>

// ---------------------------------------------------------------------------
// HttpClientException
// ---------------------------------------------------------------------------
class HttpClientException : public std::runtime_error {
public:
    int httpStatus = 0;
    explicit HttpClientException(const std::string& msg, int status = 0)
        : std::runtime_error(msg), httpStatus(status) {}
};

// ---------------------------------------------------------------------------
// HttpResponse — wraps an HTTP response from an outgoing call
// ---------------------------------------------------------------------------
struct HttpResponse {
    int         status  = 0;
    std::string body;
    std::map<std::string, std::string> headers;

    bool ok()     const { return status >= 200 && status < 300; }
    bool isJson() const {
        auto it = headers.find("content-type");
        return it != headers.end() &&
               it->second.find("application/json") != std::string::npos;
    }

    /// Parse body as JSON. Throws nlohmann::json::parse_error on failure.
    nlohmann::json json() const { return nlohmann::json::parse(body); }
};

// ---------------------------------------------------------------------------
// ClientConfig — connection and per-request settings
// ---------------------------------------------------------------------------
struct ClientConfig {
    int  connectTimeoutSec = 10;
    int  readTimeoutSec    = 30;
    bool followRedirects   = true;

    // Default headers added to every request
    std::map<std::string, std::string> defaultHeaders;
};

// ---------------------------------------------------------------------------
// HttpClient — generic, reusable REST API client
//
// Usage:
//   HttpClient client("https://api.example.com", {.readTimeoutSec = 15});
//   client.setBearer("my-token");
//
//   auto res = client.get("/users/1");
//   if (res.ok()) { auto j = res.json(); }
//
//   auto res2 = client.post("/users", {{"name","Alice"}});
// ---------------------------------------------------------------------------
class HttpClient {
public:
    /**
     * @param baseUrl  Scheme + host (+ optional port).
     *                 Examples: "http://api.example.com"
     *                           "https://api.example.com:8443"
     *                           "http://localhost:9000"
     * @param cfg      Optional configuration overrides.
     */
    explicit HttpClient(const std::string& baseUrl,
                        const ClientConfig& cfg = {});

    // --- Auth helpers ---
    void setBearer(const std::string& token);
    void setBasicAuth(const std::string& user, const std::string& password);
    void setHeader(const std::string& name, const std::string& value);

    // --- HTTP verbs ---
    HttpResponse get   (const std::string& path,
                        const httplib::Params& queryParams = {});

    HttpResponse post  (const std::string& path,
                        const std::string& body,
                        const std::string& contentType = "application/json");

    /// Convenience: serialise a JSON object and POST it.
    HttpResponse postJson(const std::string& path,
                          const nlohmann::json& body);

    HttpResponse put   (const std::string& path,
                        const std::string& body,
                        const std::string& contentType = "application/json");

    HttpResponse putJson(const std::string& path,
                         const nlohmann::json& body);

    HttpResponse patch (const std::string& path,
                        const std::string& body,
                        const std::string& contentType = "application/json");

    HttpResponse patchJson(const std::string& path,
                           const nlohmann::json& body);

    HttpResponse del   (const std::string& path);

private:
    std::unique_ptr<httplib::Client> cli_;
    ClientConfig cfg_;
    httplib::Headers defaultHeaders_;

    // Parse scheme, host, port from baseUrl
    static void parseUrl(const std::string& url,
                         std::string& scheme,
                         std::string& host,
                         int& port,
                         std::string& basePath);

    HttpResponse toResponse(const httplib::Result& result,
                            const std::string& method,
                            const std::string& path) const;
};
