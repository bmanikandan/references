#pragma once

#include "db_connection.h"
#include <nlohmann/json.hpp>

#include <cstdint>
#include <optional>
#include <string>
#include <vector>

// ---------------------------------------------------------------------------
// Employee — Domain model
// ---------------------------------------------------------------------------

struct Employee {
    int64_t     id         = 0;
    std::string name;
    std::string email;
    std::string department;
    double      salary     = 0.0;
    std::string createdAt;   // ISO-8601 string from Oracle

    // Serialise to JSON
    nlohmann::json toJson() const;

    // Deserialise from JSON (for create / update requests)
    static Employee fromJson(const nlohmann::json& j);
};

// ---------------------------------------------------------------------------
// EmployeeDAO — Data Access Object
//
// All SQL is here; no SQL leaks into the HTTP layer.
// ---------------------------------------------------------------------------

class EmployeeDAO {
public:
    explicit EmployeeDAO(OracleDB& db);

    // CRUD
    std::vector<Employee> findAll(const std::string& dept   = "",
                                  int                limit  = 100,
                                  int                offset = 0);

    std::optional<Employee> findById(int64_t id);

    /// Insert a new employee; returns the new id.
    int64_t create(const Employee& emp);

    /// Full update. Returns true if a row was modified.
    bool update(int64_t id, const Employee& emp);

    /// Partial update: only fields present in `patch` are changed.
    bool patch(int64_t id, const nlohmann::json& patch);

    /// Delete by id. Returns true if a row was deleted.
    bool remove(int64_t id);

    /// Count of all employees (optionally filtered by department).
    int64_t count(const std::string& dept = "");

private:
    OracleDB& db_;

    static Employee rowToEmployee(const Row& row);
};
