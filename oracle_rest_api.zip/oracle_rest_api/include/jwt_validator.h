#pragma once

#include "auth_exception.h"
#include "jwks_provider.h"

#include <set>
#include <string>

// ---------------------------------------------------------------------------
// JwtValidator — verifies a JWT Bearer token end-to-end.
//
// Validation steps
// ────────────────
//  1. Extract Bearer token from "Authorization: Bearer <token>" header.
//  2. Decode the JWT (base64url header + payload) — no crypto yet.
//  3. Read "kid" and "alg" from the header.
//  4. Check alg is in the allowed-algorithm set.
//  5. Retrieve the public key PEM from JwksProvider (with Redis caching).
//  6. Verify the JWT signature using jwt-cpp + OpenSSL.
//  7. Validate claims:
//       • exp  — token has not expired
//       • nbf  — token is already valid (not-before)
//       • iss  — matches configured issuer (if set)
//       • aud  — at least one audience matches (if configured)
//  8. Return populated TokenClaims on success.
//     Throw AuthException on any failure.
//
// Supported algorithms
// ─────────────────────
//   RS256 / RS384 / RS512   (RSA PKCS#1 v1.5 + SHA-2)
//   ES256 / ES384 / ES512   (ECDSA P-256/P-384/P-521 + SHA-2)
//   PS256 / PS384 / PS512   (RSA-PSS + SHA-2)        ← jwt-cpp 0.7+
// ---------------------------------------------------------------------------
class JwtValidator {
public:
    struct Config {
        std::string issuer;      // OAUTH_ISSUER — required; "" skips iss check
        std::string audience;    // OAUTH_AUDIENCE — "" skips aud check
        int  clockSkewSec = 30;  // Allowed clock drift for exp/nbf

        // Algorithms accepted. If empty, all jwt-cpp-supported ones are allowed.
        // Recommended: {"RS256"} or {"RS256", "RS384", "RS512"}
        std::set<std::string> allowedAlgorithms = {
            "RS256", "RS384", "RS512",
            "ES256", "ES384", "ES512",
            "PS256", "PS384", "PS512"
        };
    };

    JwtValidator(const Config& cfg, JwksProvider& jwks);

    // Validate the "Authorization" header value (e.g. "Bearer eyJ...").
    // Returns decoded, verified claims.
    // Throws AuthException on any failure.
    TokenClaims validate(const std::string& authorizationHeaderValue) const;

private:
    Config        cfg_;
    JwksProvider& jwks_;

    // Extract raw JWT string from "Bearer <token>" or throw.
    static std::string extractBearer(const std::string& headerValue);

    // Verify and return claims using the given public-key PEM.
    // Throws on failure.
    TokenClaims verifyWithKey(const std::string& token,
                               const std::string& alg,
                               const std::string& pemKey) const;

    // Parse "scope" claim (space-delimited string) into a vector.
    static std::vector<std::string> parseScopes(const std::string& scope);
};
