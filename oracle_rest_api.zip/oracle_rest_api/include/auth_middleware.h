#pragma once

#include "auth_exception.h"
#include "jwt_validator.h"

#include <httplib.h>
#include <nlohmann/json.hpp>

#include <string>

// ---------------------------------------------------------------------------
// Thread-local claims — set by AuthMiddleware before calling the handler.
// Handlers can read these to log the user or enforce fine-grained access.
//
//   auto& claims = AuthMiddleware::currentClaims();
//   std::cout << "Request by: " << claims.subject;
// ---------------------------------------------------------------------------
extern thread_local TokenClaims g_currentClaims;

// ---------------------------------------------------------------------------
// AuthMiddleware — wraps httplib route handlers with JWT Bearer authentication.
//
// Usage in ApiServer:
//
//   svr_.Get("/api/v1/employees",
//            auth_.require(
//                [this](auto& req, auto& res) { handleGetEmployees(req, res); }
//            ));
//
// When OAUTH_ENABLED=false the middleware is in pass-through mode — all
// requests proceed without token validation (useful for development).
//
// Error responses comply with RFC 6750 §3 (Bearer Token Usage):
//   401 + WWW-Authenticate: Bearer realm="<realm>", error="invalid_token",
//                            error_description="..."
// ---------------------------------------------------------------------------
class AuthMiddleware {
public:
    struct Config {
        bool        enabled = true;
        std::string realm   = "oracle-rest-api";
    };

    AuthMiddleware(const Config& cfg, JwtValidator& validator);

    // Wrap a plain httplib handler with Bearer token validation.
    httplib::Server::Handler require(httplib::Server::Handler handler);

    // Wrap a handler and additionally enforce a required scope.
    // Returns 403 Forbidden if the token is valid but lacks the scope.
    httplib::Server::Handler requireScope(const std::string& scope,
                                          httplib::Server::Handler handler);

    // Access decoded claims of the currently executing request (thread-local).
    static const TokenClaims& currentClaims() { return g_currentClaims; }

    bool isEnabled() const { return cfg_.enabled; }

private:
    Config        cfg_;
    JwtValidator& validator_;

    // Send RFC 6750-compliant 401 response.
    void sendUnauthorized(httplib::Response& res,
                           const std::string& rfc6750Error,
                           const std::string& description) const;

    // Send 403 Forbidden when scope is insufficient.
    void sendForbidden(httplib::Response& res,
                       const std::string& description) const;
};
