#pragma once

#include "soap_client.h"
#include <nlohmann/json.hpp>
#include <string>

// ---------------------------------------------------------------------------
// SoapCalculatorService — wraps the public DNE Online Calculator SOAP service
//
// WSDL: http://www.dneonline.com/calculator.asmx?WSDL
//
// Configure with env vars:
//   SOAP_CALC_HOST — default: http://www.dneonline.com
//   SOAP_CALC_PATH — default: /calculator.asmx
//
// Exposed API routes:
//   POST /api/v1/soap/calculator/add       { "a": 5, "b": 3 }
//   POST /api/v1/soap/calculator/subtract  { "a": 9, "b": 4 }
//   POST /api/v1/soap/calculator/multiply  { "a": 6, "b": 7 }
//   POST /api/v1/soap/calculator/divide    { "a": 10, "b": 2 }
// ---------------------------------------------------------------------------
class SoapCalculatorService {
public:
    SoapCalculatorService(const std::string& host,
                          const std::string& path);

    nlohmann::json add     (int a, int b);
    nlohmann::json subtract(int a, int b);
    nlohmann::json multiply(int a, int b);
    nlohmann::json divide  (int a, int b);

private:
    SoapClient client_;

    // Build request + call + wrap result in JSON
    nlohmann::json invoke(const std::string& operation,
                          int a, int b);
};

// ---------------------------------------------------------------------------
// SoapCountryService — wraps a simple country-info SOAP service (SOAP 1.2)
//
// WSDL: http://webservices.oorsprong.org/websamples.countryinfo/CountryInfoService.wso?WSDL
//
// Exposed API routes:
//   GET  /api/v1/soap/country/:code/name     — full country name
//   GET  /api/v1/soap/country/:code/currency — currency name
//   GET  /api/v1/soap/country/:code/capital  — capital city
// ---------------------------------------------------------------------------
class SoapCountryService {
public:
    SoapCountryService(const std::string& host,
                       const std::string& path);

    nlohmann::json countryName    (const std::string& isoCode);
    nlohmann::json countryCurrency(const std::string& isoCode);
    nlohmann::json countryCapital (const std::string& isoCode);

private:
    SoapClient client_;

    // Generic invoke helper: calls the given operation with <sCountryISOCode>
    nlohmann::json invoke(const std::string& operation,
                          const std::string& resultElement,
                          const std::string& isoCode);
};
