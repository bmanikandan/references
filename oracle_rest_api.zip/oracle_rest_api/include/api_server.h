#pragma once

// CPPHTTPLIB_OPENSSL_SUPPORT is injected via CMake when OpenSSL is present.
// Do NOT define it 0 here; let the build system control it.
#include <httplib.h>
#include <nlohmann/json.hpp>

#include "auth_middleware.h"
#include "cache.h"
#include "db_connection.h"
#include "employee.h"
#include "external_api_service.h"
#include "soap_service.h"

#include <functional>
#include <memory>
#include <string>

// ---------------------------------------------------------------------------
// ApiResponse — uniform JSON envelope for all responses
//
//  Success:  { "success": true,  "data": <payload>, "meta": { ... } }
//  Error:    { "success": false, "error": { "code": N, "message": "..." } }
// ---------------------------------------------------------------------------
namespace ApiResponse {

inline nlohmann::json ok(const nlohmann::json& data,
                          const nlohmann::json& meta = nullptr) {
    nlohmann::json j;
    j["success"] = true;
    j["data"]    = data;
    if (!meta.is_null()) j["meta"] = meta;
    return j;
}

inline nlohmann::json error(int code, const std::string& message) {
    nlohmann::json j;
    j["success"]          = false;
    j["error"]["code"]    = code;
    j["error"]["message"] = message;
    return j;
}

} // namespace ApiResponse

// ---------------------------------------------------------------------------
// ApiServer — wraps httplib::Server and registers all REST routes
// ---------------------------------------------------------------------------
class ApiServer {
public:
    /**
     * @param db         Connected OracleDB instance
     * @param cache      Redis cache (injected — caching is skipped if disabled)
     * @param extSvc     External REST API service (injected)
     * @param calcSvc    SOAP Calculator service (injected)
     * @param countrySvc SOAP Country info service (injected)
     * @param host       Bind address
     * @param port       Bind port
     */
    ApiServer(OracleDB&               db,
              RedisCache&             cache,
              AuthMiddleware&         auth,
              ExternalApiService&     extSvc,
              SoapCalculatorService&  calcSvc,
              SoapCountryService&     countrySvc,
              const std::string&      host,
              int                     port);

    void listen();   // Blocks until stop() is called
    void stop();

private:
    OracleDB&              db_;
    RedisCache&            cache_;
    AuthMiddleware&        auth_;
    EmployeeDAO            dao_;
    ExternalApiService&    extSvc_;
    SoapCalculatorService& calcSvc_;
    SoapCountryService&    countrySvc_;

    httplib::Server svr_;
    std::string     host_;
    int             port_;

    void registerRoutes();

    // ---- Employees (own DB) ----
    void handleGetEmployees  (const httplib::Request&, httplib::Response&);
    void handleGetEmployee   (const httplib::Request&, httplib::Response&);
    void handleCreateEmployee(const httplib::Request&, httplib::Response&);
    void handleUpdateEmployee(const httplib::Request&, httplib::Response&);
    void handlePatchEmployee (const httplib::Request&, httplib::Response&);
    void handleDeleteEmployee(const httplib::Request&, httplib::Response&);

    // ---- External REST API (proxy / integration) ----
    void handleExtListPosts  (const httplib::Request&, httplib::Response&);
    void handleExtGetPost    (const httplib::Request&, httplib::Response&);
    void handleExtCreatePost (const httplib::Request&, httplib::Response&);
    void handleExtListUsers  (const httplib::Request&, httplib::Response&);
    void handleExtGetUser    (const httplib::Request&, httplib::Response&);

    // ---- SOAP Calculator ----
    void handleSoapAdd      (const httplib::Request&, httplib::Response&);
    void handleSoapSubtract (const httplib::Request&, httplib::Response&);
    void handleSoapMultiply (const httplib::Request&, httplib::Response&);
    void handleSoapDivide   (const httplib::Request&, httplib::Response&);

    // ---- SOAP Country info ----
    void handleCountryName    (const httplib::Request&, httplib::Response&);
    void handleCountryCurrency(const httplib::Request&, httplib::Response&);
    void handleCountryCapital (const httplib::Request&, httplib::Response&);

    // ---- Health ----
    void handleHealth(const httplib::Request&, httplib::Response&);

    // ---- Response helpers ----
    void json200(httplib::Response&, const nlohmann::json&);
    void json201(httplib::Response&, const nlohmann::json&);
    void json400(httplib::Response&, const std::string& msg);
    void json404(httplib::Response&, const std::string& msg = "Not found");
    void json422(httplib::Response&, const std::string& msg);
    void json500(httplib::Response&, const std::string& msg);
    void json502(httplib::Response&, const std::string& msg);

    // ---- Parsing helpers ----
    bool parseId  (const httplib::Request&, int64_t&,         httplib::Response&);
    bool parseInt (const httplib::Request&, const std::string& param,
                   int&, httplib::Response&);
    bool parseBody(const httplib::Request&, nlohmann::json&,   httplib::Response&);

    // ---- SOAP arithmetic helper ----
    void handleSoapArithmetic(const std::string& op,
                               const httplib::Request&, httplib::Response&);

    // ---- Cache helpers --------------------------------------------------

    /// Try to serve a cached JSON response; on MISS call `compute`, cache the
    /// result, and return it.  Adds X-Cache: HIT/MISS and Cache-Control headers.
    ///
    /// @param res      httplib response to annotate with cache headers
    /// @param key      Full Redis key (use cache_.buildKey({...}))
    /// @param ttlSec   Time-to-live for a new cache entry
    /// @param compute  Lambda () → nlohmann::json  (called only on MISS)
    /// @returns the JSON payload (whether from cache or freshly computed)
    template<typename Fn>
    nlohmann::json withCache(httplib::Response& res,
                              const std::string& key,
                              int ttlSec,
                              Fn&& compute) {
        auto cached = cache_.get(key);
        if (cached) {
            res.set_header("X-Cache",        "HIT");
            res.set_header("Cache-Control",  "max-age=" + std::to_string(ttlSec));
            res.set_header("X-Cache-Key",    key);
            return *cached;
        }

        // Cache MISS — compute the real value
        nlohmann::json result = compute();

        cache_.set(key, result, ttlSec);

        res.set_header("X-Cache",       "MISS");
        res.set_header("Cache-Control", "max-age=" + std::to_string(ttlSec));
        res.set_header("X-Cache-Key",   key);
        return result;
    }

    /// Invalidate the per-item key and all related list keys for a resource.
    /// e.g. invalidateEmployee(42) deletes:
    ///        oracle_api:v1:employees:42
    ///        oracle_api:v1:employees:list:*
    void invalidateEmployee(int64_t id);

    // ---- Auth helper ----------------------------------------------------

    /// Shorthand: wrap handler with Bearer-token auth (and optional scope).
    /// When OAUTH_ENABLED=false this is a transparent pass-through.
    httplib::Server::Handler guard(httplib::Server::Handler h) {
        return auth_.require(std::move(h));
    }
    httplib::Server::Handler guardScope(const std::string& scope,
                                         httplib::Server::Handler h) {
        return auth_.requireScope(scope, std::move(h));
    }
};
