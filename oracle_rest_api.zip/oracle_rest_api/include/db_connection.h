#pragma once

// Oracle OCI (Call Interface) headers
#include <oci.h>

#include <cstdint>
#include <functional>
#include <map>
#include <stdexcept>
#include <string>
#include <vector>

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

/// A single result-set row: column_name (upper-case) → string value.
using Row       = std::map<std::string, std::string>;
using ResultSet = std::vector<Row>;

// ---------------------------------------------------------------------------
// Exception
// ---------------------------------------------------------------------------

class DBException : public std::runtime_error {
public:
    int ociCode = 0;

    explicit DBException(const std::string& msg, int code = 0)
        : std::runtime_error(msg), ociCode(code) {}
};

// ---------------------------------------------------------------------------
// OracleStmt — RAII wrapper around an OCI statement handle.
//
// Typical usage:
//
//   OracleStmt stmt(svc, err, "SELECT * FROM employees WHERE id = :1");
//   stmt.bindString(1, "42");
//   auto rows = stmt.fetchAll();
//
// For DML:
//   OracleStmt stmt(svc, err, "DELETE FROM employees WHERE id = :1");
//   stmt.bindString(1, id);
//   ub4 affected = stmt.executeUpdate();
// ---------------------------------------------------------------------------

class OracleStmt {
public:
    OracleStmt(OCISvcCtx* svc, OCIError* err, const std::string& sql);
    ~OracleStmt();

    // Non-copyable
    OracleStmt(const OracleStmt&)            = delete;
    OracleStmt& operator=(const OracleStmt&) = delete;

    // ---- Bind input parameters (1-based position) ----
    void bindString(ub4 pos, const std::string& value);
    void bindInt64 (ub4 pos, int64_t value);

    // ---- Execute SELECT, return all rows ----
    ResultSet fetchAll();

    // ---- Execute DML (INSERT / UPDATE / DELETE) ----
    // Returns number of rows processed.
    ub4 executeUpdate();

    // ---- Execute INSERT with RETURNING id INTO :ret_id ----
    // SQL must end with: RETURNING id INTO :ret_id
    // Returns the generated id.
    int64_t executeInsertReturning();

private:
    OCIStmt*   stmt_ = nullptr;
    OCISvcCtx* svc_;
    OCIError*  err_;

    // Bind storage — pointers must stay alive until after OCIStmtExecute.
    struct BindEntry {
        std::string strVal;   // used when !isInt
        int64_t     intVal = 0;
        bool        isInt  = false;
    };
    std::vector<BindEntry> binds_;

    // For RETURNING clause output
    int64_t returnId_ = 0;

    void checkErr(sword status, const char* context = "") const;
    std::string buildErrMsg(sword status) const;

    // Build column defines after execution and fetch rows.
    ResultSet collectRows();
};

// ---------------------------------------------------------------------------
// OracleDB — Manages the OCI environment, error handle, and service context.
//
// One OracleDB object = one database connection.
// For multi-threaded servers create one connection per thread or use a pool.
// ---------------------------------------------------------------------------

class OracleDB {
public:
    /**
     * @param user     Oracle username       (e.g. "hr")
     * @param password Oracle password
     * @param dsn      Easy Connect string   (e.g. "localhost:1521/XEPDB1")
     *                 or TNS alias          (e.g. "ORCL")
     */
    OracleDB(const std::string& user,
             const std::string& password,
             const std::string& dsn);
    ~OracleDB();

    // Non-copyable
    OracleDB(const OracleDB&)            = delete;
    OracleDB& operator=(const OracleDB&) = delete;

    // ---- Query helpers ----

    /// Run a SELECT. Optionally call `binder` to bind parameters before exec.
    ResultSet query(const std::string& sql,
                    std::function<void(OracleStmt&)> binder = nullptr);

    /// Run DML. Returns rows affected. Commits on success.
    ub4 execute(const std::string& sql,
                std::function<void(OracleStmt&)> binder = nullptr);

    /// Run INSERT … RETURNING id INTO :ret_id. Commits on success.
    int64_t insert(const std::string& sql,
                   std::function<void(OracleStmt&)> binder = nullptr);

    bool isConnected() const { return connected_; }

    // Direct handle access (for advanced use)
    OCISvcCtx* svc() const { return svc_; }
    OCIError*  err() const { return err_; }

private:
    OCIEnv*    env_       = nullptr;
    OCIError*  err_       = nullptr;
    OCISvcCtx* svc_       = nullptr;
    bool       connected_ = false;

    void initEnv();
    void connect(const std::string& user,
                 const std::string& password,
                 const std::string& dsn);
    void checkErr(sword status, const char* context = "") const;
};
