#pragma once

#include <hiredis/hiredis.h>
#include <nlohmann/json.hpp>

#include <atomic>
#include <cstdint>
#include <initializer_list>
#include <map>
#include <mutex>
#include <optional>
#include <string>

// ---------------------------------------------------------------------------
// RedisCache — thread-safe Redis cache built on the hiredis C library.
//
// Design decisions
// ─────────────────
// • Single connection + mutex: simple, correct for moderate concurrency.
//   For high-throughput services replace with a connection pool.
// • "Fail-open": any Redis error is logged and the request continues without
//   cache (the origin is always the source of truth).
// • JSON is stored as a UTF-8 string (JSON.stringify), making it easy to
//   inspect directly in redis-cli.
// • Key namespace: "<prefix><parts joined by ':'>".
// • SCAN-based pattern deletion: non-blocking even on large keyspaces.
// ---------------------------------------------------------------------------
class RedisCache {
public:
    // ---- Configuration (all fields have sensible defaults) ----
    struct Config {
        std::string host         = "127.0.0.1";
        int         port         = 6379;
        int         db           = 0;           // SELECT <db> on connect
        std::string password;                   // AUTH — empty means no auth
        int         connectMs    = 2000;        // connection timeout (ms)
        std::string keyPrefix    = "oracle_api:v1:";
        bool        enabled      = true;        // false → caching disabled
    };

    // ---- Pre-defined TTL tiers (seconds) ----
    static constexpr int TTL_SHORT  =   60;    // volatile DB rows
    static constexpr int TTL_MEDIUM =  300;    // external REST responses
    static constexpr int TTL_LONG   = 3600;    // stable reference data

    explicit RedisCache(const Config& cfg);
    ~RedisCache();

    // Non-copyable — owns the redisContext*
    RedisCache(const RedisCache&)            = delete;
    RedisCache& operator=(const RedisCache&) = delete;

    // ---- Core operations ------------------------------------------------

    /// GET key → parsed JSON on HIT, std::nullopt on MISS or Redis error.
    std::optional<nlohmann::json> get(const std::string& key);

    /// SET key (JSON) EX ttlSec — silent on error.
    void set(const std::string& key, const nlohmann::json& value, int ttlSec);

    /// DEL key — silent on error.
    void del(const std::string& key);

    /// Delete all keys matching a glob pattern using a non-blocking SCAN loop.
    /// Returns the number of keys deleted.
    int delByPattern(const std::string& pattern);

    // ---- Key builders ---------------------------------------------------

    /// Join parts with ":" and prepend cfg.keyPrefix.
    /// buildKey({"employees","42"}) → "oracle_api:v1:employees:42"
    std::string buildKey(std::initializer_list<std::string> parts) const;

    /// Serialise a sorted param map as "k1=v1&k2=v2" for use in list keys.
    static std::string paramsKey(const std::map<std::string, std::string>& params);

    // ---- Status ---------------------------------------------------------

    /// Send PING to Redis. Returns true if reachable.
    bool ping();

    bool isEnabled()   const { return cfg_.enabled; }
    bool isConnected() const;   // lock-free, approximate

    // ---- Stats (atomics — safe to read from any thread) -----------------
    struct Stats {
        uint64_t hits   = 0;
        uint64_t misses = 0;
        uint64_t errors = 0;
        uint64_t sets   = 0;
        uint64_t dels   = 0;
    };
    Stats getStats() const;

private:
    Config        cfg_;
    redisContext* ctx_  = nullptr;
    mutable std::mutex  mtx_;

    // Atomic snapshot of connection state (avoid taking lock just to check)
    std::atomic<bool> connected_{false};

    // Stats counters (protected by mtx_ for consistency, not performance)
    mutable Stats stats_;

    bool tryConnect();
    bool ensureConnected();   // called with mtx_ held
    void doDisconnect();      // called with mtx_ held

    // Execute one Redis command. Caller must freeReplyObject the result.
    // Returns nullptr on any error (already logged + disconnected).
    // Must be called with mtx_ held.
    redisReply* runCmd(const char* fmt, ...)
        __attribute__((format(printf, 2, 3)));
};
