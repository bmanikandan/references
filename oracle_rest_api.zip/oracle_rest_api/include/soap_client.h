#pragma once

#include <httplib.h>
#include <tinyxml2.h>

#include <functional>
#include <map>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

// ---------------------------------------------------------------------------
// SoapException
// ---------------------------------------------------------------------------
class SoapException : public std::runtime_error {
public:
    std::string faultCode;
    std::string faultString;

    explicit SoapException(const std::string& msg,
                           const std::string& code   = "",
                           const std::string& detail = "")
        : std::runtime_error(msg), faultCode(code), faultString(detail) {}
};

// ---------------------------------------------------------------------------
// SoapVersion — controls envelope namespace and Content-Type
// ---------------------------------------------------------------------------
enum class SoapVersion { SOAP_1_1, SOAP_1_2 };

// ---------------------------------------------------------------------------
// SoapRequest — describes one outgoing SOAP call
// ---------------------------------------------------------------------------
struct SoapRequest {
    std::string action;          // SOAPAction header value (SOAP 1.1)
                                 // or action parameter   (SOAP 1.2)
    std::string bodyXml;         // XML placed inside <soap:Body>
    std::string targetNamespace; // Used in envelope namespace declarations

    // Optional per-call headers inserted into <soap:Header>
    std::string headerXml;

    SoapVersion version = SoapVersion::SOAP_1_1;
};

// ---------------------------------------------------------------------------
// SoapResponse — parsed result of a SOAP call
// ---------------------------------------------------------------------------
struct SoapResponse {
    bool        success = false;
    std::string rawXml;           // Full response envelope

    // Convenient access to values from the Body
    // e.g.  resp.bodyValues["AddResult"]  → "8"
    std::map<std::string, std::string> bodyValues;

    // Fault details (populated when success == false)
    std::string faultCode;
    std::string faultString;
    std::string faultDetail;

    // Low-level XML access for advanced parsing
    tinyxml2::XMLDocument doc;

    /// Find the first element with the given local name anywhere in the Body.
    const tinyxml2::XMLElement* findBodyElement(const std::string& localName) const;

    /// Return text content of the first element matching localName.
    std::string valueOf(const std::string& localName,
                        const std::string& defaultVal = "") const;
};

// ---------------------------------------------------------------------------
// SoapClient — generic SOAP 1.1 / 1.2 client
//
// Example — SOAP 1.1 call to a calculator service:
//
//   SoapClient client("http://www.dneonline.com", "/calculator.asmx");
//
//   SoapRequest req;
//   req.action          = "http://tempuri.org/Add";
//   req.targetNamespace = "http://tempuri.org/";
//   req.bodyXml = R"(
//     <tns:Add>
//       <tns:intA>5</tns:intA>
//       <tns:intB>3</tns:intB>
//     </tns:Add>)";
//
//   auto resp = client.call(req);
//   std::cout << resp.valueOf("AddResult");   // → "8"
// ---------------------------------------------------------------------------
class SoapClient {
public:
    /**
     * @param host        Scheme + host, e.g. "http://example.com"
     * @param servicePath URL path to the SOAP endpoint, e.g. "/Service.asmx"
     * @param timeoutSec  Read timeout in seconds (default 30)
     */
    SoapClient(const std::string& host,
               const std::string& servicePath,
               int timeoutSec = 30);

    // Perform the SOAP call. Throws SoapException on network or SOAP fault.
    SoapResponse call(const SoapRequest& req);

    // Attach a custom HTTP header to every request (e.g. auth tokens)
    void setHeader(const std::string& name, const std::string& value);

private:
    std::unique_ptr<httplib::Client> cli_;
    std::string servicePath_;
    httplib::Headers extraHeaders_;

    // Build the full SOAP envelope string
    std::string buildEnvelope(const SoapRequest& req) const;

    // Parse the HTTP response body into a SoapResponse
    SoapResponse parseResponse(const std::string& xmlBody,
                               SoapVersion         version) const;

    // Walk an XMLElement tree collecting text-node children
    void collectValues(const tinyxml2::XMLElement* elem,
                       std::map<std::string, std::string>& out) const;

    // Strip namespace prefix: "tns:AddResult" → "AddResult"
    static std::string localName(const char* qualifiedName);

    // Recursively find first element by local name
    static const tinyxml2::XMLElement*
    findByLocalName(const tinyxml2::XMLElement* root,
                    const std::string& localName);
};
