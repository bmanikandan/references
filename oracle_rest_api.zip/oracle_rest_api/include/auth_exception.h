#pragma once

#include <chrono>
#include <cstdint>
#include <map>
#include <stdexcept>
#include <string>
#include <vector>

// ---------------------------------------------------------------------------
// TokenClaims — decoded and validated JWT payload
// ---------------------------------------------------------------------------
struct TokenClaims {
    std::string              subject;    // "sub" — user/service identifier
    std::string              issuer;     // "iss" — authorization server URL
    std::vector<std::string> audiences;  // "aud" — intended recipients
    std::vector<std::string> scopes;     // "scope" split on spaces
    std::string              keyId;      // "kid" from header

    // Standard timing claims (Unix epoch seconds)
    int64_t expiresAt  = 0;   // "exp"
    int64_t issuedAt   = 0;   // "iat"
    int64_t notBefore  = 0;   // "nbf"

    // Extra string-valued claims (roles, tenant, etc.)
    std::map<std::string, std::string> extra;

    bool hasScope(const std::string& s) const {
        for (const auto& sc : scopes) if (sc == s) return true;
        return false;
    }
};

// ---------------------------------------------------------------------------
// AuthErrorKind — machine-readable reason for authentication failure
// ---------------------------------------------------------------------------
enum class AuthErrorKind {
    MissingToken,        // No Authorization header present
    MalformedToken,      // Header present but not a valid JWT
    InvalidSignature,    // Crypto verification failed
    ExpiredToken,        // exp claim is in the past
    NotYetValid,         // nbf claim is in the future
    InvalidClaims,       // iss / aud / nbf mismatch
    KeyNotFound,         // kid not found in JWKS after refresh
    JwksFetchFailed,     // Could not reach JWKS endpoint
    AlgorithmNotAllowed, // alg header not in the permitted set
};

// ---------------------------------------------------------------------------
// AuthException — carries kind + RFC 6750 error string
//
// RFC 6750 §3.1 defines three error codes for the WWW-Authenticate header:
//   invalid_request  — request itself is malformed
//   invalid_token    — token is expired, revoked, or otherwise bad
//   insufficient_scope — token lacks required scope
// ---------------------------------------------------------------------------
class AuthException : public std::runtime_error {
public:
    AuthErrorKind kind;

    AuthException(AuthErrorKind k, const std::string& msg)
        : std::runtime_error(msg), kind(k) {}

    /// Returns the RFC 6750 error= parameter value, or "" to omit the field.
    const char* rfc6750Error() const noexcept {
        switch (kind) {
            case AuthErrorKind::MissingToken:        return "";            // 401, no error field
            case AuthErrorKind::JwksFetchFailed:     return "server_error";
            default:                                 return "invalid_token";
        }
    }
};
