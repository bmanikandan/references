#pragma once

#include "auth_exception.h"
#include "cache.h"
#include "http_client.h"

#include <map>
#include <memory>
#include <mutex>
#include <string>
#include <vector>
#include <cstdint>

// ---------------------------------------------------------------------------
// JwksProvider — fetches and caches public keys from a JWKS endpoint.
//
// Flow
// ────
//  getPublicKeyPem(kid, alg)
//    1. Check in-memory map  (fastest, zero network/Redis)
//    2. Check Redis cache     (fast, survives process restart)
//    3. Fetch full JWKS JSON from endpoint
//       → parse all keys, store each in Redis + memory
//    4. If kid still missing → allow ONE forced refresh
//       (handles key rotation where the old kid was cached)
//    5. Throw KeyNotFound if key genuinely absent
//
// Supported key types
// ───────────────────
//   RSA  — constructed from JWK "n" + "e" fields (PKCS#1 → SubjectPublicKeyInfo PEM)
//   EC   — constructed from JWK "crv" + "x" + "y"  (P-256 / P-384 / P-521)
//   x5c  — extracted from the first DER certificate in the chain
// ---------------------------------------------------------------------------
class JwksProvider {
public:
    struct Config {
        std::string jwksUri;           // Full URL to JWKS endpoint
        int         cacheTtlSec = 3600; // Redis TTL for cached key PEMs
        int         fetchTimeoutSec = 10;
    };

    JwksProvider(const Config& cfg, RedisCache& cache);

    // Returns SubjectPublicKeyInfo PEM for the given kid.
    // Throws AuthException on failure.
    std::string getPublicKeyPem(const std::string& kid,
                                const std::string& alg);

    // Force a JWKS refresh (called externally on unexpected kid-miss).
    void forceRefresh();

private:
    Config      cfg_;
    RedisCache& cache_;
    std::unique_ptr<HttpClient> http_;

    std::mutex                       mtx_;
    std::map<std::string, std::string> memCache_;  // kid → PEM
    bool                             freshFetched_ = false; // already tried this second?

    // Fetch JWKS JSON from the URI and populate caches.
    void fetchAndCache();

    // Parse a JWKS JSON object (array of JWK objects).
    void parseJwks(const std::string& jwksJson);

    // Store one key in both Redis and the in-memory map.
    void storeKey(const std::string& kid, const std::string& pem);

    // ---- Key construction (OpenSSL) ----

    // RSA: derive SubjectPublicKeyInfo PEM from base64url n and e.
    static std::string rsaJwkToPem(const std::string& n_b64url,
                                    const std::string& e_b64url);

    // EC: derive SubjectPublicKeyInfo PEM from crv, base64url x and y.
    // crv must be "P-256", "P-384", or "P-521".
    static std::string ecJwkToPem(const std::string& crv,
                                   const std::string& x_b64url,
                                   const std::string& y_b64url);

    // x5c: extract SubjectPublicKeyInfo PEM from the first base64-encoded DER cert.
    static std::string x5cToPem(const std::string& x5c_b64);

    // ---- Base64 helpers ----
    static std::vector<uint8_t> b64urlDecode(const std::string& input);
    static std::vector<uint8_t> b64Decode(const std::string& input);

    // Parse scheme://host[:port]/path from a URL.
    static void splitUrl(const std::string& url,
                         std::string& scheme,
                         std::string& host,
                         int&         port,
                         std::string& path);
};
