-- =============================================================================
-- Oracle REST API — Database Schema
-- Compatible with Oracle Database 12c Release 2 and later (including 19c, 21c)
-- Run as the schema owner (e.g. hr) or a DBA granting privileges accordingly.
-- =============================================================================

-- ---------------------------------------------------------------------------
-- Sequence for auto-increment employee IDs
-- (Oracle 12c+ also supports IDENTITY columns; we use a sequence here so that
--  RETURNING id INTO :ret_id works cleanly in OCI.)
-- ---------------------------------------------------------------------------
CREATE SEQUENCE employees_seq
    START WITH 1
    INCREMENT BY 1
    NOCACHE
    NOCYCLE;

-- ---------------------------------------------------------------------------
-- Employees table
-- ---------------------------------------------------------------------------
CREATE TABLE employees (
    id          NUMBER(19)      DEFAULT employees_seq.NEXTVAL  NOT NULL,
    name        VARCHAR2(200)                                   NOT NULL,
    email       VARCHAR2(255)                                   NOT NULL,
    department  VARCHAR2(100),
    salary      NUMBER(12, 2)   DEFAULT 0                      NOT NULL,
    created_at  TIMESTAMP       DEFAULT CURRENT_TIMESTAMP      NOT NULL,

    CONSTRAINT pk_employees   PRIMARY KEY (id),
    CONSTRAINT uq_emp_email   UNIQUE      (email),
    CONSTRAINT ck_emp_salary  CHECK       (salary >= 0),
    CONSTRAINT ck_emp_name    CHECK       (LENGTH(TRIM(name))  > 0),
    CONSTRAINT ck_emp_email   CHECK       (email LIKE '%@%')
);

-- Index for common filter (department lookup)
CREATE INDEX idx_emp_department ON employees (department);

-- ---------------------------------------------------------------------------
-- Seed data (optional — comment out in production)
-- ---------------------------------------------------------------------------
INSERT INTO employees (name, email, department, salary)
VALUES ('Alice Johnson', 'alice@example.com', 'Engineering', 95000);

INSERT INTO employees (name, email, department, salary)
VALUES ('Bob Smith', 'bob@example.com', 'Marketing', 72000);

INSERT INTO employees (name, email, department, salary)
VALUES ('Carol White', 'carol@example.com', 'Engineering', 88000);

INSERT INTO employees (name, email, department, salary)
VALUES ('David Brown', 'david@example.com', 'HR', 65000);

INSERT INTO employees (name, email, department, salary)
VALUES ('Eva Martinez', 'eva@example.com', 'Engineering', 102000);

COMMIT;

-- ---------------------------------------------------------------------------
-- Verify
-- ---------------------------------------------------------------------------
SELECT id, name, email, department, salary,
       TO_CHAR(created_at, 'YYYY-MM-DD HH24:MI:SS') AS created_at
FROM   employees
ORDER  BY id;
