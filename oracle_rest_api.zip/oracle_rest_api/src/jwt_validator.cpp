#include "jwt_validator.h"

// jwt-cpp — header-only, uses bundled picojson
#include <jwt-cpp/jwt.h>

#include <algorithm>
#include <chrono>
#include <iostream>
#include <sstream>
#include <stdexcept>

// ============================================================================
// Construction
// ============================================================================

JwtValidator::JwtValidator(const Config& cfg, JwksProvider& jwks)
    : cfg_(cfg), jwks_(jwks) {}

// ============================================================================
// Public: validate
// ============================================================================

TokenClaims JwtValidator::validate(const std::string& authHeaderValue) const {
    // ---- Step 1: extract raw token ----
    const std::string token = extractBearer(authHeaderValue);

    // ---- Step 2: decode (no crypto, just parse header + payload) ----
    jwt::decoded_jwt<jwt::traits::kazuho_picojson> decoded;
    try {
        decoded = jwt::decode(token);
    } catch (const std::exception& e) {
        throw AuthException(AuthErrorKind::MalformedToken,
                            std::string("JWT decode failed: ") + e.what());
    }

    // ---- Step 3: read kid and alg from header ----
    std::string kid, alg;
    try {
        kid = decoded.get_key_id();      // "kid" header — may be empty
        alg = decoded.get_algorithm();   // "alg" header — e.g. "RS256"
    } catch (...) {
        throw AuthException(AuthErrorKind::MalformedToken,
                            "JWT header missing kid or alg");
    }

    // ---- Step 4: check algorithm is allowed ----
    if (!cfg_.allowedAlgorithms.empty() &&
        cfg_.allowedAlgorithms.find(alg) == cfg_.allowedAlgorithms.end()) {
        throw AuthException(AuthErrorKind::AlgorithmNotAllowed,
                            "Algorithm '" + alg + "' is not allowed");
    }

    // ---- Step 5: get public key from JWKS (cached) ----
    std::string pemKey;
    try {
        pemKey = jwks_.getPublicKeyPem(kid, alg);
    } catch (const AuthException&) {
        throw;  // propagate as-is
    } catch (const std::exception& e) {
        throw AuthException(AuthErrorKind::JwksFetchFailed, e.what());
    }

    // ---- Step 6+7: verify signature + claims ----
    return verifyWithKey(token, alg, pemKey);
}

// ============================================================================
// verifyWithKey — dispatch by alg, then verify with jwt-cpp
// ============================================================================

TokenClaims JwtValidator::verifyWithKey(const std::string& token,
                                         const std::string& alg,
                                         const std::string& pemKey) const {
    // Build a jwt-cpp verifier with the right algorithm.
    // jwt-cpp verifier is not polymorphic — we must select the algorithm
    // at compile time. We handle this via a dispatch lambda.

    // Verifier factory:  alg string → verify(decoded) call
    auto doVerify = [&](auto verifier) {
        auto decoded = jwt::decode(token);

        if (!cfg_.issuer.empty())
            verifier = std::move(verifier).with_issuer(cfg_.issuer);

        if (!cfg_.audience.empty())
            verifier = std::move(verifier).with_audience(cfg_.audience);

        // Clock skew: leeway for exp and nbf
        verifier = std::move(verifier).leeway(
            std::chrono::seconds(cfg_.clockSkewSec));

        try {
            verifier.verify(decoded);
        } catch (const jwt::error::token_verification_exception& e) {
            const std::string msg = e.what();
            if (msg.find("expired") != std::string::npos)
                throw AuthException(AuthErrorKind::ExpiredToken, msg);
            if (msg.find("issuer") != std::string::npos ||
                msg.find("audience") != std::string::npos)
                throw AuthException(AuthErrorKind::InvalidClaims, msg);
            throw AuthException(AuthErrorKind::InvalidSignature, msg);
        } catch (const std::exception& e) {
            throw AuthException(AuthErrorKind::InvalidSignature, e.what());
        }

        // ---- Step 8: extract claims ----
        TokenClaims claims;
        try { claims.subject = decoded.get_subject(); } catch (...) {}
        try { claims.issuer  = decoded.get_issuer();  } catch (...) {}
        try {
            auto exp = decoded.get_expires_at();
            claims.expiresAt = std::chrono::duration_cast<std::chrono::seconds>(
                exp.time_since_epoch()).count();
        } catch (...) {}
        try {
            auto iat = decoded.get_issued_at();
            claims.issuedAt = std::chrono::duration_cast<std::chrono::seconds>(
                iat.time_since_epoch()).count();
        } catch (...) {}

        // Audience — can be a string or array in the JWT
        try {
            auto aud = decoded.get_audience();
            claims.audiences.assign(aud.begin(), aud.end());
        } catch (...) {}

        // Key ID
        try { claims.keyId = decoded.get_key_id(); } catch (...) {}

        // Scopes
        try {
            auto scope = decoded.get_payload_claim("scope")
                                .as_string();
            claims.scopes = parseScopes(scope);
        } catch (...) {}

        // Extra claims (any remaining string-valued payload entries)
        try {
            for (const auto& [k, v] : decoded.get_payload_claims()) {
                if (k == "sub" || k == "iss" || k == "aud" ||
                    k == "exp" || k == "iat" || k == "nbf" ||
                    k == "scope") continue;
                try {
                    claims.extra[k] = v.as_string();
                } catch (...) {}
            }
        } catch (...) {}

        return claims;
    };

    // ---- Algorithm dispatch ----
    if (alg == "RS256") return doVerify(jwt::verify().allow_algorithm(jwt::algorithm::rs256(pemKey)));
    if (alg == "RS384") return doVerify(jwt::verify().allow_algorithm(jwt::algorithm::rs384(pemKey)));
    if (alg == "RS512") return doVerify(jwt::verify().allow_algorithm(jwt::algorithm::rs512(pemKey)));
    if (alg == "ES256") return doVerify(jwt::verify().allow_algorithm(jwt::algorithm::es256(pemKey)));
    if (alg == "ES384") return doVerify(jwt::verify().allow_algorithm(jwt::algorithm::es384(pemKey)));
    if (alg == "ES512") return doVerify(jwt::verify().allow_algorithm(jwt::algorithm::es512(pemKey)));
    if (alg == "PS256") return doVerify(jwt::verify().allow_algorithm(jwt::algorithm::ps256(pemKey)));
    if (alg == "PS384") return doVerify(jwt::verify().allow_algorithm(jwt::algorithm::ps384(pemKey)));
    if (alg == "PS512") return doVerify(jwt::verify().allow_algorithm(jwt::algorithm::ps512(pemKey)));

    throw AuthException(AuthErrorKind::AlgorithmNotAllowed,
                        "Unsupported algorithm: " + alg);
}

// ============================================================================
// Helpers
// ============================================================================

std::string JwtValidator::extractBearer(const std::string& headerValue) {
    if (headerValue.empty())
        throw AuthException(AuthErrorKind::MissingToken,
                            "Authorization header is missing");

    // Case-insensitive prefix match for "Bearer "
    const std::string prefix = "Bearer ";
    if (headerValue.size() <= prefix.size() ||
        !std::equal(prefix.begin(), prefix.end(), headerValue.begin(),
                    [](char a, char b) {
                        return std::tolower((unsigned char)a) ==
                               std::tolower((unsigned char)b);
                    })) {
        throw AuthException(AuthErrorKind::MalformedToken,
                            "Authorization header must use Bearer scheme");
    }

    std::string token = headerValue.substr(prefix.size());
    // Trim leading/trailing whitespace
    auto l = token.find_first_not_of(' ');
    auto r = token.find_last_not_of(' ');
    if (l == std::string::npos)
        throw AuthException(AuthErrorKind::MalformedToken, "Bearer token is empty");

    return token.substr(l, r - l + 1);
}

std::vector<std::string> JwtValidator::parseScopes(const std::string& scope) {
    std::vector<std::string> result;
    std::istringstream ss(scope);
    std::string s;
    while (ss >> s) result.push_back(s);
    return result;
}
