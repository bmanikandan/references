#include "db_connection.h"

#include <cstring>
#include <sstream>

// ============================================================================
// Internal helpers
// ============================================================================

static std::string ociGetError(sword status, OCIError* errhp) {
    if (status == OCI_SUCCESS) return "OCI_SUCCESS";

    if (!errhp) {
        switch (status) {
            case OCI_SUCCESS_WITH_INFO: return "OCI_SUCCESS_WITH_INFO";
            case OCI_NEED_DATA:         return "OCI_NEED_DATA";
            case OCI_NO_DATA:           return "OCI_NO_DATA";
            case OCI_INVALID_HANDLE:    return "OCI_INVALID_HANDLE";
            case OCI_STILL_EXECUTING:   return "OCI_STILL_EXECUTING";
            case OCI_CONTINUE:          return "OCI_CONTINUE";
            default: {
                std::ostringstream oss;
                oss << "Unknown OCI error status: " << status;
                return oss.str();
            }
        }
    }

    char buf[2048] = {};
    sb4  errCode   = 0;
    OCIErrorGet(errhp, 1, nullptr, &errCode, (text*)buf, sizeof(buf) - 1,
                OCI_HTYPE_ERROR);

    std::ostringstream oss;
    oss << "OCI-" << errCode << ": " << buf;
    return oss.str();
}

// ============================================================================
// OracleStmt
// ============================================================================

OracleStmt::OracleStmt(OCISvcCtx* svc, OCIError* err, const std::string& sql)
    : svc_(svc), err_(err) {
    sword rc = OCIStmtPrepare2(
        svc_,
        &stmt_,
        err_,
        (const OraText*)sql.c_str(),
        (ub4)sql.size(),
        nullptr,   // key (no statement cache key)
        0,
        OCI_NTV_SYNTAX,
        OCI_DEFAULT
    );
    checkErr(rc, "OCIStmtPrepare2");
}

OracleStmt::~OracleStmt() {
    if (stmt_) {
        // OCI_DEFAULT releases back to stmt cache; OCI_STRLS_CACHE_DELETE removes it.
        OCIStmtRelease(stmt_, err_, nullptr, 0, OCI_DEFAULT);
        stmt_ = nullptr;
    }
}

// ---------------------------------------------------------------------------
void OracleStmt::checkErr(sword status, const char* context) const {
    if (status == OCI_SUCCESS || status == OCI_SUCCESS_WITH_INFO) return;
    if (status == OCI_NO_DATA) return; // callers handle OCI_NO_DATA separately

    std::string msg = ociGetError(status, err_);
    if (context && *context) msg = std::string(context) + ": " + msg;

    sb4 errCode = 0;
    if (err_) {
        char buf[2048] = {};
        OCIErrorGet(err_, 1, nullptr, &errCode, (text*)buf, sizeof(buf) - 1, OCI_HTYPE_ERROR);
    }
    throw DBException(msg, (int)errCode);
}

// ---------------------------------------------------------------------------
void OracleStmt::bindString(ub4 pos, const std::string& value) {
    if (pos == 0 || pos > binds_.size() + 1) {
        binds_.resize(pos); // ensure slot exists
    }

    BindEntry entry;
    entry.strVal = value;
    entry.isInt  = false;
    binds_.resize(std::max((size_t)pos, binds_.size()));
    binds_[pos - 1] = std::move(entry);

    OCIBind* bndp = nullptr;
    const std::string& sv = binds_[pos - 1].strVal;

    sword rc = OCIBindByPos(
        stmt_, &bndp, err_,
        pos,
        (dvoid*)sv.c_str(),
        (sb4)(sv.size() + 1),  // +1 for null terminator
        SQLT_STR,
        nullptr, nullptr, nullptr, 0, nullptr,
        OCI_DEFAULT
    );
    checkErr(rc, "OCIBindByPos(string)");
}

// ---------------------------------------------------------------------------
void OracleStmt::bindInt64(ub4 pos, int64_t value) {
    binds_.resize(std::max((size_t)pos, binds_.size()));
    binds_[pos - 1].intVal = value;
    binds_[pos - 1].isInt  = true;

    OCIBind* bndp = nullptr;
    sword rc = OCIBindByPos(
        stmt_, &bndp, err_,
        pos,
        (dvoid*)&binds_[pos - 1].intVal,
        sizeof(int64_t),
        SQLT_INT,
        nullptr, nullptr, nullptr, 0, nullptr,
        OCI_DEFAULT
    );
    checkErr(rc, "OCIBindByPos(int64)");
}

// ---------------------------------------------------------------------------
ResultSet OracleStmt::fetchAll() {
    // Execute SELECT (iters=0 for queries)
    sword rc = OCIStmtExecute(svc_, stmt_, err_,
                              0,           // iters: 0 for SELECT
                              0, nullptr, nullptr,
                              OCI_DEFAULT);
    checkErr(rc, "OCIStmtExecute(SELECT)");

    return collectRows();
}

// ---------------------------------------------------------------------------
ResultSet OracleStmt::collectRows() {
    // Determine column count
    ub4 numCols = 0;
    sword rc = OCIAttrGet(stmt_, OCI_HTYPE_STMT,
                          &numCols, nullptr,
                          OCI_ATTR_PARAM_COUNT, err_);
    checkErr(rc, "OCIAttrGet(PARAM_COUNT)");

    if (numCols == 0) return {};

    // ---- Per-column metadata and output buffers ----
    constexpr ub4 BUF_SZ = 4096;

    struct ColInfo {
        std::string  name;
        char         data[BUF_SZ];
        sb2          indicator = 0;
        ub2          retLen    = 0;
    };

    std::vector<ColInfo>    cols(numCols);
    std::vector<OCIDefine*> defs(numCols, nullptr);

    for (ub4 i = 0; i < numCols; i++) {
        OCIParam* param = nullptr;
        rc = OCIParamGet(stmt_, OCI_HTYPE_STMT, err_,
                         (void**)&param, i + 1);
        checkErr(rc, "OCIParamGet");

        // Column name
        OraText* namePtr = nullptr;
        ub4      nameLen = 0;
        OCIAttrGet(param, OCI_DTYPE_PARAM,
                   &namePtr, &nameLen,
                   OCI_ATTR_NAME, err_);
        cols[i].name = std::string((char*)namePtr, nameLen);

        OCIDescriptorFree(param, OCI_DTYPE_PARAM);

        // Define output as VARCHAR string
        memset(cols[i].data, 0, BUF_SZ);
        rc = OCIDefineByPos(
            stmt_, &defs[i], err_,
            i + 1,
            (dvoid*)cols[i].data,
            BUF_SZ,
            SQLT_STR,
            (dvoid*)&cols[i].indicator,
            &cols[i].retLen,
            nullptr,
            OCI_DEFAULT
        );
        checkErr(rc, "OCIDefineByPos");
    }

    // ---- Fetch loop ----
    ResultSet result;
    sword status;
    while (true) {
        status = OCIStmtFetch2(stmt_, err_, 1, OCI_FETCH_NEXT, 0, OCI_DEFAULT);
        if (status == OCI_NO_DATA) break;
        if (status != OCI_SUCCESS && status != OCI_SUCCESS_WITH_INFO) {
            checkErr(status, "OCIStmtFetch2");
        }

        Row row;
        for (ub4 i = 0; i < numCols; i++) {
            if (cols[i].indicator == OCI_IND_NULL) {
                row[cols[i].name] = "";   // NULL → empty string
            } else {
                row[cols[i].name] = std::string(cols[i].data);
            }
        }
        result.push_back(std::move(row));
    }

    return result;
}

// ---------------------------------------------------------------------------
ub4 OracleStmt::executeUpdate() {
    // iters=1 for DML
    sword rc = OCIStmtExecute(svc_, stmt_, err_,
                              1, 0, nullptr, nullptr,
                              OCI_DEFAULT);
    checkErr(rc, "OCIStmtExecute(DML)");

    ub4 rowsProcessed = 0;
    OCIAttrGet(stmt_, OCI_HTYPE_STMT,
               &rowsProcessed, nullptr,
               OCI_ATTR_ROW_COUNT, err_);
    return rowsProcessed;
}

// ---------------------------------------------------------------------------
int64_t OracleStmt::executeInsertReturning() {
    // The caller's SQL must end with: RETURNING id INTO :ret_id
    // Bind the output variable here.
    returnId_ = 0;
    OCIBind* bndp = nullptr;
    sword rc = OCIBindByName(
        stmt_, &bndp, err_,
        (text*)":ret_id", -1,
        (dvoid*)&returnId_,
        sizeof(returnId_),
        SQLT_INT,
        nullptr, nullptr, nullptr, 0, nullptr,
        OCI_DEFAULT
    );
    checkErr(rc, "OCIBindByName(:ret_id)");

    rc = OCIStmtExecute(svc_, stmt_, err_,
                        1, 0, nullptr, nullptr,
                        OCI_DEFAULT);
    checkErr(rc, "OCIStmtExecute(INSERT RETURNING)");

    return returnId_;
}

// ============================================================================
// OracleDB
// ============================================================================

OracleDB::OracleDB(const std::string& user,
                   const std::string& password,
                   const std::string& dsn) {
    initEnv();
    connect(user, password, dsn);
}

OracleDB::~OracleDB() {
    if (svc_) {
        OCILogoff(svc_, err_);
        svc_ = nullptr;
    }
    if (err_) {
        OCIHandleFree(err_, OCI_HTYPE_ERROR);
        err_ = nullptr;
    }
    if (env_) {
        OCIHandleFree(env_, OCI_HTYPE_ENV);
        env_ = nullptr;
    }
}

// ---------------------------------------------------------------------------
void OracleDB::initEnv() {
    // OCI_THREADED — safe for multi-threaded applications
    sword rc = OCIEnvCreate(
        &env_, OCI_THREADED | OCI_OBJECT,
        nullptr, nullptr, nullptr, nullptr,
        0, nullptr
    );
    if (rc != OCI_SUCCESS || !env_) {
        throw DBException("OCIEnvCreate failed");
    }

    rc = OCIHandleAlloc(env_, (void**)&err_, OCI_HTYPE_ERROR, 0, nullptr);
    if (rc != OCI_SUCCESS) {
        throw DBException("OCIHandleAlloc(OCI_HTYPE_ERROR) failed");
    }
}

// ---------------------------------------------------------------------------
void OracleDB::connect(const std::string& user,
                       const std::string& password,
                       const std::string& dsn) {
    // OCILogon2 opens a session and creates a service context.
    sword rc = OCILogon2(
        env_, err_, &svc_,
        (const OraText*)user.c_str(),     (ub4)user.size(),
        (const OraText*)password.c_str(), (ub4)password.size(),
        (const OraText*)dsn.c_str(),      (ub4)dsn.size(),
        OCI_LOGON2_STMTCACHE   // enable statement cache for the session
    );
    checkErr(rc, "OCILogon2");
    connected_ = true;
}

// ---------------------------------------------------------------------------
void OracleDB::checkErr(sword status, const char* context) const {
    if (status == OCI_SUCCESS || status == OCI_SUCCESS_WITH_INFO) return;

    std::string msg = ociGetError(status, err_);
    if (context && *context) msg = std::string(context) + ": " + msg;

    sb4 errCode = 0;
    if (err_) {
        char buf[2048] = {};
        OCIErrorGet(err_, 1, nullptr, &errCode, (text*)buf, sizeof(buf) - 1,
                    OCI_HTYPE_ERROR);
    }
    throw DBException(msg, (int)errCode);
}

// ---------------------------------------------------------------------------
ResultSet OracleDB::query(const std::string& sql,
                          std::function<void(OracleStmt&)> binder) {
    OracleStmt stmt(svc_, err_, sql);
    if (binder) binder(stmt);
    return stmt.fetchAll();
}

// ---------------------------------------------------------------------------
ub4 OracleDB::execute(const std::string& sql,
                      std::function<void(OracleStmt&)> binder) {
    OracleStmt stmt(svc_, err_, sql);
    if (binder) binder(stmt);
    ub4 rows = stmt.executeUpdate();
    // Auto-commit
    OCITransCommit(svc_, err_, OCI_DEFAULT);
    return rows;
}

// ---------------------------------------------------------------------------
int64_t OracleDB::insert(const std::string& sql,
                         std::function<void(OracleStmt&)> binder) {
    OracleStmt stmt(svc_, err_, sql);
    if (binder) binder(stmt);
    int64_t id = stmt.executeInsertReturning();
    OCITransCommit(svc_, err_, OCI_DEFAULT);
    return id;
}
