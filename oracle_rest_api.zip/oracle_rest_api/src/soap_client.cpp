#include "soap_client.h"

#include <iostream>
#include <sstream>
#include <stdexcept>

// ============================================================================
// Namespace / constant strings
// ============================================================================

static constexpr const char* NS_SOAP11 =
    "http://schemas.xmlsoap.org/soap/envelope/";
static constexpr const char* NS_SOAP12 =
    "http://www.w3.org/2003/05/soap-envelope";

// ============================================================================
// SoapResponse helpers
// ============================================================================

const tinyxml2::XMLElement*
SoapResponse::findBodyElement(const std::string& name) const {
    return SoapClient::findByLocalName(doc.RootElement(), name);
}

std::string SoapResponse::valueOf(const std::string& name,
                                  const std::string& defaultVal) const {
    // First try the pre-collected map (fast path)
    auto it = bodyValues.find(name);
    if (it != bodyValues.end()) return it->second;

    // Fallback: search the raw XML document
    const auto* elem = findBodyElement(name);
    if (elem && elem->GetText()) return elem->GetText();
    return defaultVal;
}

// ============================================================================
// SoapClient — construction
// ============================================================================

SoapClient::SoapClient(const std::string& host,
                       const std::string& servicePath,
                       int timeoutSec)
    : servicePath_(servicePath) {
    cli_ = std::make_unique<httplib::Client>(host);
    cli_->set_connection_timeout(10);
    cli_->set_read_timeout(timeoutSec);
    cli_->set_follow_location(true);
}

void SoapClient::setHeader(const std::string& name, const std::string& value) {
    extraHeaders_.emplace(name, value);
}

// ============================================================================
// Envelope builder
// ============================================================================

std::string SoapClient::buildEnvelope(const SoapRequest& req) const {
    const bool isSoap12 = (req.version == SoapVersion::SOAP_1_2);
    const char* nsUri   = isSoap12 ? NS_SOAP12 : NS_SOAP11;

    std::ostringstream xml;
    xml << R"(<?xml version="1.0" encoding="utf-8"?>)" << "\n";
    xml << "<soap:Envelope"
        << " xmlns:soap=\"" << nsUri << "\"";

    if (!req.targetNamespace.empty()) {
        xml << " xmlns:tns=\"" << req.targetNamespace << "\"";
    }
    xml << ">\n";

    // ---- Header (optional) ----
    if (!req.headerXml.empty()) {
        xml << "  <soap:Header>\n"
            << req.headerXml << "\n"
            << "  </soap:Header>\n";
    }

    // ---- Body ----
    xml << "  <soap:Body>\n"
        << req.bodyXml << "\n"
        << "  </soap:Body>\n";

    xml << "</soap:Envelope>";
    return xml.str();
}

// ============================================================================
// Call
// ============================================================================

SoapResponse SoapClient::call(const SoapRequest& req) {
    const std::string envelope = buildEnvelope(req);

    // Build content-type and SOAPAction header
    std::string contentType;
    httplib::Headers headers = extraHeaders_;

    if (req.version == SoapVersion::SOAP_1_2) {
        contentType = "application/soap+xml; charset=utf-8";
        if (!req.action.empty()) {
            contentType += "; action=\"" + req.action + "\"";
        }
    } else {
        contentType = "text/xml; charset=utf-8";
        headers.emplace("SOAPAction", "\"" + req.action + "\"");
    }

    headers.emplace("Content-Type", contentType);
    headers.emplace("Accept",       "text/xml, application/soap+xml");

    std::cout << "[SoapClient] POST " << servicePath_
              << "  action=" << req.action << "\n";

    auto result = cli_->Post(servicePath_, headers, envelope, contentType);

    if (!result) {
        throw SoapException("SOAP HTTP request failed: " +
                            std::string(httplib::to_string(result.error())));
    }

    std::cout << "[SoapClient] Response HTTP " << result->status << "\n";

    if (result->status == 404) {
        throw SoapException("SOAP endpoint not found (404): " + servicePath_);
    }

    return parseResponse(result->body, req.version);
}

// ============================================================================
// Response parser
// ============================================================================

SoapResponse SoapClient::parseResponse(const std::string& xmlBody,
                                        SoapVersion         version) const {
    SoapResponse resp;
    resp.rawXml = xmlBody;

    tinyxml2::XMLError parseErr =
        resp.doc.Parse(xmlBody.c_str(), xmlBody.size());

    if (parseErr != tinyxml2::XML_SUCCESS) {
        throw SoapException(
            std::string("Failed to parse SOAP XML response: ") +
            resp.doc.ErrorStr());
    }

    const tinyxml2::XMLElement* root = resp.doc.RootElement();
    if (!root) {
        throw SoapException("SOAP response has empty XML document");
    }

    // ---- Find soap:Body ----
    const tinyxml2::XMLElement* body = findByLocalName(root, "Body");
    if (!body) {
        throw SoapException("SOAP response missing <Body> element");
    }

    // ---- Check for soap:Fault ----
    const tinyxml2::XMLElement* fault = findByLocalName(body, "Fault");
    if (fault) {
        resp.success = false;

        // SOAP 1.1 fault structure
        const auto* fc = findByLocalName(fault, "faultcode");
        const auto* fs = findByLocalName(fault, "faultstring");
        const auto* fd = findByLocalName(fault, "detail");
        // SOAP 1.2 fault structure
        if (!fc) fc = findByLocalName(fault, "Code");
        if (!fs) fs = findByLocalName(fault, "Reason");

        if (fc && fc->GetText()) resp.faultCode   = fc->GetText();
        if (fs && fs->GetText()) resp.faultString  = fs->GetText();
        if (fd && fd->GetText()) resp.faultDetail  = fd->GetText();

        throw SoapException(
            "SOAP Fault [" + resp.faultCode + "]: " + resp.faultString,
            resp.faultCode, resp.faultDetail);
    }

    // ---- Collect body values recursively ----
    resp.success = true;
    const tinyxml2::XMLElement* bodyChild = body->FirstChildElement();
    if (bodyChild) {
        collectValues(bodyChild, resp.bodyValues);
    }

    return resp;
}

// ============================================================================
// XML helpers
// ============================================================================

// static
std::string SoapClient::localName(const char* qualifiedName) {
    if (!qualifiedName) return "";
    const char* colon = std::strchr(qualifiedName, ':');
    return colon ? std::string(colon + 1) : std::string(qualifiedName);
}

// static
const tinyxml2::XMLElement*
SoapClient::findByLocalName(const tinyxml2::XMLElement* root,
                             const std::string& name) {
    if (!root) return nullptr;

    // Check siblings at this level, then recurse into children
    for (const auto* elem = root; elem; elem = elem->NextSiblingElement()) {
        if (localName(elem->Name()) == name) return elem;

        const auto* found = findByLocalName(elem->FirstChildElement(), name);
        if (found) return found;
    }
    return nullptr;
}

void SoapClient::collectValues(const tinyxml2::XMLElement*          elem,
                               std::map<std::string, std::string>&  out) const {
    for (; elem; elem = elem->NextSiblingElement()) {
        const std::string key = localName(elem->Name());
        if (!key.empty()) {
            // Leaf node: capture text content
            const char* text = elem->GetText();
            if (text) {
                out[key] = text;
            }
        }
        // Recurse
        collectValues(elem->FirstChildElement(), out);
    }
}
