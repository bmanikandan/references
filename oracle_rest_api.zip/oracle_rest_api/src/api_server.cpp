#include "api_server.h"

#include <iostream>
#include <stdexcept>

using json = nlohmann::json;

// ============================================================================
// Construction & route registration
// ============================================================================

ApiServer::ApiServer(OracleDB&               db,
                     RedisCache&             cache,
                     AuthMiddleware&         auth,
                     ExternalApiService&     extSvc,
                     SoapCalculatorService&  calcSvc,
                     SoapCountryService&     countrySvc,
                     const std::string&      host,
                     int                     port)
    : db_(db), cache_(cache), auth_(auth), dao_(db),
      extSvc_(extSvc), calcSvc_(calcSvc), countrySvc_(countrySvc),
      host_(host), port_(port) {
    registerRoutes();
}

void ApiServer::listen() {
    std::cout << "[Server] Listening on http://" << host_ << ":" << port_ << "\n";
    svr_.listen(host_.c_str(), port_);
}

void ApiServer::stop() { svr_.stop(); }

// ============================================================================
// Route registration
// ============================================================================

void ApiServer::registerRoutes() {
    const std::string base = "/api/v1";

    // ---- PUBLIC: Health (no auth required) --------------------------------
    svr_.Get(base + "/health",
             [this](auto& req, auto& res) { handleHealth(req, res); });

    // ---- PROTECTED: Cache stats + flush (admin — requires auth) ----------
    svr_.Get(base + "/cache/stats",
             guard([this](const httplib::Request&, httplib::Response& res) {
                 auto s = cache_.getStats();
                 json data;
                 data["enabled"]   = cache_.isEnabled();
                 data["connected"] = cache_.isConnected();
                 data["hits"]      = s.hits;
                 data["misses"]    = s.misses;
                 data["errors"]    = s.errors;
                 data["sets"]      = s.sets;
                 data["dels"]      = s.dels;
                 uint64_t total    = s.hits + s.misses;
                 data["hit_rate"]  = total ? (double)s.hits / total : 0.0;
                 json200(res, ApiResponse::ok(data));
             }));

    svr_.Delete(base + "/cache/employees",
                guard([this](const httplib::Request&, httplib::Response& res) {
                    int n = cache_.delByPattern(cache_.buildKey({"employees","*"}));
                    json body; body["deleted_keys"] = n;
                    json200(res, ApiResponse::ok(body));
                }));

    svr_.Delete(base + "/cache/external",
                guard([this](const httplib::Request&, httplib::Response& res) {
                    int n = cache_.delByPattern(cache_.buildKey({"external","*"}));
                    json body; body["deleted_keys"] = n;
                    json200(res, ApiResponse::ok(body));
                }));

    svr_.Delete(base + "/cache/soap",
                guard([this](const httplib::Request&, httplib::Response& res) {
                    int n = cache_.delByPattern(cache_.buildKey({"soap","*"}));
                    json body; body["deleted_keys"] = n;
                    json200(res, ApiResponse::ok(body));
                }));

    // ---- PROTECTED: Employees (Oracle DB) --------------------------------
    svr_.Get   (base + "/employees",
                guard([this](auto& q, auto& s) { handleGetEmployees(q, s); }));
    svr_.Post  (base + "/employees",
                guard([this](auto& q, auto& s) { handleCreateEmployee(q, s); }));
    svr_.Get   (base + "/employees/:id",
                guard([this](auto& q, auto& s) { handleGetEmployee(q, s); }));
    svr_.Put   (base + "/employees/:id",
                guard([this](auto& q, auto& s) { handleUpdateEmployee(q, s); }));
    svr_.Patch (base + "/employees/:id",
                guard([this](auto& q, auto& s) { handlePatchEmployee(q, s); }));
    svr_.Delete(base + "/employees/:id",
                guard([this](auto& q, auto& s) { handleDeleteEmployee(q, s); }));

    // ---- PROTECTED: External REST API ------------------------------------
    svr_.Get (base + "/external/posts",
              guard([this](auto& q, auto& s) { handleExtListPosts(q, s); }));
    svr_.Post(base + "/external/posts",
              guard([this](auto& q, auto& s) { handleExtCreatePost(q, s); }));
    svr_.Get (base + "/external/posts/:id",
              guard([this](auto& q, auto& s) { handleExtGetPost(q, s); }));
    svr_.Get (base + "/external/users",
              guard([this](auto& q, auto& s) { handleExtListUsers(q, s); }));
    svr_.Get (base + "/external/users/:id",
              guard([this](auto& q, auto& s) { handleExtGetUser(q, s); }));

    // ---- PROTECTED: SOAP Calculator --------------------------------------
    svr_.Post(base + "/soap/calculator/add",
              guard([this](auto& q, auto& s) { handleSoapAdd(q, s); }));
    svr_.Post(base + "/soap/calculator/subtract",
              guard([this](auto& q, auto& s) { handleSoapSubtract(q, s); }));
    svr_.Post(base + "/soap/calculator/multiply",
              guard([this](auto& q, auto& s) { handleSoapMultiply(q, s); }));
    svr_.Post(base + "/soap/calculator/divide",
              guard([this](auto& q, auto& s) { handleSoapDivide(q, s); }));

    // ---- PROTECTED: SOAP Country info ------------------------------------
    svr_.Get(base + "/soap/country/:code/name",
             guard([this](auto& q, auto& s) { handleCountryName(q, s); }));
    svr_.Get(base + "/soap/country/:code/currency",
             guard([this](auto& q, auto& s) { handleCountryCurrency(q, s); }));
    svr_.Get(base + "/soap/country/:code/capital",
             guard([this](auto& q, auto& s) { handleCountryCapital(q, s); }));

    // ---- CORS ------------------------------------------------------------
    svr_.Options(".*", [](const httplib::Request&, httplib::Response& res) {
        res.set_header("Access-Control-Allow-Origin",  "*");
        res.set_header("Access-Control-Allow-Methods",
                       "GET, POST, PUT, PATCH, DELETE, OPTIONS");
        res.set_header("Access-Control-Allow-Headers",
                       "Content-Type, Authorization");
        res.status = 204;
    });

    svr_.set_post_routing_handler([](const httplib::Request&,
                                     httplib::Response& res) {
        res.set_header("Access-Control-Allow-Origin", "*");
    });

    // ---- Global exception handler ----------------------------------------
    svr_.set_exception_handler(
        [this](const httplib::Request&, httplib::Response& res,
               std::exception_ptr ep) {
            try {
                std::rethrow_exception(ep);
            } catch (const SoapException& e) {
                std::cerr << "[SOAP Error] " << e.what() << "\n";
                json502(res, std::string("SOAP fault: ") + e.what());
            } catch (const HttpClientException& e) {
                std::cerr << "[HTTP Client Error] " << e.what() << "\n";
                (e.httpStatus == 404)
                    ? json404(res, e.what())
                    : json502(res, e.what());
            } catch (const DBException& e) {
                std::cerr << "[DB Error] " << e.what() << "\n";
                json500(res, e.what());
            } catch (const std::exception& e) {
                std::cerr << "[Error] " << e.what() << "\n";
                json500(res, e.what());
            } catch (...) {
                json500(res, "Unknown error");
            }
        });
}

// ============================================================================
// Response helpers
// ============================================================================

void ApiServer::json200(httplib::Response& res, const json& body) {
    res.status = 200;
    res.set_content(body.dump(2), "application/json");
}
void ApiServer::json201(httplib::Response& res, const json& body) {
    res.status = 201;
    res.set_content(body.dump(2), "application/json");
}
void ApiServer::json400(httplib::Response& res, const std::string& msg) {
    res.status = 400;
    res.set_content(ApiResponse::error(400, msg).dump(2), "application/json");
}
void ApiServer::json404(httplib::Response& res, const std::string& msg) {
    res.status = 404;
    res.set_content(ApiResponse::error(404, msg).dump(2), "application/json");
}
void ApiServer::json422(httplib::Response& res, const std::string& msg) {
    res.status = 422;
    res.set_content(ApiResponse::error(422, msg).dump(2), "application/json");
}
void ApiServer::json500(httplib::Response& res, const std::string& msg) {
    res.status = 500;
    res.set_content(ApiResponse::error(500, msg).dump(2), "application/json");
}
void ApiServer::json502(httplib::Response& res, const std::string& msg) {
    res.status = 502;
    res.set_content(ApiResponse::error(502, msg).dump(2), "application/json");
}

// ============================================================================
// Parsing helpers
// ============================================================================

bool ApiServer::parseId(const httplib::Request& req, int64_t& outId,
                         httplib::Response& res) {
    try {
        outId = std::stoll(req.path_params.at("id"));
        if (outId <= 0) throw std::invalid_argument("");
        return true;
    } catch (...) {
        json400(res, "Invalid id — must be a positive integer");
        return false;
    }
}

bool ApiServer::parseInt(const httplib::Request& req,
                          const std::string& param,
                          int& out, httplib::Response& res) {
    try {
        out = std::stoi(req.path_params.at(param));
        return true;
    } catch (...) {
        json400(res, "Invalid path parameter '" + param + "'");
        return false;
    }
}

bool ApiServer::parseBody(const httplib::Request& req, json& out,
                           httplib::Response& res) {
    if (req.body.empty()) { json400(res, "Request body is empty"); return false; }
    try {
        out = json::parse(req.body);
        return true;
    } catch (const json::parse_error& e) {
        json400(res, std::string("Invalid JSON: ") + e.what());
        return false;
    }
}

// ============================================================================
// Cache invalidation helper
// ============================================================================

void ApiServer::invalidateEmployee(int64_t id) {
    // Delete the exact-item key
    cache_.del(cache_.buildKey({"employees", std::to_string(id)}));
    // Delete all list keys (any dept/limit/offset combination)
    cache_.delByPattern(cache_.buildKey({"employees", "list", "*"}));
}

// ============================================================================
// Health check
// ============================================================================

void ApiServer::handleHealth(const httplib::Request&, httplib::Response& res) {
    json data;
    data["status"]   = "ok";
    data["db"]       = db_.isConnected() ? "connected" : "disconnected";
    data["cache"]    = cache_.isEnabled()
                           ? (cache_.isConnected() ? "connected" : "unavailable")
                           : "disabled";
    data["auth"]     = auth_.isEnabled() ? "enabled" : "disabled";
    data["version"]  = "1.0.0";
    data["features"] = json::array({"oracle-db", "rest-client",
                                    "soap-client", "redis-cache",
                                    "oauth2-jwt"});
    json200(res, ApiResponse::ok(data));
}

// ============================================================================
// Employee handlers (Oracle DB)
// ============================================================================

// GET /api/v1/employees?dept=&limit=&offset=
// Cache key: employees:list:<sorted-param-string>   TTL: 60 s
void ApiServer::handleGetEmployees(const httplib::Request& req,
                                    httplib::Response& res) {
    std::string dept;
    int limit = 100, offset = 0;
    if (req.has_param("dept"))   dept   = req.get_param_value("dept");
    if (req.has_param("limit"))  limit  = std::min(std::stoi(req.get_param_value("limit")), 500);
    if (req.has_param("offset")) offset = std::stoi(req.get_param_value("offset"));

    // Build deterministic cache key from all query parameters
    std::map<std::string, std::string> params;
    if (!dept.empty())  params["dept"]   = dept;
    params["limit"]  = std::to_string(limit);
    params["offset"] = std::to_string(offset);
    const std::string key = cache_.buildKey(
        {"employees", "list", RedisCache::paramsKey(params)});

    json payload = withCache(res, key, RedisCache::TTL_SHORT, [&]() {
        auto employees = dao_.findAll(dept, limit, offset);
        int64_t total  = dao_.count(dept);

        json arr = json::array();
        for (const auto& e : employees) arr.push_back(e.toJson());

        json meta;
        meta["total"]  = total;
        meta["limit"]  = limit;
        meta["offset"] = offset;
        meta["count"]  = (int64_t)employees.size();
        return ApiResponse::ok(arr, meta);
    });

    json200(res, payload);
}

// GET /api/v1/employees/:id
// Cache key: employees:<id>   TTL: 60 s
void ApiServer::handleGetEmployee(const httplib::Request& req,
                                   httplib::Response& res) {
    int64_t id;
    if (!parseId(req, id, res)) return;

    const std::string key = cache_.buildKey({"employees", std::to_string(id)});

    json payload = withCache(res, key, RedisCache::TTL_SHORT, [&]() {
        auto emp = dao_.findById(id);
        if (!emp) {
            json404(res, "Employee " + std::to_string(id) + " not found");
            return json(nullptr);   // signal: response already sent
        }
        return ApiResponse::ok(emp->toJson());
    });

    if (!payload.is_null()) json200(res, payload);
}

// POST /api/v1/employees  — no cache read; invalidate lists
void ApiServer::handleCreateEmployee(const httplib::Request& req,
                                      httplib::Response& res) {
    json body;
    if (!parseBody(req, body, res)) return;
    if (!body.contains("name")  || body["name"].get<std::string>().empty())
        { json400(res, "'name' is required"); return; }
    if (!body.contains("email") || body["email"].get<std::string>().empty())
        { json400(res, "'email' is required"); return; }

    Employee emp    = Employee::fromJson(body);
    int64_t  newId  = dao_.create(emp);
    auto     created = dao_.findById(newId);
    if (!created) { json500(res, "Insert succeeded but record not found"); return; }

    // Invalidate list cache (new row changes every list result)
    cache_.delByPattern(cache_.buildKey({"employees", "list", "*"}));

    res.set_header("Location", "/api/v1/employees/" + std::to_string(newId));
    json201(res, ApiResponse::ok(created->toJson()));
}

// PUT /api/v1/employees/:id  — invalidate item + lists
void ApiServer::handleUpdateEmployee(const httplib::Request& req,
                                      httplib::Response& res) {
    int64_t id;
    if (!parseId(req, id, res)) return;
    json body;
    if (!parseBody(req, body, res)) return;
    if (!body.contains("name")  || body["name"].get<std::string>().empty())
        { json400(res, "'name' is required"); return; }
    if (!body.contains("email") || body["email"].get<std::string>().empty())
        { json400(res, "'email' is required"); return; }

    Employee emp = Employee::fromJson(body);
    if (!dao_.update(id, emp))
        { json404(res, "Employee " + std::to_string(id) + " not found"); return; }

    invalidateEmployee(id);
    json200(res, ApiResponse::ok(dao_.findById(id)->toJson()));
}

// PATCH /api/v1/employees/:id  — invalidate item + lists
void ApiServer::handlePatchEmployee(const httplib::Request& req,
                                     httplib::Response& res) {
    int64_t id;
    if (!parseId(req, id, res)) return;
    json body;
    if (!parseBody(req, body, res)) return;
    if (!dao_.patch(id, body))
        { json404(res, "Employee " + std::to_string(id) + " not found"); return; }

    invalidateEmployee(id);
    json200(res, ApiResponse::ok(dao_.findById(id)->toJson()));
}

// DELETE /api/v1/employees/:id  — invalidate item + lists
void ApiServer::handleDeleteEmployee(const httplib::Request& req,
                                      httplib::Response& res) {
    int64_t id;
    if (!parseId(req, id, res)) return;
    if (!dao_.remove(id))
        { json404(res, "Employee " + std::to_string(id) + " not found"); return; }

    invalidateEmployee(id);
    json body;
    body["message"] = "Employee " + std::to_string(id) + " deleted";
    json200(res, ApiResponse::ok(body));
}

// ============================================================================
// External REST API handlers
// ============================================================================

// GET /api/v1/external/posts?limit=&page=
// Cache key: external:posts:list:<params>   TTL: 300 s
void ApiServer::handleExtListPosts(const httplib::Request& req,
                                    httplib::Response& res) {
    int limit = 20, page = 1;
    if (req.has_param("limit")) limit = std::min(std::stoi(req.get_param_value("limit")), 100);
    if (req.has_param("page"))  page  = std::max(1, std::stoi(req.get_param_value("page")));

    std::map<std::string, std::string> params {
        {"limit", std::to_string(limit)},
        {"page",  std::to_string(page)}
    };
    const std::string key = cache_.buildKey(
        {"external", "posts", "list", RedisCache::paramsKey(params)});

    json payload = withCache(res, key, RedisCache::TTL_MEDIUM, [&]() {
        auto data = extSvc_.listPosts(limit, page);
        json meta;
        meta["limit"] = limit;
        meta["page"]  = page;
        return ApiResponse::ok(data, meta);
    });
    json200(res, payload);
}

// GET /api/v1/external/posts/:id
// Cache key: external:posts:<id>   TTL: 300 s
void ApiServer::handleExtGetPost(const httplib::Request& req,
                                  httplib::Response& res) {
    int id;
    if (!parseInt(req, "id", id, res)) return;

    const std::string key = cache_.buildKey(
        {"external", "posts", std::to_string(id)});

    json payload = withCache(res, key, RedisCache::TTL_MEDIUM, [&]() {
        return ApiResponse::ok(extSvc_.getPost(id));
    });
    json200(res, payload);
}

// POST /api/v1/external/posts  — not cached (write; JSONPlaceholder is fake anyway)
void ApiServer::handleExtCreatePost(const httplib::Request& req,
                                     httplib::Response& res) {
    json body;
    if (!parseBody(req, body, res)) return;
    json201(res, ApiResponse::ok(extSvc_.createPost(body)));
}

// GET /api/v1/external/users
// Cache key: external:users:list   TTL: 300 s
void ApiServer::handleExtListUsers(const httplib::Request&,
                                    httplib::Response& res) {
    const std::string key = cache_.buildKey({"external", "users", "list"});

    json payload = withCache(res, key, RedisCache::TTL_MEDIUM, [&]() {
        return ApiResponse::ok(extSvc_.listUsers());
    });
    json200(res, payload);
}

// GET /api/v1/external/users/:id
// Cache key: external:users:<id>   TTL: 300 s
void ApiServer::handleExtGetUser(const httplib::Request& req,
                                  httplib::Response& res) {
    int id;
    if (!parseInt(req, "id", id, res)) return;

    const std::string key = cache_.buildKey(
        {"external", "users", std::to_string(id)});

    json payload = withCache(res, key, RedisCache::TTL_MEDIUM, [&]() {
        return ApiResponse::ok(extSvc_.getUser(id));
    });
    json200(res, payload);
}

// ============================================================================
// SOAP Calculator handlers  (arithmetic is NOT cached — always fresh)
// ============================================================================

void ApiServer::handleSoapArithmetic(const std::string& op,
                                      const httplib::Request& req,
                                      httplib::Response& res) {
    json body;
    if (!parseBody(req, body, res)) return;
    if (!body.contains("a") || !body.contains("b")) {
        json400(res, "Body must contain integer fields 'a' and 'b'");
        return;
    }
    int a = body["a"].get<int>();
    int b = body["b"].get<int>();

    json result;
    if      (op == "Add")      result = calcSvc_.add     (a, b);
    else if (op == "Subtract") result = calcSvc_.subtract(a, b);
    else if (op == "Multiply") result = calcSvc_.multiply(a, b);
    else if (op == "Divide") {
        if (b == 0) { json422(res, "Division by zero"); return; }
        result = calcSvc_.divide(a, b);
    }

    // Explicitly mark calculator responses as not cached
    res.set_header("X-Cache",       "BYPASS");
    res.set_header("Cache-Control", "no-store");
    json200(res, ApiResponse::ok(result));
}

void ApiServer::handleSoapAdd     (const httplib::Request& req, httplib::Response& res) { handleSoapArithmetic("Add",      req, res); }
void ApiServer::handleSoapSubtract(const httplib::Request& req, httplib::Response& res) { handleSoapArithmetic("Subtract", req, res); }
void ApiServer::handleSoapMultiply(const httplib::Request& req, httplib::Response& res) { handleSoapArithmetic("Multiply", req, res); }
void ApiServer::handleSoapDivide  (const httplib::Request& req, httplib::Response& res) { handleSoapArithmetic("Divide",   req, res); }

// ============================================================================
// SOAP Country info handlers  (stable reference data — long TTL)
// Cache key: soap:country:<CODE>:<property>   TTL: 3600 s
// ============================================================================

void ApiServer::handleCountryName(const httplib::Request& req,
                                   httplib::Response& res) {
    const std::string code = req.path_params.at("code");
    const std::string key  = cache_.buildKey({"soap", "country", code, "name"});

    json payload = withCache(res, key, RedisCache::TTL_LONG, [&]() {
        return ApiResponse::ok(countrySvc_.countryName(code));
    });
    json200(res, payload);
}

void ApiServer::handleCountryCurrency(const httplib::Request& req,
                                       httplib::Response& res) {
    const std::string code = req.path_params.at("code");
    const std::string key  = cache_.buildKey({"soap", "country", code, "currency"});

    json payload = withCache(res, key, RedisCache::TTL_LONG, [&]() {
        return ApiResponse::ok(countrySvc_.countryCurrency(code));
    });
    json200(res, payload);
}

void ApiServer::handleCountryCapital(const httplib::Request& req,
                                      httplib::Response& res) {
    const std::string code = req.path_params.at("code");
    const std::string key  = cache_.buildKey({"soap", "country", code, "capital"});

    json payload = withCache(res, key, RedisCache::TTL_LONG, [&]() {
        return ApiResponse::ok(countrySvc_.countryCapital(code));
    });
    json200(res, payload);
}
