#include "employee.h"

#include <sstream>
#include <stdexcept>

using json = nlohmann::json;

// ============================================================================
// Employee serialisation helpers
// ============================================================================

json Employee::toJson() const {
    json j;
    j["id"]         = id;
    j["name"]       = name;
    j["email"]      = email;
    j["department"] = department;
    j["salary"]     = salary;
    j["created_at"] = createdAt;
    return j;
}

Employee Employee::fromJson(const json& j) {
    Employee e;
    if (j.contains("name"))       e.name       = j["name"].get<std::string>();
    if (j.contains("email"))      e.email      = j["email"].get<std::string>();
    if (j.contains("department")) e.department = j["department"].get<std::string>();
    if (j.contains("salary"))     e.salary     = j["salary"].get<double>();
    return e;
}

// ============================================================================
// EmployeeDAO
// ============================================================================

EmployeeDAO::EmployeeDAO(OracleDB& db) : db_(db) {}

// ---------------------------------------------------------------------------
// Row → Employee
// ---------------------------------------------------------------------------
Employee EmployeeDAO::rowToEmployee(const Row& row) {
    Employee e;

    auto get = [&](const std::string& col) -> std::string {
        auto it = row.find(col);
        return (it != row.end()) ? it->second : "";
    };

    e.id         = get("ID").empty()     ? 0 : std::stoll(get("ID"));
    e.name       = get("NAME");
    e.email      = get("EMAIL");
    e.department = get("DEPARTMENT");
    e.salary     = get("SALARY").empty() ? 0.0 : std::stod(get("SALARY"));
    e.createdAt  = get("CREATED_AT");
    return e;
}

// ---------------------------------------------------------------------------
// findAll
// ---------------------------------------------------------------------------
std::vector<Employee> EmployeeDAO::findAll(const std::string& dept,
                                           int limit,
                                           int offset) {
    // Build query: optional WHERE clause, always with ROWNUM pagination.
    // Oracle 12c+: use OFFSET … FETCH NEXT … ROWS ONLY.
    std::string sql =
        "SELECT id, name, email, department, salary, "
        "       TO_CHAR(created_at, 'YYYY-MM-DD\"T\"HH24:MI:SS') AS created_at "
        "FROM   employees ";

    if (!dept.empty()) {
        sql += "WHERE department = :1 ";
        sql += "ORDER BY id "
               "OFFSET :2 ROWS FETCH NEXT :3 ROWS ONLY";

        auto rows = db_.query(sql, [&](OracleStmt& s) {
            s.bindString(1, dept);
            s.bindInt64 (2, offset);
            s.bindInt64 (3, limit);
        });

        std::vector<Employee> result;
        result.reserve(rows.size());
        for (const auto& r : rows) result.push_back(rowToEmployee(r));
        return result;
    }

    sql += "ORDER BY id "
           "OFFSET :1 ROWS FETCH NEXT :2 ROWS ONLY";

    auto rows = db_.query(sql, [&](OracleStmt& s) {
        s.bindInt64(1, offset);
        s.bindInt64(2, limit);
    });

    std::vector<Employee> result;
    result.reserve(rows.size());
    for (const auto& r : rows) result.push_back(rowToEmployee(r));
    return result;
}

// ---------------------------------------------------------------------------
// findById
// ---------------------------------------------------------------------------
std::optional<Employee> EmployeeDAO::findById(int64_t id) {
    const std::string sql =
        "SELECT id, name, email, department, salary, "
        "       TO_CHAR(created_at, 'YYYY-MM-DD\"T\"HH24:MI:SS') AS created_at "
        "FROM   employees "
        "WHERE  id = :1";

    auto rows = db_.query(sql, [&](OracleStmt& s) {
        s.bindInt64(1, id);
    });

    if (rows.empty()) return std::nullopt;
    return rowToEmployee(rows[0]);
}

// ---------------------------------------------------------------------------
// create
// ---------------------------------------------------------------------------
int64_t EmployeeDAO::create(const Employee& emp) {
    // Use a sequence (employees_seq) defined in schema.sql to generate the id
    // so we can use RETURNING to retrieve it.
    const std::string sql =
        "INSERT INTO employees (id, name, email, department, salary) "
        "VALUES (employees_seq.NEXTVAL, :1, :2, :3, :4) "
        "RETURNING id INTO :ret_id";

    return db_.insert(sql, [&](OracleStmt& s) {
        s.bindString(1, emp.name);
        s.bindString(2, emp.email);
        s.bindString(3, emp.department);
        // Bind salary as a formatted string (SQLT_STR) to avoid float issues
        s.bindString(4, std::to_string(emp.salary));
    });
}

// ---------------------------------------------------------------------------
// update (full replace)
// ---------------------------------------------------------------------------
bool EmployeeDAO::update(int64_t id, const Employee& emp) {
    const std::string sql =
        "UPDATE employees "
        "SET    name       = :1, "
        "       email      = :2, "
        "       department = :3, "
        "       salary     = :4 "
        "WHERE  id = :5";

    ub4 affected = db_.execute(sql, [&](OracleStmt& s) {
        s.bindString(1, emp.name);
        s.bindString(2, emp.email);
        s.bindString(3, emp.department);
        s.bindString(4, std::to_string(emp.salary));
        s.bindInt64 (5, id);
    });

    return affected > 0;
}

// ---------------------------------------------------------------------------
// patch (partial update)
// ---------------------------------------------------------------------------
bool EmployeeDAO::patch(int64_t id, const json& patch) {
    // Build a dynamic SET clause from the JSON fields present in the request.
    std::vector<std::string> setClauses;
    std::vector<std::string> values;

    if (patch.contains("name")) {
        setClauses.push_back("name = :" + std::to_string(values.size() + 1));
        values.push_back(patch["name"].get<std::string>());
    }
    if (patch.contains("email")) {
        setClauses.push_back("email = :" + std::to_string(values.size() + 1));
        values.push_back(patch["email"].get<std::string>());
    }
    if (patch.contains("department")) {
        setClauses.push_back("department = :" + std::to_string(values.size() + 1));
        values.push_back(patch["department"].get<std::string>());
    }
    if (patch.contains("salary")) {
        setClauses.push_back("salary = :" + std::to_string(values.size() + 1));
        values.push_back(std::to_string(patch["salary"].get<double>()));
    }

    if (setClauses.empty()) return false;  // nothing to update

    std::ostringstream sql;
    sql << "UPDATE employees SET ";
    for (size_t i = 0; i < setClauses.size(); i++) {
        if (i) sql << ", ";
        sql << setClauses[i];
    }
    sql << " WHERE id = :" << (values.size() + 1);

    ub4 affected = db_.execute(sql.str(), [&](OracleStmt& s) {
        for (size_t i = 0; i < values.size(); i++) {
            s.bindString((ub4)(i + 1), values[i]);
        }
        s.bindInt64((ub4)(values.size() + 1), id);
    });

    return affected > 0;
}

// ---------------------------------------------------------------------------
// remove
// ---------------------------------------------------------------------------
bool EmployeeDAO::remove(int64_t id) {
    ub4 affected = db_.execute(
        "DELETE FROM employees WHERE id = :1",
        [&](OracleStmt& s) { s.bindInt64(1, id); }
    );
    return affected > 0;
}

// ---------------------------------------------------------------------------
// count
// ---------------------------------------------------------------------------
int64_t EmployeeDAO::count(const std::string& dept) {
    std::string sql = "SELECT COUNT(*) AS CNT FROM employees";
    ResultSet rows;

    if (dept.empty()) {
        rows = db_.query(sql);
    } else {
        sql += " WHERE department = :1";
        rows = db_.query(sql, [&](OracleStmt& s) {
            s.bindString(1, dept);
        });
    }

    if (rows.empty() || rows[0].find("CNT") == rows[0].end()) return 0;
    return std::stoll(rows[0].at("CNT"));
}
