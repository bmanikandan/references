#include "soap_service.h"

#include <sstream>
#include <stdexcept>

using json = nlohmann::json;

// ============================================================================
// SoapCalculatorService
// Target: http://www.dneonline.com/calculator.asmx
// Namespace: http://tempuri.org/
// ============================================================================

SoapCalculatorService::SoapCalculatorService(const std::string& host,
                                              const std::string& path)
    : client_(host, path) {}

// ---------------------------------------------------------------------------
json SoapCalculatorService::invoke(const std::string& operation,
                                    int a, int b) {
    // Build SOAP body for the given arithmetic operation
    std::ostringstream body;
    body << "    <tns:" << operation << ">\n"
         << "      <tns:intA>" << a << "</tns:intA>\n"
         << "      <tns:intB>" << b << "</tns:intB>\n"
         << "    </tns:" << operation << ">";

    SoapRequest req;
    req.action          = "http://tempuri.org/" + operation;
    req.targetNamespace = "http://tempuri.org/";
    req.bodyXml         = body.str();
    req.version         = SoapVersion::SOAP_1_1;

    SoapResponse resp = client_.call(req);

    // The response element is named "<Operation>Result", e.g. "AddResult"
    const std::string resultKey = operation + "Result";
    std::string resultVal       = resp.valueOf(resultKey);

    json out;
    out["operation"] = operation;
    out["a"]         = a;
    out["b"]         = b;
    out["result"]    = resultVal.empty() ? json(nullptr)
                                         : json(std::stoi(resultVal));
    return out;
}

json SoapCalculatorService::add     (int a, int b) { return invoke("Add",      a, b); }
json SoapCalculatorService::subtract(int a, int b) { return invoke("Subtract", a, b); }
json SoapCalculatorService::multiply(int a, int b) { return invoke("Multiply", a, b); }
json SoapCalculatorService::divide  (int a, int b) {
    if (b == 0) throw std::invalid_argument("Division by zero");
    return invoke("Divide", a, b);
}

// ============================================================================
// SoapCountryService
// Target: http://webservices.oorsprong.org/websamples.countryinfo/CountryInfoService.wso
// Namespace: http://www.oorsprong.org/websamples.countryinfo
// SOAP 1.2
// ============================================================================

SoapCountryService::SoapCountryService(const std::string& host,
                                        const std::string& path)
    : client_(host, path) {}

// ---------------------------------------------------------------------------
json SoapCountryService::invoke(const std::string& operation,
                                 const std::string& resultElement,
                                 const std::string& isoCode) {
    static const std::string NS =
        "http://www.oorsprong.org/websamples.countryinfo";

    std::ostringstream body;
    body << "    <tns:" << operation << ">\n"
         << "      <tns:sCountryISOCode>" << isoCode
         << "</tns:sCountryISOCode>\n"
         << "    </tns:" << operation << ">";

    SoapRequest req;
    req.action          = NS + "/" + operation;
    req.targetNamespace = NS;
    req.bodyXml         = body.str();
    req.version         = SoapVersion::SOAP_1_2;

    SoapResponse resp = client_.call(req);

    std::string value = resp.valueOf(resultElement);

    json out;
    out["isoCode"]   = isoCode;
    out["operation"] = operation;
    out[resultElement] = value;
    return out;
}

json SoapCountryService::countryName(const std::string& iso) {
    return invoke("CountryName", "CountryNameResult", iso);
}

json SoapCountryService::countryCurrency(const std::string& iso) {
    return invoke("CountryCurrency", "CountryCurrencyResult", iso);
}

json SoapCountryService::countryCapital(const std::string& iso) {
    return invoke("CapitalCity", "CapitalCityResult", iso);
}
