#include "jwks_provider.h"

// OpenSSL
#include <openssl/bio.h>
#include <openssl/bn.h>
#include <openssl/ec.h>
#include <openssl/evp.h>
#include <openssl/pem.h>
#include <openssl/rsa.h>
#include <openssl/x509.h>
#include <openssl/err.h>

// JSON
#include <nlohmann/json.hpp>

#include <iostream>
#include <regex>
#include <sstream>
#include <stdexcept>

using json = nlohmann::json;

// ============================================================================
// Helpers
// ============================================================================

static std::string opensslErrors() {
    std::string buf;
    char tmp[256];
    unsigned long err;
    while ((err = ERR_get_error())) {
        ERR_error_string_n(err, tmp, sizeof(tmp));
        if (!buf.empty()) buf += "; ";
        buf += tmp;
    }
    return buf.empty() ? "unknown OpenSSL error" : buf;
}

// ============================================================================
// Construction
// ============================================================================

JwksProvider::JwksProvider(const Config& cfg, RedisCache& cache)
    : cfg_(cfg), cache_(cache) {

    // Validate URI is non-empty
    if (cfg_.jwksUri.empty())
        throw std::invalid_argument("JwksProvider: OAUTH_JWKS_URI is not set");

    // Build an HttpClient pointed at the JWKS host
    std::string scheme, host, path;
    int port = 0;
    splitUrl(cfg_.jwksUri, scheme, host, port, path);

    std::string base = scheme + "://" + host;
    if ((scheme == "https" && port != 443) ||
        (scheme == "http"  && port != 80))
        base += ":" + std::to_string(port);

    ClientConfig httpCfg;
    httpCfg.readTimeoutSec    = cfg_.fetchTimeoutSec;
    httpCfg.connectTimeoutSec = 5;
    http_ = std::make_unique<HttpClient>(base, httpCfg);

    std::cout << "[JWKS] Provider initialised: " << cfg_.jwksUri << "\n";
}

// ============================================================================
// Public interface
// ============================================================================

std::string JwksProvider::getPublicKeyPem(const std::string& kid,
                                           const std::string& /*alg*/) {
    std::lock_guard<std::mutex> lk(mtx_);

    // 1. In-memory map
    auto it = memCache_.find(kid);
    if (it != memCache_.end()) return it->second;

    // 2. Redis cache
    auto cached = cache_.get(cache_.buildKey({"jwks", kid}));
    if (cached && cached->is_string()) {
        std::string pem = cached->get<std::string>();
        memCache_[kid]  = pem;
        return pem;
    }

    // 3. Fetch JWKS from origin
    fetchAndCache();
    it = memCache_.find(kid);
    if (it != memCache_.end()) return it->second;

    // 4. One more refresh in case key was rotated mid-air
    if (!freshFetched_) {
        freshFetched_ = true;
        fetchAndCache();
        it = memCache_.find(kid);
        if (it != memCache_.end()) return it->second;
    }

    throw AuthException(AuthErrorKind::KeyNotFound,
                        "No JWKS key found for kid='" + kid + "'");
}

void JwksProvider::forceRefresh() {
    std::lock_guard<std::mutex> lk(mtx_);
    memCache_.clear();
    fetchAndCache();
}

// ============================================================================
// JWKS fetching + parsing
// ============================================================================

void JwksProvider::fetchAndCache() {
    // Re-derive the path portion of the URI
    std::string scheme, host, path;
    int port = 0;
    splitUrl(cfg_.jwksUri, scheme, host, port, path);

    std::cout << "[JWKS] Fetching " << cfg_.jwksUri << "\n";
    HttpResponse resp;
    try {
        resp = http_->get(path);
    } catch (const HttpClientException& e) {
        throw AuthException(AuthErrorKind::JwksFetchFailed,
                            std::string("JWKS fetch error: ") + e.what());
    }

    if (!resp.ok()) {
        throw AuthException(AuthErrorKind::JwksFetchFailed,
                            "JWKS endpoint returned HTTP " +
                            std::to_string(resp.status));
    }

    parseJwks(resp.body);
    freshFetched_ = true;
}

// ---------------------------------------------------------------------------
void JwksProvider::parseJwks(const std::string& jwksJson) {
    json doc;
    try {
        doc = json::parse(jwksJson);
    } catch (const json::parse_error& e) {
        throw AuthException(AuthErrorKind::JwksFetchFailed,
                            std::string("JWKS JSON parse error: ") + e.what());
    }

    if (!doc.contains("keys") || !doc["keys"].is_array()) {
        throw AuthException(AuthErrorKind::JwksFetchFailed,
                            "JWKS response missing 'keys' array");
    }

    int stored = 0;
    for (const auto& jwk : doc["keys"]) {
        try {
            const std::string kty = jwk.value("kty", "");
            const std::string kid = jwk.value("kid", "");
            const std::string use = jwk.value("use", "sig");

            // Skip encryption keys
            if (use != "sig" && !use.empty()) continue;

            std::string pem;

            // ---- x5c takes precedence (full certificate chain) ----
            if (jwk.contains("x5c") && jwk["x5c"].is_array()
                    && !jwk["x5c"].empty()) {
                pem = x5cToPem(jwk["x5c"][0].get<std::string>());
            }
            // ---- RSA: n + e ----
            else if (kty == "RSA") {
                pem = rsaJwkToPem(jwk.at("n").get<std::string>(),
                                  jwk.at("e").get<std::string>());
            }
            // ---- EC: crv + x + y ----
            else if (kty == "EC") {
                pem = ecJwkToPem(jwk.at("crv").get<std::string>(),
                                 jwk.at("x").get<std::string>(),
                                 jwk.at("y").get<std::string>());
            } else {
                std::cerr << "[JWKS] Skipping unsupported key type: " << kty << "\n";
                continue;
            }

            if (kid.empty()) {
                std::cerr << "[JWKS] WARNING — key has no 'kid'; skipping.\n";
                continue;
            }

            storeKey(kid, pem);
            stored++;
        } catch (const AuthException&) {
            throw;
        } catch (const std::exception& e) {
            std::cerr << "[JWKS] Skipping key due to error: " << e.what() << "\n";
        }
    }

    std::cout << "[JWKS] Loaded " << stored << " key(s).\n";
}

// ---------------------------------------------------------------------------
void JwksProvider::storeKey(const std::string& kid, const std::string& pem) {
    memCache_[kid] = pem;
    // Cache PEM string in Redis (store as JSON string value)
    cache_.set(cache_.buildKey({"jwks", kid}),
               json(pem),
               cfg_.cacheTtlSec);
}

// ============================================================================
// RSA key construction from JWK n + e
// ============================================================================

std::string JwksProvider::rsaJwkToPem(const std::string& n_b64,
                                       const std::string& e_b64) {
    auto n_bytes = b64urlDecode(n_b64);
    auto e_bytes = b64urlDecode(e_b64);

    if (n_bytes.empty() || e_bytes.empty())
        throw AuthException(AuthErrorKind::JwksFetchFailed,
                            "RSA JWK: empty n or e after base64url decode");

    BIGNUM* bn_n = BN_bin2bn(n_bytes.data(), (int)n_bytes.size(), nullptr);
    BIGNUM* bn_e = BN_bin2bn(e_bytes.data(), (int)e_bytes.size(), nullptr);
    if (!bn_n || !bn_e) {
        BN_free(bn_n); BN_free(bn_e);
        throw AuthException(AuthErrorKind::JwksFetchFailed, "RSA BN_bin2bn failed");
    }

    // Create RSA key (takes ownership of bn_n, bn_e)
    RSA* rsa = RSA_new();
    if (RSA_set0_key(rsa, bn_n, bn_e, nullptr) != 1) {
        RSA_free(rsa);
        BN_free(bn_n); BN_free(bn_e);
        throw AuthException(AuthErrorKind::JwksFetchFailed, "RSA_set0_key failed");
    }

    // Wrap in EVP_PKEY
    EVP_PKEY* pkey = EVP_PKEY_new();
    EVP_PKEY_assign_RSA(pkey, rsa);   // pkey owns rsa now

    // Export SubjectPublicKeyInfo PEM
    BIO* bio = BIO_new(BIO_s_mem());
    if (PEM_write_bio_PUBKEY(bio, pkey) != 1) {
        BIO_free(bio);
        EVP_PKEY_free(pkey);
        throw AuthException(AuthErrorKind::JwksFetchFailed,
                            "PEM_write_bio_PUBKEY failed: " + opensslErrors());
    }

    BUF_MEM* bptr = nullptr;
    BIO_get_mem_ptr(bio, &bptr);
    std::string pem(bptr->data, bptr->length);
    BIO_free(bio);
    EVP_PKEY_free(pkey);
    return pem;
}

// ============================================================================
// EC key construction from JWK crv + x + y
// ============================================================================

std::string JwksProvider::ecJwkToPem(const std::string& crv,
                                      const std::string& x_b64,
                                      const std::string& y_b64) {
    int nid;
    if      (crv == "P-256") nid = NID_X9_62_prime256v1;
    else if (crv == "P-384") nid = NID_secp384r1;
    else if (crv == "P-521") nid = NID_secp521r1;
    else throw AuthException(AuthErrorKind::JwksFetchFailed,
                             "Unsupported EC curve: " + crv);

    auto x_bytes = b64urlDecode(x_b64);
    auto y_bytes = b64urlDecode(y_b64);

    EC_KEY*    ec    = EC_KEY_new_by_curve_name(nid);
    EC_GROUP*  group = (EC_GROUP*)EC_KEY_get0_group(ec);
    EC_POINT*  point = EC_POINT_new(group);

    BIGNUM* bn_x = BN_bin2bn(x_bytes.data(), (int)x_bytes.size(), nullptr);
    BIGNUM* bn_y = BN_bin2bn(y_bytes.data(), (int)y_bytes.size(), nullptr);

    if (EC_POINT_set_affine_coordinates(group, point, bn_x, bn_y, nullptr) != 1 ||
        EC_KEY_set_public_key(ec, point) != 1) {
        BN_free(bn_x); BN_free(bn_y);
        EC_POINT_free(point);
        EC_KEY_free(ec);
        throw AuthException(AuthErrorKind::JwksFetchFailed,
                            "EC key construction failed: " + opensslErrors());
    }

    BN_free(bn_x); BN_free(bn_y);
    EC_POINT_free(point);

    EVP_PKEY* pkey = EVP_PKEY_new();
    EVP_PKEY_assign_EC_KEY(pkey, ec);

    BIO* bio = BIO_new(BIO_s_mem());
    PEM_write_bio_PUBKEY(bio, pkey);
    BUF_MEM* bptr = nullptr;
    BIO_get_mem_ptr(bio, &bptr);
    std::string pem(bptr->data, bptr->length);
    BIO_free(bio);
    EVP_PKEY_free(pkey);
    return pem;
}

// ============================================================================
// x5c certificate → SubjectPublicKeyInfo PEM
// ============================================================================

std::string JwksProvider::x5cToPem(const std::string& x5c_b64) {
    // x5c values are standard base64 (not base64url)
    auto der = b64Decode(x5c_b64);

    const unsigned char* ptr = der.data();
    X509* cert = d2i_X509(nullptr, &ptr, (long)der.size());
    if (!cert)
        throw AuthException(AuthErrorKind::JwksFetchFailed,
                            "x5c: d2i_X509 failed: " + opensslErrors());

    EVP_PKEY* pkey = X509_get_pubkey(cert);
    X509_free(cert);
    if (!pkey)
        throw AuthException(AuthErrorKind::JwksFetchFailed,
                            "x5c: X509_get_pubkey failed: " + opensslErrors());

    BIO* bio = BIO_new(BIO_s_mem());
    PEM_write_bio_PUBKEY(bio, pkey);
    BUF_MEM* bptr = nullptr;
    BIO_get_mem_ptr(bio, &bptr);
    std::string pem(bptr->data, bptr->length);
    BIO_free(bio);
    EVP_PKEY_free(pkey);
    return pem;
}

// ============================================================================
// Base64 helpers
// ============================================================================

std::vector<uint8_t> JwksProvider::b64urlDecode(const std::string& input) {
    std::string b64 = input;
    for (auto& c : b64) {
        if (c == '-') c = '+';
        if (c == '_') c = '/';
    }
    while (b64.size() % 4) b64 += '=';
    return b64Decode(b64);
}

std::vector<uint8_t> JwksProvider::b64Decode(const std::string& input) {
    BIO* b64bio = BIO_new(BIO_f_base64());
    BIO_set_flags(b64bio, BIO_FLAGS_BASE64_NO_NL);
    BIO* mem = BIO_new_mem_buf(input.data(), (int)input.size());
    BIO_push(b64bio, mem);

    std::vector<uint8_t> out(input.size());
    int len = BIO_read(b64bio, out.data(), (int)out.size());
    BIO_free_all(b64bio);

    out.resize(std::max(0, len));
    return out;
}

// ============================================================================
// URL splitting
// ============================================================================

void JwksProvider::splitUrl(const std::string& url,
                              std::string& scheme,
                              std::string& host,
                              int&         port,
                              std::string& path) {
    static const std::regex re(R"(^(https?)://([^/:]+)(?::(\d+))?(/.*)?)");
    std::smatch m;
    if (!std::regex_match(url, m, re))
        throw std::invalid_argument("Invalid JWKS URI: " + url);

    scheme = m[1].str();
    host   = m[2].str();
    port   = m[3].matched ? std::stoi(m[3].str())
                          : (scheme == "https" ? 443 : 80);
    path   = m[4].matched ? m[4].str() : "/";
}
