#include "auth_middleware.h"

#include <iostream>
#include <sstream>

using json = nlohmann::json;

// Thread-local storage for the claims of the currently executing request.
thread_local TokenClaims g_currentClaims;

// ============================================================================
// Construction
// ============================================================================

AuthMiddleware::AuthMiddleware(const Config& cfg, JwtValidator& validator)
    : cfg_(cfg), validator_(validator) {
    if (cfg_.enabled) {
        std::cout << "[Auth] OAuth 2.0 JWT validation ENABLED (realm="
                  << cfg_.realm << ")\n";
    } else {
        std::cout << "[Auth] OAuth 2.0 JWT validation DISABLED "
                     "(OAUTH_ENABLED=false)\n";
    }
}

// ============================================================================
// require — wrap a handler with Bearer token validation
// ============================================================================

httplib::Server::Handler
AuthMiddleware::require(httplib::Server::Handler handler) {
    return [this, handler](const httplib::Request& req,
                           httplib::Response&      res) {
        if (!cfg_.enabled) {
            // Pass-through mode: clear stale claims, call handler directly
            g_currentClaims = {};
            handler(req, res);
            return;
        }

        // Extract Authorization header
        const std::string authHeader = req.get_header_value("Authorization");

        TokenClaims claims;
        try {
            claims = validator_.validate(authHeader);
        } catch (const AuthException& e) {
            const char* errCode = e.rfc6750Error();
            if (errCode[0] == '\0') {
                // MissingToken — no error= field per RFC 6750
                sendUnauthorized(res, "", e.what());
            } else {
                sendUnauthorized(res, errCode, e.what());
            }
            return;
        } catch (const std::exception& e) {
            sendUnauthorized(res, "invalid_token", e.what());
            return;
        }

        // Inject validated claims into thread-local for handler access
        g_currentClaims = claims;

        std::cout << "[Auth] Authenticated: sub=" << claims.subject
                  << " iss=" << claims.issuer << "\n";

        handler(req, res);
    };
}

// ============================================================================
// requireScope — same as require + scope enforcement
// ============================================================================

httplib::Server::Handler
AuthMiddleware::requireScope(const std::string&      scope,
                              httplib::Server::Handler handler) {
    return [this, scope, handler](const httplib::Request& req,
                                   httplib::Response&      res) {
        if (!cfg_.enabled) {
            g_currentClaims = {};
            handler(req, res);
            return;
        }

        const std::string authHeader = req.get_header_value("Authorization");
        TokenClaims claims;
        try {
            claims = validator_.validate(authHeader);
        } catch (const AuthException& e) {
            sendUnauthorized(res, e.rfc6750Error(), e.what());
            return;
        }

        if (!claims.hasScope(scope)) {
            sendForbidden(res, "Required scope '" + scope + "' not granted");
            return;
        }

        g_currentClaims = claims;
        handler(req, res);
    };
}

// ============================================================================
// Error responses
// ============================================================================

void AuthMiddleware::sendUnauthorized(httplib::Response&  res,
                                       const std::string& rfc6750Error,
                                       const std::string& description) const {
    // Build WWW-Authenticate header per RFC 6750 §3.1
    std::ostringstream www;
    www << "Bearer realm=\"" << cfg_.realm << "\"";
    if (!rfc6750Error.empty()) {
        www << ", error=\"" << rfc6750Error << "\"";
        if (!description.empty())
            www << ", error_description=\"" << description << "\"";
    }

    res.status = 401;
    res.set_header("WWW-Authenticate", www.str());

    json body;
    body["success"]           = false;
    body["error"]["code"]     = 401;
    body["error"]["message"]  = description.empty() ? "Unauthorized" : description;
    if (!rfc6750Error.empty())
        body["error"]["error"] = rfc6750Error;

    res.set_content(body.dump(2), "application/json");
}

void AuthMiddleware::sendForbidden(httplib::Response&  res,
                                    const std::string& description) const {
    // RFC 6750 §3.1: use insufficient_scope for missing scope
    std::ostringstream www;
    www << "Bearer realm=\"" << cfg_.realm << "\""
        << ", error=\"insufficient_scope\""
        << ", error_description=\"" << description << "\"";

    res.status = 403;
    res.set_header("WWW-Authenticate", www.str());

    json body;
    body["success"]          = false;
    body["error"]["code"]    = 403;
    body["error"]["message"] = description;
    body["error"]["error"]   = "insufficient_scope";

    res.set_content(body.dump(2), "application/json");
}
