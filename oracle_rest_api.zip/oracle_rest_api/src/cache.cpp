#include "cache.h"

#include <cstdarg>
#include <iostream>
#include <sstream>
#include <vector>

// ============================================================================
// Construction / destruction
// ============================================================================

RedisCache::RedisCache(const Config& cfg) : cfg_(cfg) {
    if (!cfg_.enabled) {
        std::cout << "[Cache] Caching DISABLED by configuration.\n";
        return;
    }
    if (tryConnect()) {
        std::cout << "[Cache] Connected to Redis "
                  << cfg_.host << ":" << cfg_.port
                  << " (db=" << cfg_.db << ")\n";
    } else {
        std::cout << "[Cache] WARNING — could not connect to Redis. "
                     "Requests will bypass the cache.\n";
    }
}

RedisCache::~RedisCache() {
    std::lock_guard<std::mutex> lk(mtx_);
    doDisconnect();
}

// ============================================================================
// Connection helpers  (all called with mtx_ held, except tryConnect)
// ============================================================================

bool RedisCache::tryConnect() {
    std::lock_guard<std::mutex> lk(mtx_);

    doDisconnect();   // close stale connection if any

    struct timeval tv;
    tv.tv_sec  = cfg_.connectMs / 1000;
    tv.tv_usec = (cfg_.connectMs % 1000) * 1000;

    ctx_ = redisConnectWithTimeout(cfg_.host.c_str(), cfg_.port, tv);
    if (!ctx_ || ctx_->err) {
        std::cerr << "[Cache] redisConnect error: "
                  << (ctx_ ? ctx_->errstr : "allocation failure") << "\n";
        doDisconnect();
        return false;
    }

    // AUTH
    if (!cfg_.password.empty()) {
        redisReply* r = (redisReply*)redisCommand(ctx_, "AUTH %s",
                                                  cfg_.password.c_str());
        if (!r || r->type == REDIS_REPLY_ERROR) {
            std::cerr << "[Cache] Redis AUTH failed: "
                      << (r ? r->str : "no reply") << "\n";
            if (r) freeReplyObject(r);
            doDisconnect();
            return false;
        }
        freeReplyObject(r);
    }

    // SELECT db
    if (cfg_.db != 0) {
        redisReply* r = (redisReply*)redisCommand(ctx_, "SELECT %d", cfg_.db);
        if (!r || r->type == REDIS_REPLY_ERROR) {
            std::cerr << "[Cache] Redis SELECT " << cfg_.db << " failed\n";
            if (r) freeReplyObject(r);
            doDisconnect();
            return false;
        }
        freeReplyObject(r);
    }

    connected_.store(true, std::memory_order_relaxed);
    return true;
}

bool RedisCache::ensureConnected() {
    // Already good
    if (ctx_ && !ctx_->err) return true;

    // Attempt one reconnect (mtx_ already held by caller)
    doDisconnect();

    struct timeval tv;
    tv.tv_sec  = cfg_.connectMs / 1000;
    tv.tv_usec = (cfg_.connectMs % 1000) * 1000;

    ctx_ = redisConnectWithTimeout(cfg_.host.c_str(), cfg_.port, tv);
    if (!ctx_ || ctx_->err) {
        std::cerr << "[Cache] reconnect failed: "
                  << (ctx_ ? ctx_->errstr : "alloc failure") << "\n";
        doDisconnect();
        return false;
    }

    if (!cfg_.password.empty()) {
        redisReply* r = (redisReply*)redisCommand(ctx_, "AUTH %s",
                                                  cfg_.password.c_str());
        bool ok = r && r->type != REDIS_REPLY_ERROR;
        if (r) freeReplyObject(r);
        if (!ok) { doDisconnect(); return false; }
    }
    if (cfg_.db != 0) {
        redisReply* r = (redisReply*)redisCommand(ctx_, "SELECT %d", cfg_.db);
        bool ok = r && r->type != REDIS_REPLY_ERROR;
        if (r) freeReplyObject(r);
        if (!ok) { doDisconnect(); return false; }
    }

    connected_.store(true, std::memory_order_relaxed);
    std::cout << "[Cache] Reconnected to Redis.\n";
    return true;
}

void RedisCache::doDisconnect() {
    if (ctx_) {
        redisFree(ctx_);
        ctx_ = nullptr;
    }
    connected_.store(false, std::memory_order_relaxed);
}

// ============================================================================
// runCmd — variadic command execution (mtx_ must be held by caller)
// ============================================================================

redisReply* RedisCache::runCmd(const char* fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    redisReply* r = (redisReply*)redisvCommand(ctx_, fmt, ap);
    va_end(ap);

    if (!r || ctx_->err) {
        std::cerr << "[Cache] command error: "
                  << (ctx_ ? ctx_->errstr : "null reply") << "\n";
        if (r) freeReplyObject(r);
        doDisconnect();
        return nullptr;
    }
    return r;
}

// ============================================================================
// Core operations
// ============================================================================

std::optional<nlohmann::json> RedisCache::get(const std::string& key) {
    if (!cfg_.enabled) return std::nullopt;

    std::lock_guard<std::mutex> lk(mtx_);
    if (!ensureConnected()) { stats_.errors++; return std::nullopt; }

    redisReply* r = runCmd("GET %s", key.c_str());
    if (!r) { stats_.errors++; return std::nullopt; }

    if (r->type == REDIS_REPLY_NIL) {
        freeReplyObject(r);
        stats_.misses++;
        return std::nullopt;                    // cache MISS
    }

    std::string raw(r->str, r->len);
    freeReplyObject(r);

    try {
        auto j = nlohmann::json::parse(raw);
        stats_.hits++;
        return j;                               // cache HIT
    } catch (const nlohmann::json::parse_error& e) {
        std::cerr << "[Cache] JSON parse error for key '" << key
                  << "': " << e.what() << "\n";
        stats_.errors++;
        return std::nullopt;
    }
}

// ---------------------------------------------------------------------------
void RedisCache::set(const std::string& key,
                     const nlohmann::json& value,
                     int ttlSec) {
    if (!cfg_.enabled) return;

    const std::string serialised = value.dump();

    std::lock_guard<std::mutex> lk(mtx_);
    if (!ensureConnected()) { stats_.errors++; return; }

    // SET key value EX ttl
    redisReply* r = runCmd("SET %s %b EX %d",
                           key.c_str(),
                           serialised.c_str(), serialised.size(),
                           ttlSec);
    if (r) {
        freeReplyObject(r);
        stats_.sets++;
    } else {
        stats_.errors++;
    }
}

// ---------------------------------------------------------------------------
void RedisCache::del(const std::string& key) {
    if (!cfg_.enabled) return;

    std::lock_guard<std::mutex> lk(mtx_);
    if (!ensureConnected()) { stats_.errors++; return; }

    redisReply* r = runCmd("DEL %s", key.c_str());
    if (r) {
        freeReplyObject(r);
        stats_.dels++;
    } else {
        stats_.errors++;
    }
}

// ---------------------------------------------------------------------------
// delByPattern — SCAN-based pattern delete (non-blocking, cursor loop)
// ---------------------------------------------------------------------------
int RedisCache::delByPattern(const std::string& pattern) {
    if (!cfg_.enabled) return 0;

    std::lock_guard<std::mutex> lk(mtx_);
    if (!ensureConnected()) { stats_.errors++; return 0; }

    int totalDeleted = 0;
    long long cursor = 0;

    do {
        // SCAN cursor MATCH pattern COUNT 100
        redisReply* scanReply = runCmd(
            "SCAN %lld MATCH %s COUNT 100",
            cursor, pattern.c_str());

        if (!scanReply) { stats_.errors++; break; }

        // scanReply->element[0] = new cursor (string)
        // scanReply->element[1] = array of matching key strings
        if (scanReply->type  != REDIS_REPLY_ARRAY ||
            scanReply->elements != 2) {
            freeReplyObject(scanReply);
            break;
        }

        cursor = std::atoll(scanReply->element[0]->str);
        redisReply* keys = scanReply->element[1];

        if (keys->elements > 0) {
            // Build DEL key1 key2 … using redisCommandArgv
            std::vector<const char*> argv;
            std::vector<size_t>      argvLen;
            argv.push_back("DEL");
            argvLen.push_back(3);

            for (size_t i = 0; i < keys->elements; i++) {
                argv.push_back(keys->element[i]->str);
                argvLen.push_back((size_t)keys->element[i]->len);
            }

            redisReply* delReply = (redisReply*)redisCommandArgv(
                ctx_,
                (int)argv.size(),
                argv.data(),
                argvLen.data());

            if (delReply) {
                if (delReply->type == REDIS_REPLY_INTEGER)
                    totalDeleted += (int)delReply->integer;
                freeReplyObject(delReply);
                stats_.dels += (uint64_t)keys->elements;
            } else {
                stats_.errors++;
            }
        }

        freeReplyObject(scanReply);

    } while (cursor != 0);

    return totalDeleted;
}

// ============================================================================
// Key builders
// ============================================================================

std::string RedisCache::buildKey(std::initializer_list<std::string> parts) const {
    std::string key = cfg_.keyPrefix;
    bool first = true;
    for (const auto& part : parts) {
        if (!first) key += ':';
        key += part;
        first = false;
    }
    return key;
}

// static
std::string RedisCache::paramsKey(const std::map<std::string, std::string>& params) {
    // The map is already sorted by key → deterministic output.
    std::ostringstream oss;
    bool first = true;
    for (const auto& [k, v] : params) {
        if (!first) oss << '&';
        oss << k << '=' << v;
        first = false;
    }
    return oss.str();
}

// ============================================================================
// Status
// ============================================================================

bool RedisCache::ping() {
    if (!cfg_.enabled) return false;

    std::lock_guard<std::mutex> lk(mtx_);
    if (!ensureConnected()) return false;

    redisReply* r = runCmd("PING");
    if (!r) return false;

    bool ok = (r->type == REDIS_REPLY_STATUS &&
               std::string(r->str) == "PONG");
    freeReplyObject(r);
    return ok;
}

bool RedisCache::isConnected() const {
    return connected_.load(std::memory_order_relaxed);
}

RedisCache::Stats RedisCache::getStats() const {
    std::lock_guard<std::mutex> lk(mtx_);
    return stats_;
}
