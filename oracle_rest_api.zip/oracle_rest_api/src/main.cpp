#include "api_server.h"
#include "auth_middleware.h"
#include "cache.h"
#include "db_connection.h"
#include "external_api_service.h"
#include "jwks_provider.h"
#include "jwt_validator.h"
#include "soap_service.h"

#include <csignal>
#include <cstdlib>
#include <iostream>
#include <memory>
#include <set>
#include <string>

// ---------------------------------------------------------------------------
// Global server pointer for signal handler
// ---------------------------------------------------------------------------
static ApiServer* g_server = nullptr;

static void signalHandler(int sig) {
    std::cout << "\n[Main] Signal " << sig << " — shutting down...\n";
    if (g_server) g_server->stop();
}

// ---------------------------------------------------------------------------
// Helper: read env var with fallback default
// ---------------------------------------------------------------------------
static std::string envOr(const char* name, const char* fallback) {
    const char* v = std::getenv(name);
    return v ? v : fallback;
}

// ---------------------------------------------------------------------------
// main
//
// Environment variables:
//
//  Oracle DB
//    DB_USER                 (default: hr)
//    DB_PASSWORD             (default: hr)
//    DB_DSN                  (default: localhost:1521/XEPDB1)
//
//  HTTP server
//    SERVER_HOST             (default: 0.0.0.0)
//    SERVER_PORT             (default: 8080)
//
//  Redis cache
//    REDIS_HOST              (default: 127.0.0.1)
//    REDIS_PORT              (default: 6379)
//    REDIS_DB                (default: 0)
//    REDIS_PASSWORD          (default: "")
//    REDIS_ENABLED           (default: true)   set "false" to disable caching
//    REDIS_KEY_PREFIX        (default: oracle_api:v1:)
//
//  External REST API
//    EXTERNAL_API_BASE_URL   (default: http://jsonplaceholder.typicode.com)
//    EXTERNAL_API_TOKEN      (default: "")
//
//  SOAP Calculator service
//    SOAP_CALC_HOST          (default: http://www.dneonline.com)
//    SOAP_CALC_PATH          (default: /calculator.asmx)
//
//  SOAP Country info service
//    SOAP_COUNTRY_HOST       (default: http://webservices.oorsprong.org)
//    SOAP_COUNTRY_PATH       (default: /websamples.countryinfo/CountryInfoService.wso)
//
//  OAuth 2.0 / JWT
//    OAUTH_ENABLED           (default: true)   set "false" to disable auth (dev only)
//    OAUTH_JWKS_URI          REQUIRED when OAUTH_ENABLED=true
//                            e.g. https://my-idp.example.com/.well-known/jwks.json
//    OAUTH_ISSUER            (default: "")  validated if non-empty
//    OAUTH_AUDIENCE          (default: "")  validated if non-empty
//    OAUTH_REALM             (default: oracle-rest-api)  WWW-Authenticate realm
//    OAUTH_JWKS_CACHE_TTL_SEC (default: 3600)  how long JWKS keys are cached in Redis
//    OAUTH_CLOCK_SKEW_SEC    (default: 30)   leeway for exp / nbf checks
// ---------------------------------------------------------------------------
int main() {
    // ---- Server & DB config ----
    const std::string dbUser  = envOr("DB_USER",     "hr");
    const std::string dbPass  = envOr("DB_PASSWORD", "hr");
    const std::string dbDsn   = envOr("DB_DSN",      "localhost:1521/XEPDB1");
    const std::string srvHost = envOr("SERVER_HOST", "0.0.0.0");
    const int         srvPort = std::stoi(envOr("SERVER_PORT", "8080"));

    // ---- Redis config ----
    RedisCache::Config redisCfg;
    redisCfg.host      = envOr("REDIS_HOST",       "127.0.0.1");
    redisCfg.port      = std::stoi(envOr("REDIS_PORT", "6379"));
    redisCfg.db        = std::stoi(envOr("REDIS_DB",   "0"));
    redisCfg.password  = envOr("REDIS_PASSWORD",   "");
    redisCfg.keyPrefix = envOr("REDIS_KEY_PREFIX", "oracle_api:v1:");
    redisCfg.enabled   = (envOr("REDIS_ENABLED",   "true") != "false");

    // ---- External REST API config ----
    const std::string extApiUrl   = envOr("EXTERNAL_API_BASE_URL",
                                          "http://jsonplaceholder.typicode.com");
    const std::string extApiToken = envOr("EXTERNAL_API_TOKEN", "");

    // ---- SOAP services config ----
    const std::string soapCalcHost    = envOr("SOAP_CALC_HOST",
                                              "http://www.dneonline.com");
    const std::string soapCalcPath    = envOr("SOAP_CALC_PATH",
                                              "/calculator.asmx");
    const std::string soapCountryHost = envOr("SOAP_COUNTRY_HOST",
        "http://webservices.oorsprong.org");
    const std::string soapCountryPath = envOr("SOAP_COUNTRY_PATH",
        "/websamples.countryinfo/CountryInfoService.wso");

    // ---- OAuth 2.0 / JWT config ----
    const bool        oauthEnabled  = (envOr("OAUTH_ENABLED",  "true") != "false");
    const std::string jwksUri       = envOr("OAUTH_JWKS_URI",  "");
    const std::string oauthIssuer   = envOr("OAUTH_ISSUER",    "");
    const std::string oauthAudience = envOr("OAUTH_AUDIENCE",  "");
    const std::string oauthRealm    = envOr("OAUTH_REALM",     "oracle-rest-api");
    const int         jwksCacheTtl  = std::stoi(envOr("OAUTH_JWKS_CACHE_TTL_SEC", "3600"));
    const int         clockSkewSec  = std::stoi(envOr("OAUTH_CLOCK_SKEW_SEC",     "30"));

    if (oauthEnabled && jwksUri.empty()) {
        std::cerr << "[FATAL] OAUTH_ENABLED=true but OAUTH_JWKS_URI is not set.\n"
                  << "        Set OAUTH_JWKS_URI to your IdP's JWKS endpoint, or\n"
                  << "        set OAUTH_ENABLED=false to run without auth (dev only).\n";
        return EXIT_FAILURE;
    }

    // ---- Print startup banner ----
    std::cout << "=======================================\n"
              << "  Oracle REST API  (C++17 / OCI)\n"
              << "=======================================\n"
              << "[DB]      DSN          : " << dbDsn     << "\n"
              << "[DB]      User         : " << dbUser    << "\n"
              << "[HTTP]    Bind         : " << srvHost   << ":" << srvPort << "\n"
              << "[Cache]   Redis        : " << redisCfg.host << ":" << redisCfg.port
              << " (db=" << redisCfg.db << ") "
              << (redisCfg.enabled ? "ENABLED" : "DISABLED") << "\n"
              << "[ExtREST] Base URL     : " << extApiUrl << "\n"
              << "[SOAP]    Calculator   : " << soapCalcHost + soapCalcPath   << "\n"
              << "[SOAP]    Country info : " << soapCountryHost + soapCountryPath << "\n"
              << "[Auth]    OAuth 2.0    : " << (oauthEnabled ? "ENABLED" : "DISABLED") << "\n";
    if (oauthEnabled) {
        std::cout << "[Auth]    JWKS URI     : " << jwksUri << "\n"
                  << "[Auth]    Issuer       : " << (oauthIssuer.empty()   ? "(any)" : oauthIssuer)   << "\n"
                  << "[Auth]    Audience     : " << (oauthAudience.empty() ? "(any)" : oauthAudience) << "\n"
                  << "[Auth]    Realm        : " << oauthRealm << "\n"
                  << "[Auth]    JWKS TTL     : " << jwksCacheTtl << "s\n"
                  << "[Auth]    Clock skew   : " << clockSkewSec << "s\n";
    }

    // ---- Connect to Oracle ----
    std::unique_ptr<OracleDB> db;
    try {
        std::cout << "[DB] Connecting...\n";
        db = std::make_unique<OracleDB>(dbUser, dbPass, dbDsn);
        std::cout << "[DB] Connected.\n";
    } catch (const DBException& e) {
        std::cerr << "[FATAL] Cannot connect to Oracle: " << e.what() << "\n";
        return EXIT_FAILURE;
    }

    // ---- Connect to Redis (non-fatal — fail-open) ----
    RedisCache cache(redisCfg);
    if (redisCfg.enabled && !cache.isConnected()) {
        std::cerr << "[WARN] Redis unavailable — running without cache.\n";
    }

    // ---- Build OAuth 2.0 auth stack ----
    //
    // Stack:  JwksProvider → JwtValidator → AuthMiddleware
    //
    // When OAUTH_ENABLED=false the AuthMiddleware is configured as a
    // transparent pass-through; the JwksProvider/JwtValidator objects still
    // exist but are never called.
    JwksProvider::Config jwksCfg;
    jwksCfg.jwksUri       = oauthEnabled ? jwksUri : "http://localhost/dummy-jwks";
    jwksCfg.cacheTtlSec   = jwksCacheTtl;
    jwksCfg.fetchTimeoutSec = 10;

    auto jwksProv = std::make_unique<JwksProvider>(jwksCfg, cache);

    JwtValidator::Config valCfg;
    valCfg.issuer       = oauthIssuer;
    valCfg.audience     = oauthAudience;
    valCfg.clockSkewSec = clockSkewSec;
    // Allow all asymmetric algorithms supported by jwt-cpp / OpenSSL.
    // Symmetric (HS*) are intentionally excluded for resource-server use.
    valCfg.allowedAlgorithms = {
        "RS256", "RS384", "RS512",
        "ES256", "ES384", "ES512",
        "PS256", "PS384", "PS512"
    };

    auto jwtVal = std::make_unique<JwtValidator>(valCfg, *jwksProv);

    AuthMiddleware::Config authCfg;
    authCfg.enabled = oauthEnabled;
    authCfg.realm   = oauthRealm;

    auto auth = std::make_unique<AuthMiddleware>(authCfg, *jwtVal);

    // ---- Construct downstream service clients ----
    ExternalApiService    extSvc(extApiUrl, extApiToken);
    SoapCalculatorService calcSvc(soapCalcHost, soapCalcPath);
    SoapCountryService    countrySvc(soapCountryHost, soapCountryPath);

    // ---- Create and start API server ----
    ApiServer server(*db, cache, *auth, extSvc, calcSvc, countrySvc, srvHost, srvPort);
    g_server = &server;

    std::signal(SIGINT,  signalHandler);
    std::signal(SIGTERM, signalHandler);

    server.listen();   // blocks until stop() is called

    std::cout << "[Main] Stopped.\n";
    return EXIT_SUCCESS;
}
