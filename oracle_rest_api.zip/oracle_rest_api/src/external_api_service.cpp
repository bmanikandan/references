#include "external_api_service.h"

#include <stdexcept>
#include <string>

using json = nlohmann::json;

// ============================================================================
// Construction
// ============================================================================

ExternalApiService::ExternalApiService(const std::string& baseUrl,
                                        const std::string& authToken)
    : client_(baseUrl, {.readTimeoutSec = 20}) {
    if (!authToken.empty()) {
        client_.setBearer(authToken);
    }
}

// ============================================================================
// Posts
// ============================================================================

json ExternalApiService::listPosts(int limit, int page) {
    // JSONPlaceholder supports _limit and _page query params
    httplib::Params params = {
        {"_limit", std::to_string(limit)},
        {"_page",  std::to_string(page)}
    };

    auto resp = client_.get("/posts", params);
    if (!resp.ok()) {
        throw HttpClientException(
            "listPosts failed: HTTP " + std::to_string(resp.status),
            resp.status);
    }
    return resp.json();
}

json ExternalApiService::getPost(int id) {
    auto resp = client_.get("/posts/" + std::to_string(id));
    if (resp.status == 404) {
        throw HttpClientException("Post " + std::to_string(id) + " not found",
                                  404);
    }
    if (!resp.ok()) {
        throw HttpClientException(
            "getPost failed: HTTP " + std::to_string(resp.status), resp.status);
    }
    return resp.json();
}

json ExternalApiService::createPost(const json& body) {
    auto resp = client_.postJson("/posts", body);
    if (!resp.ok()) {
        throw HttpClientException(
            "createPost failed: HTTP " + std::to_string(resp.status),
            resp.status);
    }
    return resp.json();
}

// ============================================================================
// Users
// ============================================================================

json ExternalApiService::listUsers() {
    auto resp = client_.get("/users");
    if (!resp.ok()) {
        throw HttpClientException(
            "listUsers failed: HTTP " + std::to_string(resp.status),
            resp.status);
    }
    return resp.json();
}

json ExternalApiService::getUser(int id) {
    auto resp = client_.get("/users/" + std::to_string(id));
    if (resp.status == 404) {
        throw HttpClientException("User " + std::to_string(id) + " not found",
                                  404);
    }
    if (!resp.ok()) {
        throw HttpClientException(
            "getUser failed: HTTP " + std::to_string(resp.status), resp.status);
    }
    return resp.json();
}
