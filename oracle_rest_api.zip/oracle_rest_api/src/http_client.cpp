#include "http_client.h"

#include <iostream>
#include <regex>
#include <sstream>
#include <stdexcept>

// ============================================================================
// URL parsing helper
// ============================================================================

void HttpClient::parseUrl(const std::string& url,
                          std::string& scheme,
                          std::string& host,
                          int& port,
                          std::string& basePath) {
    // Simple regex: scheme://host[:port][/path]
    static const std::regex re(
        R"(^(https?)://([^/:]+)(?::(\d+))?(/.*)?)");

    std::smatch m;
    if (!std::regex_match(url, m, re)) {
        throw HttpClientException("Invalid base URL: " + url);
    }

    scheme   = m[1].str();
    host     = m[2].str();
    port     = m[3].matched ? std::stoi(m[3].str())
                            : (scheme == "https" ? 443 : 80);
    basePath = m[4].matched ? m[4].str() : "";
}

// ============================================================================
// Constructor
// ============================================================================

HttpClient::HttpClient(const std::string& baseUrl, const ClientConfig& cfg)
    : cfg_(cfg) {
    std::string scheme, host, basePath;
    int port = 0;
    parseUrl(baseUrl, scheme, host, port, basePath);

#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
    if (scheme == "https") {
        cli_ = std::make_unique<httplib::Client>(host, port);
        cli_->enable_server_certificate_verification(true);
    } else {
        cli_ = std::make_unique<httplib::Client>(host, port);
    }
#else
    if (scheme == "https") {
        throw HttpClientException(
            "HTTPS requires OpenSSL. Build with -DCMAKE_BUILD_TYPE=Release "
            "and ensure OpenSSL is installed.");
    }
    cli_ = std::make_unique<httplib::Client>(host, port);
#endif

    cli_->set_connection_timeout(cfg_.connectTimeoutSec);
    cli_->set_read_timeout(cfg_.readTimeoutSec);
    cli_->set_follow_location(cfg_.followRedirects);

    // Default headers for every request
    defaultHeaders_ = {{"Accept", "application/json"},
                       {"User-Agent", "OracleRestAPI-Client/1.0"}};

    for (const auto& [k, v] : cfg_.defaultHeaders) {
        defaultHeaders_.emplace(k, v);
    }
}

// ============================================================================
// Auth helpers
// ============================================================================

void HttpClient::setBearer(const std::string& token) {
    // Remove existing Authorization header if present
    defaultHeaders_.erase("Authorization");
    defaultHeaders_.emplace("Authorization", "Bearer " + token);
}

void HttpClient::setBasicAuth(const std::string& user,
                              const std::string& password) {
    cli_->set_basic_auth(user, password);
}

void HttpClient::setHeader(const std::string& name, const std::string& value) {
    defaultHeaders_.erase(name);
    defaultHeaders_.emplace(name, value);
}

// ============================================================================
// Response conversion
// ============================================================================

HttpResponse HttpClient::toResponse(const httplib::Result& result,
                                    const std::string& method,
                                    const std::string& path) const {
    if (!result) {
        auto errType = result.error();
        std::ostringstream oss;
        oss << method << " " << path << " failed: "
            << httplib::to_string(errType);
        throw HttpClientException(oss.str());
    }

    HttpResponse resp;
    resp.status = result->status;
    resp.body   = result->body;

    for (const auto& [k, v] : result->headers) {
        // Store lower-case key for case-insensitive lookup
        std::string key = k;
        for (auto& c : key) c = (char)std::tolower((unsigned char)c);
        resp.headers[key] = v;
    }

    if (!resp.ok()) {
        std::cerr << "[HttpClient] " << method << " " << path
                  << " → HTTP " << resp.status << "\n";
    }

    return resp;
}

// ============================================================================
// HTTP verbs
// ============================================================================

HttpResponse HttpClient::get(const std::string& path,
                             const httplib::Params& queryParams) {
    std::string fullPath = path;
    if (!queryParams.empty()) {
        fullPath += "?" + httplib::detail::params_to_query_str(queryParams);
    }
    auto result = cli_->Get(fullPath, defaultHeaders_);
    return toResponse(result, "GET", fullPath);
}

HttpResponse HttpClient::post(const std::string& path,
                              const std::string& body,
                              const std::string& contentType) {
    auto headers = defaultHeaders_;
    headers.emplace("Content-Type", contentType);
    auto result = cli_->Post(path, headers, body, contentType);
    return toResponse(result, "POST", path);
}

HttpResponse HttpClient::postJson(const std::string& path,
                                  const nlohmann::json& body) {
    return post(path, body.dump(), "application/json");
}

HttpResponse HttpClient::put(const std::string& path,
                             const std::string& body,
                             const std::string& contentType) {
    auto headers = defaultHeaders_;
    headers.emplace("Content-Type", contentType);
    auto result = cli_->Put(path, headers, body, contentType);
    return toResponse(result, "PUT", path);
}

HttpResponse HttpClient::putJson(const std::string& path,
                                 const nlohmann::json& body) {
    return put(path, body.dump(), "application/json");
}

HttpResponse HttpClient::patch(const std::string& path,
                               const std::string& body,
                               const std::string& contentType) {
    auto headers = defaultHeaders_;
    headers.emplace("Content-Type", contentType);
    auto result = cli_->Patch(path, headers, body, contentType);
    return toResponse(result, "PATCH", path);
}

HttpResponse HttpClient::patchJson(const std::string& path,
                                   const nlohmann::json& body) {
    return patch(path, body.dump(), "application/json");
}

HttpResponse HttpClient::del(const std::string& path) {
    auto result = cli_->Delete(path, defaultHeaders_);
    return toResponse(result, "DELETE", path);
}
