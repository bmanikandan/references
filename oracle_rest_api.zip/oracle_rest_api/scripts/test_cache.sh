#!/usr/bin/env bash
# =============================================================================
# Cache smoke-test — verifies Redis caching behaviour for all GET endpoints.
#
# What it checks:
#   1. First request  → X-Cache: MISS  (data fetched from origin)
#   2. Second request → X-Cache: HIT   (data returned from Redis)
#   3. Write (PUT/DELETE) → cache invalidated → next GET is MISS again
#   4. Cache stats endpoint reflects hit/miss counts
#   5. Manual cache flush endpoints work
#
# Usage:  ./scripts/test_cache.sh [http://localhost:8080]
# =============================================================================

set -euo pipefail

BASE="${1:-http://localhost:8080}/api/v1"

ok()  { echo -e "\033[32m✔  $1\033[0m"; }
err() { echo -e "\033[31m✘  $1\033[0m"; exit 1; }
sep() { echo -e "\n\033[36m════════════════════════════════════════\033[0m"
        echo -e "\033[36m  $1\033[0m"
        echo -e "\033[36m════════════════════════════════════════\033[0m"; }

# Get the X-Cache header value from a URL
xcache() { curl -sI "$1" | grep -i 'x-cache' | awk '{print $2}' | tr -d '\r'; }

json_id() {
    python3 -c "import sys,json; print(json.load(sys.stdin)['data']['id'])"
}

# ---------------------------------------------------------------------------
sep "Health — cache status"
curl -sf "$BASE/health" | python3 -m json.tool
ok "Health with cache info"

# ===========================================================================
sep "EMPLOYEE CACHE"
# ---------------------------------------------------------------------------
EMP_URL="$BASE/employees"

echo "--- 1st GET (expect MISS) ---"
HIT=$(xcache "$EMP_URL")
[[ "$HIT" == "MISS" ]] && ok "employees list MISS" || err "Expected MISS, got '$HIT'"

echo "--- 2nd GET (expect HIT) ---"
HIT=$(xcache "$EMP_URL")
[[ "$HIT" == "HIT" ]]  && ok "employees list HIT"  || err "Expected HIT, got '$HIT'"

echo "--- Filtered list (expect MISS then HIT) ---"
URL2="$EMP_URL?dept=Engineering&limit=3"
HIT=$(xcache "$URL2")
[[ "$HIT" == "MISS" ]] && ok "filtered MISS" || err "Expected MISS, got '$HIT'"
HIT=$(xcache "$URL2")
[[ "$HIT" == "HIT"  ]] && ok "filtered HIT"  || err "Expected HIT, got '$HIT'"

echo "--- Create employee → invalidates list cache ---"
CREATE=$(curl -sf -X POST "$EMP_URL" \
    -H "Content-Type: application/json" \
    -d '{"name":"Cache Test","email":"cachetest@example.com","department":"QA","salary":50000}')
EMP_ID=$(echo "$CREATE" | json_id)
ok "Created employee id=$EMP_ID"

echo "--- List after create (expect MISS — cache was invalidated) ---"
HIT=$(xcache "$EMP_URL")
[[ "$HIT" == "MISS" ]] && ok "list MISS after POST" || err "Expected MISS, got '$HIT'"

echo "--- Get by id (expect MISS) ---"
HIT=$(xcache "$EMP_URL/$EMP_ID")
[[ "$HIT" == "MISS" ]] && ok "get-by-id MISS" || err "Expected MISS, got '$HIT'"

echo "--- Get by id again (expect HIT) ---"
HIT=$(xcache "$EMP_URL/$EMP_ID")
[[ "$HIT" == "HIT"  ]] && ok "get-by-id HIT"  || err "Expected HIT, got '$HIT'"

echo "--- PATCH employee → invalidates item + lists ---"
curl -sf -X PATCH "$EMP_URL/$EMP_ID" \
    -H "Content-Type: application/json" \
    -d '{"salary":55000}' > /dev/null
ok "PATCH sent"

echo "--- Get by id after PATCH (expect MISS) ---"
HIT=$(xcache "$EMP_URL/$EMP_ID")
[[ "$HIT" == "MISS" ]] && ok "get-by-id MISS after PATCH" || err "Expected MISS, got '$HIT'"

echo "--- DELETE employee → invalidates item + lists ---"
curl -sf -X DELETE "$EMP_URL/$EMP_ID" > /dev/null
ok "DELETE sent"

echo "--- List after DELETE (expect MISS) ---"
HIT=$(xcache "$EMP_URL")
[[ "$HIT" == "MISS" ]] && ok "list MISS after DELETE" || err "Expected MISS, got '$HIT'"

# ===========================================================================
sep "EXTERNAL REST CACHE"
# ---------------------------------------------------------------------------
POST_URL="$BASE/external/posts"
USER_URL="$BASE/external/users"

echo "--- Posts list MISS ---"
HIT=$(xcache "$POST_URL?limit=5")
[[ "$HIT" == "MISS" ]] && ok "posts list MISS" || err "Got '$HIT'"
echo "--- Posts list HIT ---"
HIT=$(xcache "$POST_URL?limit=5")
[[ "$HIT" == "HIT"  ]] && ok "posts list HIT"  || err "Got '$HIT'"

echo "--- Post by id MISS ---"
HIT=$(xcache "$POST_URL/1")
[[ "$HIT" == "MISS" ]] && ok "post/1 MISS" || err "Got '$HIT'"
echo "--- Post by id HIT ---"
HIT=$(xcache "$POST_URL/1")
[[ "$HIT" == "HIT"  ]] && ok "post/1 HIT"  || err "Got '$HIT'"

echo "--- Users list MISS ---"
HIT=$(xcache "$USER_URL")
[[ "$HIT" == "MISS" ]] && ok "users list MISS" || err "Got '$HIT'"
echo "--- Users list HIT ---"
HIT=$(xcache "$USER_URL")
[[ "$HIT" == "HIT"  ]] && ok "users list HIT"  || err "Got '$HIT'"

# ===========================================================================
sep "SOAP COUNTRY CACHE  (TTL = 1 hour)"
# ---------------------------------------------------------------------------
COUNTRY_URL="$BASE/soap/country"

echo "--- Country name GB MISS ---"
HIT=$(xcache "$COUNTRY_URL/GB/name")
[[ "$HIT" == "MISS" ]] && ok "country GB name MISS" || err "Got '$HIT'"
echo "--- Country name GB HIT ---"
HIT=$(xcache "$COUNTRY_URL/GB/name")
[[ "$HIT" == "HIT"  ]] && ok "country GB name HIT"  || err "Got '$HIT'"

echo "--- Currency US MISS ---"
HIT=$(xcache "$COUNTRY_URL/US/currency")
[[ "$HIT" == "MISS" ]] && ok "currency US MISS" || err "Got '$HIT'"
echo "--- Currency US HIT ---"
HIT=$(xcache "$COUNTRY_URL/US/currency")
[[ "$HIT" == "HIT"  ]] && ok "currency US HIT"  || err "Got '$HIT'"

# ===========================================================================
sep "SOAP CALCULATOR  (never cached)"
# ---------------------------------------------------------------------------
echo "--- Add: expect BYPASS ---"
RESP=$(curl -sf -X POST "$BASE/soap/calculator/add" \
    -H "Content-Type: application/json" -d '{"a":3,"b":4}' -D -)
HIT=$(echo "$RESP" | grep -i 'x-cache' | awk '{print $2}' | tr -d '\r')
[[ "$HIT" == "BYPASS" ]] && ok "calculator BYPASS" || err "Expected BYPASS, got '$HIT'"

# ===========================================================================
sep "CACHE MANAGEMENT ENDPOINTS"
# ---------------------------------------------------------------------------
echo "--- Cache stats ---"
curl -sf "$BASE/cache/stats" | python3 -m json.tool && ok "Stats endpoint"

echo "--- Flush employee cache ---"
curl -sf -X DELETE "$BASE/cache/employees" | python3 -m json.tool && ok "Employee flush"
HIT=$(xcache "$EMP_URL")
[[ "$HIT" == "MISS" ]] && ok "employees MISS after flush" || err "Expected MISS, got '$HIT'"

echo "--- Flush external cache ---"
curl -sf -X DELETE "$BASE/cache/external" | python3 -m json.tool && ok "External flush"

echo "--- Flush soap cache ---"
curl -sf -X DELETE "$BASE/cache/soap" | python3 -m json.tool && ok "SOAP flush"

# ===========================================================================
echo ""
echo -e "\033[32m  All cache tests passed.\033[0m"
