#!/usr/bin/env bash
# =============================================================================
# Run the Oracle REST API server
# Reads config from environment variables (override as needed).
# =============================================================================

set -euo pipefail

BINARY="./build/OracleRestAPI"

if [[ ! -x "$BINARY" ]]; then
    echo "Binary not found. Run ./scripts/build.sh first."
    exit 1
fi

export DB_USER="${DB_USER:-hr}"
export DB_PASSWORD="${DB_PASSWORD:-hr}"
export DB_DSN="${DB_DSN:-localhost:1521/XEPDB1}"
export SERVER_HOST="${SERVER_HOST:-0.0.0.0}"
export SERVER_PORT="${SERVER_PORT:-8080}"

# If using Instant Client, set library path
if [[ -n "${ORACLE_HOME:-}" ]]; then
    if [[ "$(uname)" == "Darwin" ]]; then
        export DYLD_LIBRARY_PATH="${ORACLE_HOME}:${DYLD_LIBRARY_PATH:-}"
    else
        export LD_LIBRARY_PATH="${ORACLE_HOME}:${ORACLE_HOME}/lib:${LD_LIBRARY_PATH:-}"
    fi
fi

exec "$BINARY"
