#!/usr/bin/env bash
# =============================================================================
# Build script for Oracle REST API
#
# Prerequisites:
#   - CMake >= 3.16
#   - C++17 capable compiler (GCC 9+ or Clang 9+)
#   - Oracle Instant Client (with SDK) installed
#   - Internet access for FetchContent (httplib + nlohmann/json)
#
# Usage:
#   export ORACLE_HOME=/opt/oracle/instantclient_21_9
#   ./scripts/build.sh            # Debug build
#   ./scripts/build.sh Release    # Release build
# =============================================================================

set -euo pipefail

BUILD_TYPE="${1:-Debug}"
BUILD_DIR="build"

echo "============================================"
echo "  Building Oracle REST API  [$BUILD_TYPE]"
echo "============================================"

# Verify ORACLE_HOME
if [[ -z "${ORACLE_HOME:-}" ]]; then
    echo "[WARN] ORACLE_HOME not set — CMake will try default path /opt/oracle/instantclient_21_9"
fi

# Create & enter build directory
mkdir -p "$BUILD_DIR"

cmake \
    -S . \
    -B "$BUILD_DIR" \
    -DCMAKE_BUILD_TYPE="$BUILD_TYPE" \
    ${ORACLE_HOME:+-DORACLE_HOME="$ORACLE_HOME"}

cmake --build "$BUILD_DIR" --parallel "$(nproc 2>/dev/null || sysctl -n hw.ncpu)"

echo ""
echo "Build successful!"
echo "Binary: ./$BUILD_DIR/OracleRestAPI"
