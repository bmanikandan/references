#!/usr/bin/env bash
# =============================================================================
# Smoke-test: Oracle REST API — covers DB, external REST, and SOAP endpoints
# Requires: curl, python3 (for JSON id extraction)
# Optional: jq  (for pretty-print)
# Usage:  ./scripts/test_api.sh [http://localhost:8080]
# =============================================================================

set -euo pipefail

BASE="${1:-http://localhost:8080}/api/v1"
JQ=$(command -v jq &>/dev/null && echo "jq ." || echo "cat")

ok()  { echo -e "\033[32m✔  $1\033[0m"; }
err() { echo -e "\033[31m✘  $1\033[0m"; exit 1; }
sep() { echo -e "\n\033[36m════════════════════════════════════════\033[0m"
        echo -e "\033[36m  $1\033[0m"
        echo -e "\033[36m════════════════════════════════════════\033[0m"; }

json_id() {
    # extract .data.id from a JSON response
    python3 -c "import sys,json; print(json.load(sys.stdin)['data']['id'])"
}

# ---------------------------------------------------------------------------
sep "Health check"
curl -sf "$BASE/health" | $JQ && ok "Health"

# ===========================================================================
sep "EMPLOYEES  (Oracle DB)"
# ---------------------------------------------------------------------------
echo "--- List all ---"
curl -sf "$BASE/employees" | $JQ && ok "List employees"

echo "--- Filter by dept ---"
curl -sf "$BASE/employees?dept=Engineering&limit=2" | $JQ && ok "List Engineering"

echo "--- Create ---"
CREATE=$(curl -sf -X POST "$BASE/employees" \
    -H "Content-Type: application/json" \
    -d '{"name":"Test User","email":"testuser@example.com","department":"QA","salary":55000}')
echo "$CREATE" | $JQ
EMP_ID=$(echo "$CREATE" | json_id)
ok "Created employee id=$EMP_ID"

echo "--- Get by id ---"
curl -sf "$BASE/employees/$EMP_ID" | $JQ && ok "Get employee $EMP_ID"

echo "--- Full update (PUT) ---"
curl -sf -X PUT "$BASE/employees/$EMP_ID" \
    -H "Content-Type: application/json" \
    -d '{"name":"Updated User","email":"testuser@example.com","department":"QA","salary":60000}' \
    | $JQ && ok "PUT employee"

echo "--- Partial update (PATCH) ---"
curl -sf -X PATCH "$BASE/employees/$EMP_ID" \
    -H "Content-Type: application/json" \
    -d '{"salary":65000}' | $JQ && ok "PATCH salary"

echo "--- Delete ---"
curl -sf -X DELETE "$BASE/employees/$EMP_ID" | $JQ && ok "Delete employee"

echo "--- Confirm 404 ---"
CODE=$(curl -s -o /dev/null -w "%{http_code}" "$BASE/employees/$EMP_ID")
[[ "$CODE" == "404" ]] && ok "Confirmed 404 after delete" || err "Expected 404, got $CODE"

# ===========================================================================
sep "EXTERNAL REST API  (proxy to JSONPlaceholder)"
# ---------------------------------------------------------------------------
echo "--- List posts (limit 3) ---"
curl -sf "$BASE/external/posts?limit=3" | $JQ && ok "List posts"

echo "--- Get post 1 ---"
curl -sf "$BASE/external/posts/1" | $JQ && ok "Get post 1"

echo "--- Create post ---"
curl -sf -X POST "$BASE/external/posts" \
    -H "Content-Type: application/json" \
    -d '{"title":"New Post","body":"Hello world","userId":1}' \
    | $JQ && ok "Create post"

echo "--- List users ---"
curl -sf "$BASE/external/users" | $JQ | head -30 && ok "List users"

echo "--- Get user 2 ---"
curl -sf "$BASE/external/users/2" | $JQ && ok "Get user 2"

# ===========================================================================
sep "SOAP: Calculator service  (www.dneonline.com)"
# ---------------------------------------------------------------------------
echo "--- Add 7 + 3 ---"
curl -sf -X POST "$BASE/soap/calculator/add" \
    -H "Content-Type: application/json" \
    -d '{"a":7,"b":3}' | $JQ && ok "SOAP Add"

echo "--- Subtract 10 - 4 ---"
curl -sf -X POST "$BASE/soap/calculator/subtract" \
    -H "Content-Type: application/json" \
    -d '{"a":10,"b":4}' | $JQ && ok "SOAP Subtract"

echo "--- Multiply 6 × 7 ---"
curl -sf -X POST "$BASE/soap/calculator/multiply" \
    -H "Content-Type: application/json" \
    -d '{"a":6,"b":7}' | $JQ && ok "SOAP Multiply"

echo "--- Divide 20 / 4 ---"
curl -sf -X POST "$BASE/soap/calculator/divide" \
    -H "Content-Type: application/json" \
    -d '{"a":20,"b":4}' | $JQ && ok "SOAP Divide"

echo "--- Divide by zero (expect 422) ---"
CODE=$(curl -s -o /dev/null -w "%{http_code}" -X POST "$BASE/soap/calculator/divide" \
    -H "Content-Type: application/json" -d '{"a":5,"b":0}')
[[ "$CODE" == "422" ]] && ok "422 for divide-by-zero" || err "Expected 422, got $CODE"

# ===========================================================================
sep "SOAP: Country info service  (webservices.oorsprong.org)"
# ---------------------------------------------------------------------------
echo "--- Country name: GB ---"
curl -sf "$BASE/soap/country/GB/name" | $JQ && ok "Country name GB"

echo "--- Currency: US ---"
curl -sf "$BASE/soap/country/US/currency" | $JQ && ok "Currency US"

echo "--- Capital: FR ---"
curl -sf "$BASE/soap/country/FR/capital" | $JQ && ok "Capital FR"

# ===========================================================================
echo ""
echo -e "\033[32m  All tests passed.\033[0m"
