# rust-oracle-api

A RESTful CRUD API built with **Rust** ([actix-web](https://actix.rs/)) and **Oracle Database**.

## Tech Stack

| Layer | Library |
|---|---|
| Web framework | [actix-web 4](https://crates.io/crates/actix-web) |
| Oracle driver | [oracle 0.5](https://crates.io/crates/oracle) |
| Connection pool | [r2d2](https://crates.io/crates/r2d2) + [r2d2-oracle](https://crates.io/crates/r2d2-oracle) |
| Serialization | [serde](https://crates.io/crates/serde) + serde\_json |
| Error handling | [thiserror](https://crates.io/crates/thiserror) |

## Prerequisites

- Rust 1.75+
- Oracle Instant Client (required by the `oracle` crate – see below)
- An accessible Oracle database (12c or later)

### Installing Oracle Instant Client

The `oracle` Rust crate links against Oracle's OCI library.

**macOS (Homebrew)**
```bash
brew install instantclient-basic
```

**Linux (RPM)**
```bash
# Download Basic & SDK packages from Oracle's website, then:
rpm -ivh oracle-instantclient*-basic*.rpm
export LD_LIBRARY_PATH=/usr/lib/oracle/21/client64/lib:$LD_LIBRARY_PATH
```

Set `OCI_LIB_DIR` if `cargo build` cannot find the library:
```bash
export OCI_LIB_DIR=/path/to/instantclient
```

## Quick Start

```bash
# 1. Clone / enter the project
cd rust-oracle-api

# 2. Configure environment
cp .env.example .env
# Edit .env with your Oracle credentials

# 3. Apply the schema
sqlplus your_user/your_password@//host:1521/service @sql/schema.sql

# 4. Build and run
cargo run
```

The server starts on `http://0.0.0.0:8080` by default.

## API Reference

Base URL: `http://localhost:8080/api`

### Health check

```
GET /health
```

### Employees

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/api/employees` | List all employees |
| `GET` | `/api/employees/{id}` | Get employee by ID |
| `POST` | `/api/employees` | Create a new employee |
| `PUT` | `/api/employees/{id}` | Update an employee |
| `DELETE` | `/api/employees/{id}` | Delete an employee |

### Request / Response Examples

**Create employee**
```bash
curl -X POST http://localhost:8080/api/employees \
  -H 'Content-Type: application/json' \
  -d '{"name":"Jane Doe","email":"jane@example.com","department":"Engineering","salary":95000}'
```

```json
{
  "success": true,
  "message": "Employee created successfully",
  "data": {
    "id": 6,
    "name": "Jane Doe",
    "email": "jane@example.com",
    "department": "Engineering",
    "salary": 95000.0,
    "hire_date": "2026-03-08"
  }
}
```

**Update employee**
```bash
curl -X PUT http://localhost:8080/api/employees/6 \
  -H 'Content-Type: application/json' \
  -d '{"salary":100000}'
```

**Delete employee**
```bash
curl -X DELETE http://localhost:8080/api/employees/6
```

## Project Structure

```
rust-oracle-api/
├── Cargo.toml
├── .env.example
├── sql/
│   └── schema.sql          # Oracle DDL + seed data
└── src/
    ├── main.rs             # Server bootstrap & route registration
    ├── db.rs               # Connection pool setup
    ├── models.rs           # Domain structs & request/response types
    ├── errors.rs           # AppError with actix-web ResponseError impl
    └── handlers/
        ├── mod.rs
        └── employees.rs    # CRUD handlers
```

## Building for Production

```bash
cargo build --release
./target/release/rust-oracle-api
```
