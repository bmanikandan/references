use actix_web::HttpResponse;
use thiserror::Error;

use crate::models::ErrorResponse;

#[derive(Debug, Error)]
pub enum AppError {
    #[error("Database error: {0}")]
    Database(#[from] oracle::Error),

    #[error("Connection pool error: {0}")]
    Pool(#[from] r2d2::Error),

    #[error("Not found: {0}")]
    NotFound(String),

    #[error("Bad request: {0}")]
    BadRequest(String),

    #[error("Internal server error")]
    Internal,

    #[error("Thread blocking error")]
    Blocking,
}

impl actix_web::ResponseError for AppError {
    fn error_response(&self) -> HttpResponse {
        let body = serde_json::to_value(ErrorResponse::new(self.to_string()))
            .unwrap_or_default();

        match self {
            AppError::NotFound(_) => HttpResponse::NotFound().json(body),
            AppError::BadRequest(_) => HttpResponse::BadRequest().json(body),
            _ => HttpResponse::InternalServerError().json(body),
        }
    }
}
