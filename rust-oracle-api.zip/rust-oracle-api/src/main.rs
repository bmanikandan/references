use actix_web::{middleware, web, App, HttpServer};
use dotenv::dotenv;
use std::env;

mod db;
mod errors;
mod handlers;
mod models;

#[actix_web::main]
async fn main() -> std::io::Result<()> {
    // Load .env file if present
    dotenv().ok();

    // Initialise logger (set RUST_LOG=info or debug)
    env_logger::init_from_env(env_logger::Env::default().default_filter_or("info"));

    // -----------------------------------------------------------------------
    // Read configuration from environment
    // -----------------------------------------------------------------------
    let db_user = env::var("ORACLE_USER").expect("ORACLE_USER must be set");
    let db_password = env::var("ORACLE_PASSWORD").expect("ORACLE_PASSWORD must be set");
    let db_conn_string =
        env::var("ORACLE_CONNECTION_STRING").expect("ORACLE_CONNECTION_STRING must be set");
    let server_host = env::var("SERVER_HOST").unwrap_or_else(|_| "0.0.0.0".to_string());
    let server_port: u16 = env::var("SERVER_PORT")
        .unwrap_or_else(|_| "8080".to_string())
        .parse()
        .expect("SERVER_PORT must be a valid port number");

    // -----------------------------------------------------------------------
    // Create Oracle connection pool
    // -----------------------------------------------------------------------
    log::info!("Connecting to Oracle database…");
    let pool = db::create_pool(&db_user, &db_password, &db_conn_string)
        .expect("Failed to create Oracle connection pool");
    let pool_data = web::Data::new(pool);

    log::info!("Starting server at http://{}:{}", server_host, server_port);

    // -----------------------------------------------------------------------
    // Build and run HTTP server
    // -----------------------------------------------------------------------
    HttpServer::new(move || {
        App::new()
            // Share the pool across all workers
            .app_data(pool_data.clone())
            // Return a helpful JSON body when JSON parsing fails
            .app_data(
                web::JsonConfig::default()
                    .error_handler(|err, _req| {
                        let response = actix_web::HttpResponse::BadRequest().json(
                            serde_json::json!({ "success": false, "message": err.to_string() }),
                        );
                        actix_web::error::InternalError::from_response(err, response).into()
                    }),
            )
            // Request/response logging
            .wrap(middleware::Logger::default())
            // ---------------------------------------------------------------
            // Routes
            // ---------------------------------------------------------------
            .service(
                web::scope("/api").service(
                    web::scope("/employees")
                        // GET  /api/employees
                        .route("", web::get().to(handlers::employees::get_all))
                        // POST /api/employees
                        .route("", web::post().to(handlers::employees::create))
                        // GET  /api/employees/{id}
                        .route("/{id}", web::get().to(handlers::employees::get_by_id))
                        // PUT  /api/employees/{id}
                        .route("/{id}", web::put().to(handlers::employees::update))
                        // DELETE /api/employees/{id}
                        .route("/{id}", web::delete().to(handlers::employees::delete)),
                ),
            )
            // Health-check endpoint
            .route(
                "/health",
                web::get().to(|| async {
                    actix_web::HttpResponse::Ok()
                        .json(serde_json::json!({ "status": "ok" }))
                }),
            )
    })
    .bind((server_host.as_str(), server_port))?
    .run()
    .await
}
