use r2d2::Pool;
use r2d2_oracle::OracleConnectionManager;

/// Type alias for the Oracle connection pool
pub type DbPool = Pool<OracleConnectionManager>;

/// Creates and returns a connection pool for Oracle database.
///
/// # Arguments
/// * `username` - Oracle DB username
/// * `password` - Oracle DB password
/// * `connect_string` - Oracle connection string (e.g. `//host:1521/service_name`)
///
/// # Errors
/// Returns `r2d2::Error` if the pool cannot be initialized.
pub fn create_pool(username: &str, password: &str, connect_string: &str) -> Result<DbPool, r2d2::Error> {
    let manager = OracleConnectionManager::new(username, password, connect_string);
    Pool::builder()
        .max_size(15)
        .min_idle(Some(2))
        .build(manager)
}
