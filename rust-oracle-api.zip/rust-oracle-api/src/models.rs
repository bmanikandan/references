use serde::{Deserialize, Serialize};

// ---------------------------------------------------------------------------
// Domain model
// ---------------------------------------------------------------------------

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct Employee {
    pub id: i64,
    pub name: String,
    pub email: String,
    pub department: Option<String>,
    pub salary: Option<f64>,
    /// ISO date string (YYYY-MM-DD) returned from Oracle
    pub hire_date: Option<String>,
}

// ---------------------------------------------------------------------------
// Request payloads
// ---------------------------------------------------------------------------

#[derive(Debug, Serialize, Deserialize)]
pub struct CreateEmployee {
    pub name: String,
    pub email: String,
    pub department: Option<String>,
    pub salary: Option<f64>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct UpdateEmployee {
    pub name: Option<String>,
    pub email: Option<String>,
    pub department: Option<String>,
    pub salary: Option<f64>,
}

// ---------------------------------------------------------------------------
// API response wrappers
// ---------------------------------------------------------------------------

#[derive(Debug, Serialize)]
pub struct ApiResponse<T: Serialize> {
    pub success: bool,
    pub message: String,
    pub data: Option<T>,
}

impl<T: Serialize> ApiResponse<T> {
    pub fn ok(data: T, message: impl Into<String>) -> Self {
        ApiResponse {
            success: true,
            message: message.into(),
            data: Some(data),
        }
    }
}

#[derive(Debug, Serialize)]
pub struct ErrorResponse {
    pub success: bool,
    pub message: String,
}

impl ErrorResponse {
    pub fn new(message: impl Into<String>) -> Self {
        ErrorResponse {
            success: false,
            message: message.into(),
        }
    }
}
