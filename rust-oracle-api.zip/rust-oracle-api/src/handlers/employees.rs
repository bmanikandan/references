use actix_web::{web, HttpResponse};

use crate::db::DbPool;
use crate::errors::AppError;
use crate::models::{ApiResponse, CreateEmployee, Employee, UpdateEmployee};

// ---------------------------------------------------------------------------
// Helper: map a Row into an Employee struct
// ---------------------------------------------------------------------------

fn row_to_employee(row: &oracle::Row) -> Result<Employee, oracle::Error> {
    Ok(Employee {
        id: row.get(0)?,
        name: row.get(1)?,
        email: row.get(2)?,
        department: row.get(3)?,
        salary: row.get(4)?,
        hire_date: row.get(5)?,
    })
}

// ---------------------------------------------------------------------------
// GET /api/employees  — list all
// ---------------------------------------------------------------------------

pub async fn get_all(pool: web::Data<DbPool>) -> Result<HttpResponse, AppError> {
    let pool = pool.into_inner();

    let employees = web::block(move || -> Result<Vec<Employee>, AppError> {
        let conn = pool.get()?;

        let rows = conn.query(
            "SELECT id, name, email, department, salary, \
             TO_CHAR(hire_date, 'YYYY-MM-DD') AS hire_date \
             FROM employees \
             ORDER BY id",
            &[],
        )?;

        let mut result = Vec::new();
        for row_res in rows {
            let row = row_res?;
            result.push(row_to_employee(&row)?);
        }
        Ok(result)
    })
    .await
    .map_err(|_| AppError::Blocking)??;

    Ok(HttpResponse::Ok().json(ApiResponse::ok(employees, "Employees retrieved successfully")))
}

// ---------------------------------------------------------------------------
// GET /api/employees/{id}  — get by primary key
// ---------------------------------------------------------------------------

pub async fn get_by_id(
    pool: web::Data<DbPool>,
    path: web::Path<i64>,
) -> Result<HttpResponse, AppError> {
    let id = path.into_inner();
    let pool = pool.into_inner();

    let employee = web::block(move || -> Result<Employee, AppError> {
        let conn = pool.get()?;

        let rows = conn.query(
            "SELECT id, name, email, department, salary, \
             TO_CHAR(hire_date, 'YYYY-MM-DD') AS hire_date \
             FROM employees \
             WHERE id = :1",
            &[&id],
        )?;

        let mut iter = rows.into_iter();
        match iter.next() {
            Some(row_res) => Ok(row_to_employee(&row_res?)?),
            None => Err(AppError::NotFound(format!("Employee with id {} not found", id))),
        }
    })
    .await
    .map_err(|_| AppError::Blocking)??;

    Ok(HttpResponse::Ok().json(ApiResponse::ok(employee, "Employee retrieved successfully")))
}

// ---------------------------------------------------------------------------
// POST /api/employees  — create
// ---------------------------------------------------------------------------

pub async fn create(
    pool: web::Data<DbPool>,
    body: web::Json<CreateEmployee>,
) -> Result<HttpResponse, AppError> {
    let payload = body.into_inner();
    let pool = pool.into_inner();

    // Validate required fields
    if payload.name.trim().is_empty() {
        return Err(AppError::BadRequest("name is required".into()));
    }
    if payload.email.trim().is_empty() {
        return Err(AppError::BadRequest("email is required".into()));
    }

    let employee = web::block(move || -> Result<Employee, AppError> {
        let conn = pool.get()?;

        // Fetch the next sequence value so we know the new ID before INSERT
        let seq_rows = conn.query("SELECT employees_seq.NEXTVAL FROM DUAL", &[])?;
        let seq_row = seq_rows
            .into_iter()
            .next()
            .ok_or_else(|| AppError::Internal)??;
        let new_id: i64 = seq_row.get(0)?;

        conn.execute(
            "INSERT INTO employees (id, name, email, department, salary) \
             VALUES (:1, :2, :3, :4, :5)",
            &[
                &new_id,
                &payload.name,
                &payload.email,
                &payload.department,
                &payload.salary,
            ],
        )?;
        conn.commit()?;

        // Fetch the newly created record
        let rows = conn.query(
            "SELECT id, name, email, department, salary, \
             TO_CHAR(hire_date, 'YYYY-MM-DD') AS hire_date \
             FROM employees WHERE id = :1",
            &[&new_id],
        )?;

        let mut iter = rows.into_iter();
        match iter.next() {
            Some(row_res) => Ok(row_to_employee(&row_res?)?),
            None => Err(AppError::Internal),
        }
    })
    .await
    .map_err(|_| AppError::Blocking)??;

    Ok(HttpResponse::Created().json(ApiResponse::ok(employee, "Employee created successfully")))
}

// ---------------------------------------------------------------------------
// PUT /api/employees/{id}  — full / partial update
// ---------------------------------------------------------------------------

pub async fn update(
    pool: web::Data<DbPool>,
    path: web::Path<i64>,
    body: web::Json<UpdateEmployee>,
) -> Result<HttpResponse, AppError> {
    let id = path.into_inner();
    let payload = body.into_inner();
    let pool = pool.into_inner();

    let employee = web::block(move || -> Result<Employee, AppError> {
        let conn = pool.get()?;

        // Build SET clause dynamically based on provided fields
        let mut set_parts: Vec<String> = Vec::new();
        let mut params: Vec<Box<dyn oracle::sql_type::ToSql>> = Vec::new();
        let mut bind_idx = 1usize;

        if let Some(ref name) = payload.name {
            set_parts.push(format!("name = :{}", bind_idx));
            params.push(Box::new(name.clone()));
            bind_idx += 1;
        }
        if let Some(ref email) = payload.email {
            set_parts.push(format!("email = :{}", bind_idx));
            params.push(Box::new(email.clone()));
            bind_idx += 1;
        }
        if let Some(ref dept) = payload.department {
            set_parts.push(format!("department = :{}", bind_idx));
            params.push(Box::new(dept.clone()));
            bind_idx += 1;
        }
        if let Some(salary) = payload.salary {
            set_parts.push(format!("salary = :{}", bind_idx));
            params.push(Box::new(salary));
            bind_idx += 1;
        }

        if set_parts.is_empty() {
            return Err(AppError::BadRequest(
                "At least one field must be provided for update".into(),
            ));
        }

        // Append the WHERE id bind placeholder
        let set_clause = set_parts.join(", ");
        let sql = format!("UPDATE employees SET {} WHERE id = :{}", set_clause, bind_idx);
        params.push(Box::new(id));

        // Build a slice of `&dyn ToSql` from the boxed params
        let param_refs: Vec<&dyn oracle::sql_type::ToSql> =
            params.iter().map(|p| p.as_ref()).collect();

        let rows_affected = conn.execute(&sql, param_refs.as_slice())?;
        if rows_affected == 0 {
            return Err(AppError::NotFound(format!(
                "Employee with id {} not found",
                id
            )));
        }
        conn.commit()?;

        // Return updated record
        let rows = conn.query(
            "SELECT id, name, email, department, salary, \
             TO_CHAR(hire_date, 'YYYY-MM-DD') AS hire_date \
             FROM employees WHERE id = :1",
            &[&id],
        )?;

        let mut iter = rows.into_iter();
        match iter.next() {
            Some(row_res) => Ok(row_to_employee(&row_res?)?),
            None => Err(AppError::Internal),
        }
    })
    .await
    .map_err(|_| AppError::Blocking)??;

    Ok(HttpResponse::Ok().json(ApiResponse::ok(employee, "Employee updated successfully")))
}

// ---------------------------------------------------------------------------
// DELETE /api/employees/{id}
// ---------------------------------------------------------------------------

pub async fn delete(
    pool: web::Data<DbPool>,
    path: web::Path<i64>,
) -> Result<HttpResponse, AppError> {
    let id = path.into_inner();
    let pool = pool.into_inner();

    web::block(move || -> Result<(), AppError> {
        let conn = pool.get()?;

        let rows_affected = conn.execute("DELETE FROM employees WHERE id = :1", &[&id])?;
        if rows_affected == 0 {
            return Err(AppError::NotFound(format!(
                "Employee with id {} not found",
                id
            )));
        }
        conn.commit()?;
        Ok(())
    })
    .await
    .map_err(|_| AppError::Blocking)??;

    Ok(HttpResponse::Ok().json(serde_json::json!({
        "success": true,
        "message": format!("Employee {} deleted successfully", id)
    })))
}
