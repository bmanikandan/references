-- =============================================================================
-- Oracle schema for rust-oracle-api
-- Compatible with Oracle 12c+ (uses DEFAULT ON NULL sequence syntax)
-- =============================================================================

-- Drop objects if they already exist (safe re-run)
BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE employees CASCADE CONSTRAINTS';
EXCEPTION
    WHEN OTHERS THEN NULL;
END;
/

BEGIN
    EXECUTE IMMEDIATE 'DROP SEQUENCE employees_seq';
EXCEPTION
    WHEN OTHERS THEN NULL;
END;
/

-- =============================================================================
-- Sequence: used for generating primary key values
-- =============================================================================
CREATE SEQUENCE employees_seq
    START WITH 1
    INCREMENT BY 1
    NOCACHE
    NOCYCLE;

-- =============================================================================
-- Table: employees
-- =============================================================================
CREATE TABLE employees (
    id          NUMBER          DEFAULT employees_seq.NEXTVAL PRIMARY KEY,
    name        VARCHAR2(100)   NOT NULL,
    email       VARCHAR2(150)   UNIQUE NOT NULL,
    department  VARCHAR2(100),
    salary      NUMBER(12, 2),
    hire_date   DATE            DEFAULT SYSDATE NOT NULL,

    CONSTRAINT chk_salary CHECK (salary IS NULL OR salary >= 0)
);

-- Index on email for fast lookup / uniqueness checks
CREATE UNIQUE INDEX idx_employees_email ON employees (email);

-- =============================================================================
-- Seed data (optional)
-- =============================================================================
INSERT INTO employees (name, email, department, salary)
VALUES ('Alice Johnson', 'alice@example.com', 'Engineering', 95000.00);

INSERT INTO employees (name, email, department, salary)
VALUES ('Bob Smith', 'bob@example.com', 'Marketing', 72000.00);

INSERT INTO employees (name, email, department, salary)
VALUES ('Carol White', 'carol@example.com', 'Engineering', 110000.00);

INSERT INTO employees (name, email, department, salary)
VALUES ('David Brown', 'david@example.com', 'HR', 65000.00);

INSERT INTO employees (name, email, department, salary)
VALUES ('Eve Davis', 'eve@example.com', 'Finance', 88000.00);

COMMIT;

-- Verify
SELECT id, name, email, department, salary,
       TO_CHAR(hire_date, 'YYYY-MM-DD') AS hire_date
FROM   employees
ORDER  BY id;
