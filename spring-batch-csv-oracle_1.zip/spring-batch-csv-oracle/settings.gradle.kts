rootProject.name = "spring-batch-csv-oracle"
