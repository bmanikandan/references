/**
 * Utility functions for Playwright automation
 */

/**
 * Wait for a specific amount of time (use sparingly)
 * @param {number} ms - Milliseconds to wait
 * @returns {Promise<void>}
 */
async function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Take a screenshot with timestamp
 * @param {import('@playwright/test').Page} page 
 * @param {string} name - Base name for the screenshot
 * @returns {Promise<string>} - Path to the screenshot
 */
async function takeTimestampedScreenshot(page, name) {
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const path = `screenshots/${name}-${timestamp}.png`;
  await page.screenshot({ path, fullPage: true });
  return path;
}

/**
 * Scroll element into view
 * @param {import('@playwright/test').Page} page 
 * @param {string} selector 
 */
async function scrollIntoView(page, selector) {
  await page.evaluate((sel) => {
    document.querySelector(sel)?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }, selector);
}

/**
 * Wait for network to be idle
 * @param {import('@playwright/test').Page} page 
 * @param {number} timeout 
 */
async function waitForNetworkIdle(page, timeout = 5000) {
  await page.waitForLoadState('networkidle', { timeout });
}

/**
 * Get all cookies from the page
 * @param {import('@playwright/test').BrowserContext} context 
 * @returns {Promise<Array>}
 */
async function getAllCookies(context) {
  return await context.cookies();
}

/**
 * Set cookies on the context
 * @param {import('@playwright/test').BrowserContext} context 
 * @param {Array} cookies 
 */
async function setCookies(context, cookies) {
  await context.addCookies(cookies);
}

/**
 * Clear all cookies
 * @param {import('@playwright/test').BrowserContext} context 
 */
async function clearCookies(context) {
  await context.clearCookies();
}

/**
 * Download a file and return the path
 * @param {import('@playwright/test').Page} page 
 * @param {string} clickSelector - Selector to click to trigger download
 * @returns {Promise<string>} - Path to downloaded file
 */
async function downloadFile(page, clickSelector) {
  const [download] = await Promise.all([
    page.waitForEvent('download'),
    page.click(clickSelector),
  ]);
  const path = await download.path();
  return path;
}

/**
 * Handle alert/confirm/prompt dialogs
 * @param {import('@playwright/test').Page} page 
 * @param {string} action - 'accept' or 'dismiss'
 * @param {string} [promptText] - Text to enter for prompt dialogs
 */
function setupDialogHandler(page, action = 'accept', promptText = '') {
  page.on('dialog', async dialog => {
    if (action === 'accept') {
      await dialog.accept(promptText);
    } else {
      await dialog.dismiss();
    }
  });
}

/**
 * Retry an action with exponential backoff
 * @param {Function} action - Async function to retry
 * @param {number} maxRetries - Maximum number of retries
 * @param {number} baseDelay - Base delay in ms
 * @returns {Promise<any>}
 */
async function retryWithBackoff(action, maxRetries = 3, baseDelay = 1000) {
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      return await action();
    } catch (error) {
      if (attempt === maxRetries - 1) throw error;
      const delay = baseDelay * Math.pow(2, attempt);
      await sleep(delay);
    }
  }
}

/**
 * Extract all links from a page
 * @param {import('@playwright/test').Page} page 
 * @returns {Promise<Array<{href: string, text: string}>>}
 */
async function extractAllLinks(page) {
  return await page.$$eval('a[href]', links => {
    return links.map(link => ({
      href: link.href,
      text: link.textContent?.trim() || '',
    }));
  });
}

/**
 * Check if element is visible
 * @param {import('@playwright/test').Page} page 
 * @param {string} selector 
 * @returns {Promise<boolean>}
 */
async function isVisible(page, selector) {
  try {
    await page.waitForSelector(selector, { state: 'visible', timeout: 3000 });
    return true;
  } catch {
    return false;
  }
}

module.exports = {
  sleep,
  takeTimestampedScreenshot,
  scrollIntoView,
  waitForNetworkIdle,
  getAllCookies,
  setCookies,
  clearCookies,
  downloadFile,
  setupDialogHandler,
  retryWithBackoff,
  extractAllLinks,
  isVisible,
};
