# Playwright Automation Demo Project

A comprehensive Node.js project demonstrating Playwright's capabilities for web automation and testing.

## 📁 Project Structure

```
playwright-demo/
├── playwright.config.js    # Playwright configuration
├── package.json
├── pages/                  # Page Object Models
│   ├── LoginPage.js
│   └── TablesPage.js
├── utils/                  # Helper utilities
│   └── helpers.js
└── tests/                  # Test files
    ├── login.spec.js       # Login functionality tests
    ├── tables.spec.js      # Data table tests
    ├── advanced.spec.js    # Advanced scenarios
    ├── api.spec.js         # API testing
    ├── visual.spec.js      # Visual/accessibility tests
    └── auth.spec.js        # Authentication patterns
```

## 🚀 Getting Started

### Installation

```bash
# Install dependencies
npm install

# Install browser binaries
npx playwright install
```

### Running Tests

```bash
# Run all tests
npx playwright test

# Run specific test file
npx playwright test tests/login.spec.js

# Run tests in headed mode (see browser)
npx playwright test --headed

# Run tests in specific browser
npx playwright test --project=chromium
npx playwright test --project=firefox
npx playwright test --project=webkit

# Run tests with UI mode (interactive)
npx playwright test --ui

# Debug mode
npx playwright test --debug
```

### Viewing Reports

```bash
# Open HTML report
npx playwright show-report
```

## 📚 Features Covered

### 1. Page Object Model (POM)
- `pages/LoginPage.js` - Encapsulated login page interactions
- `pages/TablesPage.js` - Table data extraction methods

### 2. Test Types

| File | Description |
|------|-------------|
| `login.spec.js` | Form submission, validation, edge cases |
| `tables.spec.js` | Data extraction, sorting, cell access |
| `advanced.spec.js` | Iframes, dialogs, uploads, drag-drop |
| `api.spec.js` | REST API testing without browser |
| `visual.spec.js` | Screenshots, accessibility, performance |
| `auth.spec.js` | Session handling, multi-user scenarios |

### 3. Advanced Scenarios

#### Iframes
```javascript
const frame = page.frameLocator('#my-iframe');
await frame.locator('button').click();
```

#### File Upload
```javascript
await page.setInputFiles('#upload', 'path/to/file.txt');
```

#### File Download
```javascript
const [download] = await Promise.all([
  page.waitForEvent('download'),
  page.click('a.download-link'),
]);
await download.saveAs('/path/to/save');
```

#### JavaScript Dialogs
```javascript
page.on('dialog', async dialog => {
  await dialog.accept('input text');
});
```

#### Network Interception
```javascript
await page.route('**/api/**', route => {
  route.fulfill({ body: JSON.stringify({ mocked: true }) });
});
```

### 4. API Testing
```javascript
const response = await request.get('https://api.example.com/data');
expect(response.ok()).toBeTruthy();
const data = await response.json();
```

### 5. Authentication Patterns

- **UI Login**: Traditional form-based login
- **Cookie Injection**: Set auth cookies directly
- **Basic Auth**: HTTP credentials
- **Token-Based**: JWT in headers
- **Session Sharing**: Reuse auth state across tests

## ⚙️ Configuration Highlights

### Multi-Browser Testing
```javascript
projects: [
  { name: 'chromium', use: { ...devices['Desktop Chrome'] } },
  { name: 'firefox', use: { ...devices['Desktop Firefox'] } },
  { name: 'webkit', use: { ...devices['Desktop Safari'] } },
  { name: 'mobile-chrome', use: { ...devices['Pixel 5'] } },
]
```

### Retry & Reporting
```javascript
retries: 2,
reporter: [['html'], ['list']],
```

### Artifacts on Failure
```javascript
screenshot: 'only-on-failure',
video: 'retain-on-failure',
trace: 'on-first-retry',
```

## 🛠️ Utility Functions

Located in `utils/helpers.js`:

| Function | Purpose |
|----------|---------|
| `takeTimestampedScreenshot()` | Screenshots with timestamps |
| `scrollIntoView()` | Scroll element into viewport |
| `waitForNetworkIdle()` | Wait for network to settle |
| `downloadFile()` | Handle file downloads |
| `setupDialogHandler()` | Handle JS dialogs |
| `retryWithBackoff()` | Retry with exponential backoff |
| `extractAllLinks()` | Get all links from page |
| `isVisible()` | Check element visibility |

## 📊 Best Practices

1. **Use Page Objects** - Encapsulate page interactions
2. **Avoid Hard Waits** - Use Playwright's auto-waiting
3. **Isolate Tests** - Each test should be independent
4. **Use Descriptive Names** - Clear test and variable names
5. **Handle Flakiness** - Use retries and proper waits
6. **Mock External APIs** - Use route interception for isolation
7. **Leverage Fixtures** - Share setup across tests
8. **Save Auth State** - Avoid repeated logins

## 🔗 Resources

- [Playwright Documentation](https://playwright.dev/docs/intro)
- [API Reference](https://playwright.dev/docs/api/class-playwright)
- [Best Practices](https://playwright.dev/docs/best-practices)
- [Test Generator](https://playwright.dev/docs/codegen)
