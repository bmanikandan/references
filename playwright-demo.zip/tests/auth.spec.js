const { test, expect } = require('@playwright/test');
const fs = require('fs');
const path = require('path');

const AUTH_FILE = 'playwright/.auth/user.json';

/**
 * Authentication Setup
 * This file demonstrates how to handle authentication state
 * and share it across tests for efficiency
 */

// Setup: Run once to create auth state
test.describe('Authentication Setup', () => {
  test('should save authentication state', async ({ page, context }) => {
    // Navigate to login
    await page.goto('/login');
    
    // Perform login
    await page.fill('#username', 'tomsmith');
    await page.fill('#password', 'SuperSecretPassword!');
    await page.click('button[type="submit"]');
    
    // Wait for successful login
    await expect(page.locator('.flash.success')).toBeVisible();
    
    // Ensure auth directory exists
    const authDir = path.dirname(AUTH_FILE);
    if (!fs.existsSync(authDir)) {
      fs.mkdirSync(authDir, { recursive: true });
    }
    
    // Save storage state (cookies, localStorage)
    await context.storageState({ path: AUTH_FILE });
    
    console.log('Authentication state saved to:', AUTH_FILE);
  });
});

// Tests that use saved authentication state
test.describe('Authenticated Tests', () => {
  // Use saved auth state if it exists
  test.use({
    storageState: fs.existsSync(AUTH_FILE) ? AUTH_FILE : undefined,
  });

  test('should access secure page with saved auth', async ({ page }) => {
    // Go directly to secure page
    await page.goto('/secure');
    
    // Should be on secure page, not redirected to login
    await expect(page).toHaveURL(/\/secure/);
    await expect(page.locator('h2')).toContainText('Secure Area');
  });
});

/**
 * Different authentication strategies
 */
test.describe('Authentication Strategies', () => {
  test('should login via UI', async ({ page }) => {
    await page.goto('/login');
    
    await page.fill('#username', 'tomsmith');
    await page.fill('#password', 'SuperSecretPassword!');
    await page.click('button[type="submit"]');
    
    await expect(page.locator('.flash.success')).toBeVisible();
  });

  test('should set auth cookies directly', async ({ page, context }) => {
    // This is useful when you know the cookie format
    // and want to skip the login UI
    
    // Example: Set cookies before navigation
    await context.addCookies([
      {
        name: 'session_id',
        value: 'fake-session-value',
        domain: 'the-internet.herokuapp.com',
        path: '/',
      },
    ]);
    
    // Now navigate - would be authenticated if cookies were valid
    await page.goto('/');
  });

  test('should handle Basic Auth', async ({ page, context }) => {
    // For Basic Auth protected pages
    // Create context with credentials
    const authContext = await context.browser().newContext({
      httpCredentials: {
        username: 'admin',
        password: 'admin',
      },
    });
    
    const authPage = await authContext.newPage();
    
    // Navigate to Basic Auth protected page
    await authPage.goto('/basic_auth');
    
    // Should see success message (Basic Auth accepted)
    await expect(authPage.locator('p')).toContainText('Congratulations');
    
    await authContext.close();
  });

  test('should handle HTTP credentials inline', async ({ browser }) => {
    // Alternative: Embed credentials in URL
    const context = await browser.newContext();
    const page = await context.newPage();
    
    // Navigate with credentials in URL
    await page.goto('https://admin:admin@the-internet.herokuapp.com/basic_auth');
    
    await expect(page.locator('p')).toContainText('Congratulations');
    
    await context.close();
  });
});

/**
 * Session management patterns
 */
test.describe('Session Management', () => {
  test('should maintain session across pages', async ({ page }) => {
    // Login
    await page.goto('/login');
    await page.fill('#username', 'tomsmith');
    await page.fill('#password', 'SuperSecretPassword!');
    await page.click('button[type="submit"]');
    
    // Navigate to different pages
    await page.goto('/');
    await page.goto('/secure');
    
    // Should still be authenticated
    await expect(page).toHaveURL(/\/secure/);
  });

  test('should clear session on logout', async ({ page, context }) => {
    // Login first
    await page.goto('/login');
    await page.fill('#username', 'tomsmith');
    await page.fill('#password', 'SuperSecretPassword!');
    await page.click('button[type="submit"]');
    
    // Get cookies before logout
    const cookiesBefore = await context.cookies();
    console.log('Cookies before logout:', cookiesBefore.length);
    
    // Logout
    await page.click('a[href="/logout"]');
    
    // Try to access secure page
    await page.goto('/secure');
    
    // Should be redirected to login
    await expect(page).toHaveURL(/\/login/);
  });

  test('should handle session timeout', async ({ page }) => {
    // Login
    await page.goto('/login');
    await page.fill('#username', 'tomsmith');
    await page.fill('#password', 'SuperSecretPassword!');
    await page.click('button[type="submit"]');
    
    // Simulate session timeout by clearing cookies
    const context = page.context();
    await context.clearCookies();
    
    // Try to access secure page
    await page.goto('/secure');
    
    // Should be redirected to login
    await expect(page).toHaveURL(/\/login/);
  });
});

/**
 * Multi-user scenarios
 */
test.describe('Multi-User Testing', () => {
  test('should handle multiple users in same test', async ({ browser }) => {
    // Create two separate contexts (like two incognito windows)
    const userAContext = await browser.newContext();
    const userBContext = await browser.newContext();
    
    const userAPage = await userAContext.newPage();
    const userBPage = await userBContext.newPage();
    
    // User A logs in
    await userAPage.goto('https://the-internet.herokuapp.com/login');
    await userAPage.fill('#username', 'tomsmith');
    await userAPage.fill('#password', 'SuperSecretPassword!');
    await userAPage.click('button[type="submit"]');
    
    // User B stays on login page
    await userBPage.goto('https://the-internet.herokuapp.com/login');
    
    // Verify User A is logged in
    await expect(userAPage.locator('.flash.success')).toBeVisible();
    
    // Verify User B is not logged in (still sees login form)
    await expect(userBPage.locator('#username')).toBeVisible();
    
    // Clean up
    await userAContext.close();
    await userBContext.close();
  });
});

/**
 * Token-based authentication (conceptual example)
 */
test.describe('Token-Based Auth', () => {
  test('should set authorization header for API calls', async ({ page }) => {
    const token = 'your-jwt-token-here';
    
    // Intercept requests and add auth header
    await page.route('**/*', route => {
      route.continue({
        headers: {
          ...route.request().headers(),
          'Authorization': `Bearer ${token}`,
        },
      });
    });
    
    // Now all requests will include the auth header
    await page.goto('/');
  });

  test('should store token in localStorage', async ({ page }) => {
    await page.goto('/');
    
    // Simulate storing a token
    await page.evaluate(() => {
      localStorage.setItem('authToken', 'fake-jwt-token');
    });
    
    // Verify token is stored
    const token = await page.evaluate(() => localStorage.getItem('authToken'));
    expect(token).toBe('fake-jwt-token');
  });
});
