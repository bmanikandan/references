const { test, expect } = require('@playwright/test');

/**
 * Visual Testing with Playwright
 * Screenshot comparison and visual regression testing
 */
test.describe('Visual Testing', () => {
  test('should match screenshot of login page', async ({ page }) => {
    await page.goto('/login');
    
    // Take a full page screenshot and compare to baseline
    await expect(page).toHaveScreenshot('login-page.png', {
      maxDiffPixels: 100, // Allow small differences
    });
  });

  test('should match screenshot of specific element', async ({ page }) => {
    await page.goto('/login');
    
    // Screenshot of just the login form
    const form = page.locator('form');
    await expect(form).toHaveScreenshot('login-form.png');
  });

  test('should match screenshot with mask', async ({ page }) => {
    await page.goto('/dynamic_content');
    
    // Mask dynamic elements that change between runs
    await expect(page).toHaveScreenshot('dynamic-masked.png', {
      mask: [page.locator('.large-2.columns img')],
    });
  });

  test('should compare screenshots at different viewports', async ({ page }) => {
    await page.goto('/login');
    
    // Desktop viewport
    await page.setViewportSize({ width: 1280, height: 720 });
    await expect(page).toHaveScreenshot('login-desktop.png');
    
    // Tablet viewport
    await page.setViewportSize({ width: 768, height: 1024 });
    await expect(page).toHaveScreenshot('login-tablet.png');
    
    // Mobile viewport
    await page.setViewportSize({ width: 375, height: 667 });
    await expect(page).toHaveScreenshot('login-mobile.png');
  });
});

test.describe('Accessibility Testing', () => {
  test('should have proper page structure', async ({ page }) => {
    await page.goto('/login');
    
    // Check for main heading
    const h2 = page.locator('h2');
    await expect(h2).toBeVisible();
    
    // Check form labels
    const labels = page.locator('label');
    expect(await labels.count()).toBeGreaterThan(0);
  });

  test('should have accessible form inputs', async ({ page }) => {
    await page.goto('/login');
    
    // Check username input has associated label
    const usernameInput = page.locator('#username');
    await expect(usernameInput).toHaveAttribute('name', 'username');
    
    // Check password input
    const passwordInput = page.locator('#password');
    await expect(passwordInput).toHaveAttribute('type', 'password');
  });

  test('should be keyboard navigable', async ({ page }) => {
    await page.goto('/login');
    
    // Tab through form elements
    await page.keyboard.press('Tab');
    
    // Check if username field is focused
    const focusedElement = page.locator(':focus');
    await expect(focusedElement).toHaveAttribute('id', 'username');
    
    // Tab to password
    await page.keyboard.press('Tab');
    await expect(page.locator(':focus')).toHaveAttribute('id', 'password');
    
    // Tab to submit button
    await page.keyboard.press('Tab');
    await expect(page.locator(':focus')).toHaveAttribute('type', 'submit');
  });

  test('should have sufficient color contrast', async ({ page }) => {
    await page.goto('/login');
    
    // Get button color
    const button = page.locator('button[type="submit"]');
    const backgroundColor = await button.evaluate(el => {
      return window.getComputedStyle(el).backgroundColor;
    });
    
    // Basic check that button has a background color
    expect(backgroundColor).toBeTruthy();
    expect(backgroundColor).not.toBe('transparent');
  });
});

test.describe('Performance Monitoring', () => {
  test('should measure page load time', async ({ page }) => {
    const startTime = Date.now();
    
    await page.goto('/');
    await page.waitForLoadState('domcontentloaded');
    
    const domContentLoaded = Date.now() - startTime;
    console.log(`DOM Content Loaded: ${domContentLoaded}ms`);
    
    await page.waitForLoadState('load');
    const fullLoad = Date.now() - startTime;
    console.log(`Full Load: ${fullLoad}ms`);
    
    // Assert reasonable load times
    expect(fullLoad).toBeLessThan(10000); // Should load within 10 seconds
  });

  test('should capture performance metrics', async ({ page }) => {
    await page.goto('/');
    
    // Get performance timing data
    const performanceTiming = await page.evaluate(() => {
      const timing = performance.timing;
      return {
        dnsLookup: timing.domainLookupEnd - timing.domainLookupStart,
        tcpConnect: timing.connectEnd - timing.connectStart,
        serverResponse: timing.responseStart - timing.requestStart,
        domParsing: timing.domContentLoadedEventEnd - timing.responseEnd,
        pageLoad: timing.loadEventEnd - timing.navigationStart,
      };
    });

    console.log('Performance Metrics:', performanceTiming);
    
    // Assert on performance
    expect(performanceTiming.pageLoad).toBeGreaterThan(0);
  });

  test('should measure time to interactive elements', async ({ page }) => {
    const startTime = Date.now();
    
    await page.goto('/login');
    
    // Wait for interactive element
    await page.waitForSelector('#username', { state: 'visible' });
    
    const timeToInteractive = Date.now() - startTime;
    console.log(`Time to Interactive: ${timeToInteractive}ms`);
    
    expect(timeToInteractive).toBeLessThan(5000);
  });

  test('should track network requests', async ({ page }) => {
    const requests = [];
    
    page.on('request', request => {
      requests.push({
        url: request.url(),
        method: request.method(),
        resourceType: request.resourceType(),
      });
    });

    await page.goto('/');
    
    // Analyze requests
    console.log(`Total requests: ${requests.length}`);
    
    const jsRequests = requests.filter(r => r.resourceType === 'script');
    const cssRequests = requests.filter(r => r.resourceType === 'stylesheet');
    const imageRequests = requests.filter(r => r.resourceType === 'image');
    
    console.log(`JS files: ${jsRequests.length}`);
    console.log(`CSS files: ${cssRequests.length}`);
    console.log(`Images: ${imageRequests.length}`);
  });
});

test.describe('Console and Error Monitoring', () => {
  test('should capture console messages', async ({ page }) => {
    const consoleMessages = [];
    
    page.on('console', msg => {
      consoleMessages.push({
        type: msg.type(),
        text: msg.text(),
      });
    });

    await page.goto('/javascript_error');
    
    // Check for errors
    const errors = consoleMessages.filter(m => m.type === 'error');
    console.log('Console errors:', errors);
  });

  test('should detect JavaScript errors', async ({ page }) => {
    const errors = [];
    
    page.on('pageerror', error => {
      errors.push(error.message);
    });

    await page.goto('/javascript_error');
    
    // Click to trigger error
    await page.click('button').catch(() => {}); // Ignore if no button
    
    // Log any errors found
    if (errors.length > 0) {
      console.log('JavaScript errors detected:', errors);
    }
  });

  test('should monitor failed requests', async ({ page }) => {
    const failedRequests = [];
    
    page.on('requestfailed', request => {
      failedRequests.push({
        url: request.url(),
        failure: request.failure()?.errorText,
      });
    });

    await page.goto('/');
    
    if (failedRequests.length > 0) {
      console.log('Failed requests:', failedRequests);
    }
  });
});
