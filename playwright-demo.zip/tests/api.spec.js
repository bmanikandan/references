const { test, expect } = require('@playwright/test');

/**
 * API Testing with Playwright
 * Playwright can also be used for API testing without a browser
 */
test.describe('API Testing', () => {
  const baseURL = 'https://jsonplaceholder.typicode.com';

  test('GET request - fetch all posts', async ({ request }) => {
    const response = await request.get(`${baseURL}/posts`);
    
    // Verify response status
    expect(response.ok()).toBeTruthy();
    expect(response.status()).toBe(200);
    
    // Parse and verify response body
    const posts = await response.json();
    expect(Array.isArray(posts)).toBe(true);
    expect(posts.length).toBeGreaterThan(0);
    
    // Verify post structure
    const firstPost = posts[0];
    expect(firstPost).toHaveProperty('id');
    expect(firstPost).toHaveProperty('title');
    expect(firstPost).toHaveProperty('body');
    expect(firstPost).toHaveProperty('userId');
  });

  test('GET request - fetch single post', async ({ request }) => {
    const response = await request.get(`${baseURL}/posts/1`);
    
    expect(response.ok()).toBeTruthy();
    
    const post = await response.json();
    expect(post.id).toBe(1);
    expect(post.title).toBeTruthy();
  });

  test('POST request - create new post', async ({ request }) => {
    const newPost = {
      title: 'Test Post from Playwright',
      body: 'This is a test post created using Playwright API testing',
      userId: 1,
    };

    const response = await request.post(`${baseURL}/posts`, {
      data: newPost,
    });

    expect(response.status()).toBe(201);
    
    const createdPost = await response.json();
    expect(createdPost.title).toBe(newPost.title);
    expect(createdPost.body).toBe(newPost.body);
    expect(createdPost.id).toBeTruthy();
  });

  test('PUT request - update post', async ({ request }) => {
    const updatedPost = {
      id: 1,
      title: 'Updated Title',
      body: 'Updated body content',
      userId: 1,
    };

    const response = await request.put(`${baseURL}/posts/1`, {
      data: updatedPost,
    });

    expect(response.ok()).toBeTruthy();
    
    const result = await response.json();
    expect(result.title).toBe(updatedPost.title);
  });

  test('PATCH request - partial update', async ({ request }) => {
    const response = await request.patch(`${baseURL}/posts/1`, {
      data: {
        title: 'Patched Title',
      },
    });

    expect(response.ok()).toBeTruthy();
    
    const result = await response.json();
    expect(result.title).toBe('Patched Title');
  });

  test('DELETE request', async ({ request }) => {
    const response = await request.delete(`${baseURL}/posts/1`);
    
    expect(response.ok()).toBeTruthy();
    expect(response.status()).toBe(200);
  });

  test('should handle query parameters', async ({ request }) => {
    const response = await request.get(`${baseURL}/posts`, {
      params: {
        userId: 1,
      },
    });

    expect(response.ok()).toBeTruthy();
    
    const posts = await response.json();
    
    // All posts should belong to userId 1
    posts.forEach(post => {
      expect(post.userId).toBe(1);
    });
  });

  test('should handle headers', async ({ request }) => {
    const response = await request.get(`${baseURL}/posts/1`, {
      headers: {
        'Accept': 'application/json',
        'Custom-Header': 'test-value',
      },
    });

    expect(response.ok()).toBeTruthy();
  });

  test('should validate response headers', async ({ request }) => {
    const response = await request.get(`${baseURL}/posts`);
    
    // Check content type
    const contentType = response.headers()['content-type'];
    expect(contentType).toContain('application/json');
  });

  test('should handle 404 errors', async ({ request }) => {
    const response = await request.get(`${baseURL}/posts/99999`);
    
    expect(response.status()).toBe(404);
    expect(response.ok()).toBeFalsy();
  });
});

test.describe('API + UI Integration', () => {
  test('should use API to setup test data then verify in UI', async ({ page, request }) => {
    // This example shows how you might combine API and UI testing
    // Using API to check data, then verify it renders correctly
    
    // First, get data via API
    const apiResponse = await request.get('https://jsonplaceholder.typicode.com/users/1');
    const userData = await apiResponse.json();
    
    // Store the expected data
    const expectedName = userData.name;
    const expectedEmail = userData.email;
    
    // Now you could navigate to a UI that displays this user
    // and verify the data matches what the API returned
    // (This is a conceptual example - the demo site doesn't have this)
    
    console.log(`API returned user: ${expectedName} (${expectedEmail})`);
    expect(expectedName).toBeTruthy();
    expect(expectedEmail).toContain('@');
  });

  test('should mock API responses', async ({ page }) => {
    // Intercept API calls and return mock data
    await page.route('**/api/users', route => {
      route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify([
          { id: 1, name: 'Mock User 1' },
          { id: 2, name: 'Mock User 2' },
        ]),
      });
    });

    // Now any request to */api/users will return our mock data
    // This is useful for testing UI components in isolation
  });

  test('should intercept and modify responses', async ({ page }) => {
    // Intercept and modify responses
    await page.route('**/posts/*', async route => {
      const response = await route.fetch();
      const json = await response.json();
      
      // Modify the response
      json.title = 'Modified Title';
      
      await route.fulfill({
        response,
        body: JSON.stringify(json),
      });
    });
  });
});
