const { test, expect } = require('@playwright/test');
const { LoginPage } = require('../pages/LoginPage');

test.describe('Login Functionality', () => {
  let loginPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    await loginPage.goto();
  });

  test('should display login page elements', async ({ page }) => {
    // Verify page title
    await expect(page).toHaveTitle(/The Internet/);
    
    // Verify form elements are visible
    await expect(page.locator('#username')).toBeVisible();
    await expect(page.locator('#password')).toBeVisible();
    await expect(page.locator('button[type="submit"]')).toBeVisible();
  });

  test('should login with valid credentials', async ({ page }) => {
    await loginPage.login('tomsmith', 'SuperSecretPassword!');
    
    // Verify successful login
    await expect(page.locator('.flash.success')).toBeVisible();
    const message = await loginPage.getSuccessMessage();
    expect(message).toContain('You logged into a secure area!');
    
    // Verify we can see the logout button
    await expect(page.locator('a[href="/logout"]')).toBeVisible();
  });

  test('should fail login with invalid username', async ({ page }) => {
    await loginPage.login('invaliduser', 'SuperSecretPassword!');
    
    // Verify error message
    await expect(page.locator('.flash.error')).toBeVisible();
    const message = await loginPage.getErrorMessage();
    expect(message).toContain('Your username is invalid!');
  });

  test('should fail login with invalid password', async ({ page }) => {
    await loginPage.login('tomsmith', 'wrongpassword');
    
    // Verify error message
    await expect(page.locator('.flash.error')).toBeVisible();
    const message = await loginPage.getErrorMessage();
    expect(message).toContain('Your password is invalid!');
  });

  test('should logout successfully', async ({ page }) => {
    // Login first
    await loginPage.login('tomsmith', 'SuperSecretPassword!');
    await expect(page.locator('.flash.success')).toBeVisible();
    
    // Now logout
    await loginPage.logout();
    
    // Verify we're logged out
    await expect(page.locator('.flash.success')).toContainText('You logged out');
    await expect(page.locator('#username')).toBeVisible();
  });

  test('should remember login state with cookies', async ({ page, context }) => {
    // Login
    await loginPage.login('tomsmith', 'SuperSecretPassword!');
    await expect(page.locator('.flash.success')).toBeVisible();
    
    // Get cookies
    const cookies = await context.cookies();
    expect(cookies.length).toBeGreaterThan(0);
    
    // Navigate away and back - session should persist
    await page.goto('/');
    await page.goto('/secure');
    
    // Should still be on secure page (not redirected to login)
    await expect(page).toHaveURL(/\/secure/);
  });
});

test.describe('Login - Edge Cases', () => {
  test('should handle empty form submission', async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.goto();
    
    // Click login without entering anything
    await loginPage.clickLogin();
    
    // Should show error
    await expect(page.locator('.flash.error')).toBeVisible();
  });

  test('should handle special characters in password', async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.goto();
    
    // Use special characters
    await loginPage.login('tomsmith', 'Test@#$%^&*()!');
    
    // Should fail (wrong password)
    await expect(page.locator('.flash.error')).toBeVisible();
  });
});
