const { test, expect } = require('@playwright/test');
const path = require('path');
const fs = require('fs');
const { setupDialogHandler, isVisible } = require('../utils/helpers');

test.describe('Iframe Handling', () => {
  test('should interact with content inside iframe', async ({ page }) => {
    await page.goto('/iframe');
    
    // Get the iframe
    const frameElement = page.frameLocator('#mce_0_ifr');
    
    // Clear existing content and type new text
    await frameElement.locator('#tinymce').fill('');
    await frameElement.locator('#tinymce').type('Hello from Playwright!');
    
    // Verify the text was entered
    const content = await frameElement.locator('#tinymce').textContent();
    expect(content).toContain('Hello from Playwright!');
  });

  test('should handle nested iframes', async ({ page }) => {
    await page.goto('/nested_frames');
    
    // Access the top frame
    const topFrame = page.frameLocator('frame[name="frame-top"]');
    
    // Access left frame inside top
    const leftFrame = topFrame.frameLocator('frame[name="frame-left"]');
    const leftContent = await leftFrame.locator('body').textContent();
    expect(leftContent).toContain('LEFT');
    
    // Access middle frame
    const middleFrame = topFrame.frameLocator('frame[name="frame-middle"]');
    const middleContent = await middleFrame.locator('body').textContent();
    expect(middleContent).toContain('MIDDLE');
  });
});

test.describe('JavaScript Alerts', () => {
  test('should handle simple alert', async ({ page }) => {
    await page.goto('/javascript_alerts');
    
    // Setup dialog handler
    let alertMessage = '';
    page.on('dialog', async dialog => {
      alertMessage = dialog.message();
      await dialog.accept();
    });
    
    // Trigger alert
    await page.click('button:has-text("Click for JS Alert")');
    
    // Verify alert was handled
    await expect(page.locator('#result')).toContainText('successfully');
    expect(alertMessage).toBe('I am a JS Alert');
  });

  test('should handle confirm dialog - accept', async ({ page }) => {
    await page.goto('/javascript_alerts');
    
    page.on('dialog', async dialog => {
      await dialog.accept();
    });
    
    await page.click('button:has-text("Click for JS Confirm")');
    await expect(page.locator('#result')).toContainText('Ok');
  });

  test('should handle confirm dialog - dismiss', async ({ page }) => {
    await page.goto('/javascript_alerts');
    
    page.on('dialog', async dialog => {
      await dialog.dismiss();
    });
    
    await page.click('button:has-text("Click for JS Confirm")');
    await expect(page.locator('#result')).toContainText('Cancel');
  });

  test('should handle prompt dialog', async ({ page }) => {
    await page.goto('/javascript_alerts');
    
    const promptText = 'Playwright Test Input';
    
    page.on('dialog', async dialog => {
      await dialog.accept(promptText);
    });
    
    await page.click('button:has-text("Click for JS Prompt")');
    await expect(page.locator('#result')).toContainText(promptText);
  });
});

test.describe('File Upload', () => {
  test('should upload a file', async ({ page }) => {
    await page.goto('/upload');
    
    // Create a test file
    const testFilePath = '/tmp/test-upload.txt';
    fs.writeFileSync(testFilePath, 'This is a test file for upload');
    
    // Upload the file
    await page.setInputFiles('#file-upload', testFilePath);
    
    // Submit
    await page.click('#file-submit');
    
    // Verify upload success
    await expect(page.locator('#uploaded-files')).toContainText('test-upload.txt');
    
    // Cleanup
    fs.unlinkSync(testFilePath);
  });

  test('should upload multiple files', async ({ page }) => {
    await page.goto('/upload');
    
    // Create test files
    const files = ['/tmp/file1.txt', '/tmp/file2.txt'];
    files.forEach((file, i) => {
      fs.writeFileSync(file, `Test content ${i + 1}`);
    });
    
    // Upload multiple files
    await page.setInputFiles('#file-upload', files);
    
    // Cleanup
    files.forEach(file => fs.unlinkSync(file));
  });
});

test.describe('File Download', () => {
  test('should download a file', async ({ page }) => {
    await page.goto('/download');
    
    // Start waiting for download before clicking
    const [download] = await Promise.all([
      page.waitForEvent('download'),
      page.click('a[href*=".txt"]'), // Click any .txt file link
    ]);
    
    // Get download info
    const fileName = download.suggestedFilename();
    expect(fileName).toBeTruthy();
    
    // Save to specific path
    const downloadPath = `/tmp/${fileName}`;
    await download.saveAs(downloadPath);
    
    // Verify file exists
    expect(fs.existsSync(downloadPath)).toBe(true);
    
    // Cleanup
    fs.unlinkSync(downloadPath);
  });
});

test.describe('Drag and Drop', () => {
  test('should drag and drop elements', async ({ page }) => {
    await page.goto('/drag_and_drop');
    
    // Get the source and target elements
    const source = page.locator('#column-a');
    const target = page.locator('#column-b');
    
    // Verify initial state
    await expect(source).toContainText('A');
    await expect(target).toContainText('B');
    
    // Perform drag and drop
    await source.dragTo(target);
    
    // Note: This demo might not work perfectly with all drag implementations
    // The elements should have swapped
  });
});

test.describe('Hover Actions', () => {
  test('should display content on hover', async ({ page }) => {
    await page.goto('/hovers');
    
    // Get all user figures
    const figures = page.locator('.figure');
    
    // Hover over first figure
    await figures.first().hover();
    
    // Verify caption appears
    await expect(page.locator('.figcaption').first()).toBeVisible();
  });

  test('should reveal profile links on hover', async ({ page }) => {
    await page.goto('/hovers');
    
    const figures = page.locator('.figure');
    const captions = page.locator('.figcaption');
    
    // Check each figure
    for (let i = 0; i < await figures.count(); i++) {
      await figures.nth(i).hover();
      await expect(captions.nth(i)).toBeVisible();
      
      // Verify profile link is present
      const link = captions.nth(i).locator('a');
      await expect(link).toHaveAttribute('href', /\/users\/\d+/);
    }
  });
});

test.describe('Dynamic Content', () => {
  test('should wait for dynamic elements', async ({ page }) => {
    await page.goto('/dynamic_loading/1');
    
    // Click start button
    await page.click('#start button');
    
    // Wait for loading to complete and text to appear
    await expect(page.locator('#finish h4')).toBeVisible({ timeout: 10000 });
    await expect(page.locator('#finish h4')).toHaveText('Hello World!');
  });

  test('should handle element not initially present', async ({ page }) => {
    await page.goto('/dynamic_loading/2');
    
    // Element doesn't exist in DOM initially
    await expect(page.locator('#finish')).not.toBeVisible();
    
    // Click start
    await page.click('#start button');
    
    // Wait for element to be added and visible
    await expect(page.locator('#finish h4')).toBeVisible({ timeout: 10000 });
  });
});

test.describe('Form Inputs', () => {
  test('should handle checkboxes', async ({ page }) => {
    await page.goto('/checkboxes');
    
    const checkboxes = page.locator('input[type="checkbox"]');
    
    // Check first checkbox
    await checkboxes.first().check();
    await expect(checkboxes.first()).toBeChecked();
    
    // Uncheck second checkbox
    await checkboxes.last().uncheck();
    await expect(checkboxes.last()).not.toBeChecked();
  });

  test('should handle dropdown selection', async ({ page }) => {
    await page.goto('/dropdown');
    
    // Select by value
    await page.selectOption('#dropdown', '1');
    await expect(page.locator('#dropdown')).toHaveValue('1');
    
    // Select by label
    await page.selectOption('#dropdown', { label: 'Option 2' });
    await expect(page.locator('#dropdown')).toHaveValue('2');
  });

  test('should handle key presses', async ({ page }) => {
    await page.goto('/key_presses');
    
    const input = page.locator('#target');
    
    // Focus and type
    await input.focus();
    await page.keyboard.press('Enter');
    
    await expect(page.locator('#result')).toContainText('ENTER');
    
    // Try another key
    await page.keyboard.press('Tab');
    await expect(page.locator('#result')).toContainText('TAB');
  });
});

test.describe('Context Menu', () => {
  test('should handle right-click context menu', async ({ page }) => {
    await page.goto('/context_menu');
    
    // Setup alert handler
    let alertText = '';
    page.on('dialog', async dialog => {
      alertText = dialog.message();
      await dialog.accept();
    });
    
    // Right-click on the box
    await page.locator('#hot-spot').click({ button: 'right' });
    
    // Verify alert appeared
    expect(alertText).toBe('You selected a context menu');
  });
});

test.describe('New Window/Tab', () => {
  test('should handle new window', async ({ page, context }) => {
    await page.goto('/windows');
    
    // Wait for new page to open
    const [newPage] = await Promise.all([
      context.waitForEvent('page'),
      page.click('a[href="/windows/new"]'),
    ]);
    
    // Wait for new page to load
    await newPage.waitForLoadState();
    
    // Verify new window content
    await expect(newPage.locator('h3')).toHaveText('New Window');
    
    // Close the new page
    await newPage.close();
  });
});

test.describe('Shadow DOM', () => {
  test('should interact with shadow DOM elements', async ({ page }) => {
    await page.goto('/shadowdom');
    
    // Access shadow DOM content
    // Playwright can pierce shadow DOM automatically
    const shadowContent = page.locator('span');
    
    // Verify we can see shadow DOM content
    const count = await shadowContent.count();
    expect(count).toBeGreaterThan(0);
  });
});
