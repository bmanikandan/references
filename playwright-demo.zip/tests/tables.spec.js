const { test, expect } = require('@playwright/test');
const { TablesPage } = require('../pages/TablesPage');

test.describe('Data Tables', () => {
  let tablesPage;

  test.beforeEach(async ({ page }) => {
    tablesPage = new TablesPage(page);
    await tablesPage.goto();
  });

  test('should display tables correctly', async ({ page }) => {
    // Verify both tables are visible
    await expect(page.locator('#table1')).toBeVisible();
    await expect(page.locator('#table2')).toBeVisible();
  });

  test('should extract all table data', async () => {
    const data = await tablesPage.getTable1Data();
    
    // Verify we got data
    expect(data.length).toBeGreaterThan(0);
    
    // Verify data structure
    const firstRow = data[0];
    expect(firstRow).toHaveProperty('lastName');
    expect(firstRow).toHaveProperty('firstName');
    expect(firstRow).toHaveProperty('email');
    expect(firstRow).toHaveProperty('due');
    expect(firstRow).toHaveProperty('website');
    
    console.log('Extracted table data:', JSON.stringify(data, null, 2));
  });

  test('should find row by email', async () => {
    const row = await tablesPage.findRowByEmail('jdoe@hotmail.com');
    
    expect(row).not.toBeNull();
    expect(row.firstName).toBe('John');
    expect(row.lastName).toBe('Doe');
  });

  test('should get correct row count', async () => {
    const count = await tablesPage.getTable1RowCount();
    expect(count).toBe(4); // The demo table has 4 rows
  });

  test('should sort table by column', async ({ page }) => {
    // Get initial first cell value
    const initialFirst = await tablesPage.getCellValue(0, 0);
    
    // Sort by Last Name
    await tablesPage.sortByColumn('Last Name');
    
    // Wait for sort to complete
    await page.waitForTimeout(500);
    
    // Get data after sort
    const sortedData = await tablesPage.getTable1Data();
    
    // Verify sorting (should be alphabetical)
    const lastNames = sortedData.map(row => row.lastName);
    const sortedLastNames = [...lastNames].sort();
    
    // Check if sorted (ascending or descending)
    const isAscending = JSON.stringify(lastNames) === JSON.stringify(sortedLastNames);
    const isDescending = JSON.stringify(lastNames) === JSON.stringify(sortedLastNames.reverse());
    
    expect(isAscending || isDescending).toBe(true);
  });

  test('should get specific cell value', async () => {
    const cellValue = await tablesPage.getCellValue(0, 2); // First row, email column
    expect(cellValue).toContain('@'); // Should be an email
  });
});

test.describe('Table Data Validation', () => {
  test('should validate email format in table', async ({ page }) => {
    const tablesPage = new TablesPage(page);
    await tablesPage.goto();
    
    const data = await tablesPage.getTable1Data();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    
    for (const row of data) {
      expect(row.email).toMatch(emailRegex);
    }
  });

  test('should validate due amounts are numeric', async ({ page }) => {
    const tablesPage = new TablesPage(page);
    await tablesPage.goto();
    
    const data = await tablesPage.getTable1Data();
    
    for (const row of data) {
      // Due format is like "$50.00"
      const numericValue = parseFloat(row.due.replace('$', ''));
      expect(numericValue).not.toBeNaN();
      expect(numericValue).toBeGreaterThanOrEqual(0);
    }
  });
});
