/**
 * Page Object Model for the Login Page
 * Encapsulates all login page interactions
 */
class LoginPage {
  constructor(page) {
    this.page = page;
    
    // Define selectors
    this.selectors = {
      usernameInput: '#username',
      passwordInput: '#password',
      loginButton: 'button[type="submit"]',
      successMessage: '.flash.success',
      errorMessage: '.flash.error',
      logoutButton: 'a[href="/logout"]',
    };
  }

  /**
   * Navigate to the login page
   */
  async goto() {
    await this.page.goto('/login');
  }

  /**
   * Fill in the username field
   * @param {string} username 
   */
  async fillUsername(username) {
    await this.page.fill(this.selectors.usernameInput, username);
  }

  /**
   * Fill in the password field
   * @param {string} password 
   */
  async fillPassword(password) {
    await this.page.fill(this.selectors.passwordInput, password);
  }

  /**
   * Click the login button
   */
  async clickLogin() {
    await this.page.click(this.selectors.loginButton);
  }

  /**
   * Perform complete login
   * @param {string} username 
   * @param {string} password 
   */
  async login(username, password) {
    await this.fillUsername(username);
    await this.fillPassword(password);
    await this.clickLogin();
  }

  /**
   * Get success message text
   * @returns {Promise<string>}
   */
  async getSuccessMessage() {
    await this.page.waitForSelector(this.selectors.successMessage);
    const text = await this.page.textContent(this.selectors.successMessage);
    return text.trim();
  }

  /**
   * Get error message text
   * @returns {Promise<string>}
   */
  async getErrorMessage() {
    await this.page.waitForSelector(this.selectors.errorMessage);
    const text = await this.page.textContent(this.selectors.errorMessage);
    return text.trim();
  }

  /**
   * Check if logged in successfully
   * @returns {Promise<boolean>}
   */
  async isLoggedIn() {
    try {
      await this.page.waitForSelector(this.selectors.logoutButton, { timeout: 3000 });
      return true;
    } catch {
      return false;
    }
  }

  /**
   * Logout from the application
   */
  async logout() {
    await this.page.click(this.selectors.logoutButton);
  }
}

module.exports = { LoginPage };
