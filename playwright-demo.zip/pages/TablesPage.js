/**
 * Page Object Model for the Data Tables Page
 * Demonstrates handling tables and extracting data
 */
class TablesPage {
  constructor(page) {
    this.page = page;
    
    this.selectors = {
      table1: '#table1',
      table2: '#table2',
      tableRows: 'tbody tr',
      sortableHeaders: 'thead th span',
    };
  }

  /**
   * Navigate to the tables page
   */
  async goto() {
    await this.page.goto('/tables');
  }

  /**
   * Get all data from table 1
   * @returns {Promise<Array<Object>>}
   */
  async getTable1Data() {
    return await this.page.$$eval(`${this.selectors.table1} ${this.selectors.tableRows}`, rows => {
      return rows.map(row => {
        const cells = row.querySelectorAll('td');
        return {
          lastName: cells[0]?.textContent || '',
          firstName: cells[1]?.textContent || '',
          email: cells[2]?.textContent || '',
          due: cells[3]?.textContent || '',
          website: cells[4]?.textContent || '',
        };
      });
    });
  }

  /**
   * Get row count from table 1
   * @returns {Promise<number>}
   */
  async getTable1RowCount() {
    const rows = await this.page.$$(`${this.selectors.table1} ${this.selectors.tableRows}`);
    return rows.length;
  }

  /**
   * Sort table by column header
   * @param {string} columnName - The column header text to click
   */
  async sortByColumn(columnName) {
    await this.page.click(`${this.selectors.table1} th:has-text("${columnName}")`);
  }

  /**
   * Get specific cell value
   * @param {number} row - Row index (0-based)
   * @param {number} col - Column index (0-based)
   * @returns {Promise<string>}
   */
  async getCellValue(row, col) {
    const selector = `${this.selectors.table1} ${this.selectors.tableRows}:nth-child(${row + 1}) td:nth-child(${col + 1})`;
    return await this.page.textContent(selector);
  }

  /**
   * Find row by email
   * @param {string} email 
   * @returns {Promise<Object|null>}
   */
  async findRowByEmail(email) {
    const data = await this.getTable1Data();
    return data.find(row => row.email === email) || null;
  }
}

module.exports = { TablesPage };
