# API Testing Suite

A production-ready API test suite built with **Mocha**, **Chai**, and **Allure Reports**. Supports daily scheduled runs with cumulative trend graphs showing pass/fail history, response durations, and failure categories over time.

---

## Tech Stack

| Tool | Purpose |
|---|---|
| [Mocha](https://mochajs.org/) | Test runner |
| [Chai](https://www.chaijs.com/) | Assertions |
| [Axios](https://axios-http.com/) | HTTP client |
| [allure-mocha](https://allurereport.org/) | Allure reporter for Mocha |
| [allure-commandline](https://allurereport.org/docs/install-for-nodejs/) | Allure CLI (report generation) |
| [dotenv](https://github.com/motdotla/dotenv) | Environment variable loading |

---

## Project Structure

```
api-testing-suite/
├── .env.example                   # Environment variable template
├── .env                           # Your local env config (git-ignored)
├── .mocharc.cjs                   # Mocha configuration (reporter, timeout, etc.)
├── .gitignore
├── package.json
│
├── test/
│   ├── helpers/
│   │   ├── api-client.js          # Pre-configured Axios instance
│   │   └── allure-helper.js       # label(), step(), attachJson() utilities
│   ├── hooks/
│   │   └── root-hooks.js          # Global before/after hooks
│   └── specs/
│       ├── 01-users.test.js       # Users API – 16 tests (CRUD + 404)
│       ├── 02-posts.test.js       # Posts API – 22 tests (CRUD + filter + PATCH)
│       └── 03-comments.test.js    # Comments API – 16 tests (list, filter, schema)
│
├── scripts/
│   └── daily-run.js               # Orchestrates the full daily pipeline
│
└── allure-results/
    └── categories.json            # Custom Allure failure category rules
```

---

## Setup

### Prerequisites

- **Node.js** >= 18
- **Java** >= 8 (required by the Allure CLI to render reports)

### Install

```bash
git clone <repo-url>
cd api-testing-suite
npm install
```

### Configure environment

```bash
cp .env.example .env
```

Edit `.env` to point at your API:

```env
BASE_URL=https://jsonplaceholder.typicode.com
TEST_ENV=local
API_TOKEN=                  # leave blank if not needed
REQUEST_TIMEOUT_MS=10000
```

---

## Execution Commands

### Run all tests

Runs every spec file under `test/specs/` and writes raw Allure result files to `allure-results/`.

```bash
npm test
```

---

### Run smoke tests only

Runs only tests tagged with `@smoke` in the test name.

```bash
npm run test:smoke
```

---

### Run regression tests only

Runs only tests tagged with `@regression` in the test name.

```bash
npm run test:regression
```

---

### Daily run (recommended for CI / scheduled jobs)

Executes the full pipeline in sequence:

1. Copies `allure-report/history/` → `allure-results/history/` (preserves trend data)
2. Clears stale result files (keeps history)
3. Writes `executor.json` and `environment.properties` metadata
4. Runs all Mocha tests
5. Generates the Allure HTML report

```bash
npm run test:daily
```

Run tests and automatically open the report in a browser when done:

```bash
npm run test:daily -- --open
```

---

### Generate Allure HTML report

Generates the HTML report from the current contents of `allure-results/`. Run this after `npm test` if you want to build the report separately.

```bash
npm run report:generate
```

---

### Open the last generated report

Opens `allure-report/index.html` in your default browser.

```bash
npm run report:open
```

---

### Serve the report live from results

Spins up a temporary local server and opens the Allure report directly from `allure-results/` without a separate generate step. Useful for quick inspection during development.

```bash
npm run report:serve
```

---

### Clean all generated artefacts

Deletes both `allure-results/` and `allure-report/`. Use this to start fresh.

```bash
npm run clean
```

---

## Allure Report Features

### Trend graphs (daily history)

Each `npm run test:daily` run appends a data point to these trend graphs:

| Graph | What it shows |
|---|---|
| **History Trend** | Pass / fail / broken count per run |
| **Duration Trend** | Total suite execution time per run |
| **Categories Trend** | Infra errors vs. product defects vs. schema failures |
| **Retry Trend** | Flaky test frequency over time |

> Trend graphs become meaningful after **2+ daily runs**. History is preserved automatically by `daily-run.js`.

### Failure categories

Failures are automatically bucketed by `allure-results/categories.json`:

| Category | Matched on |
|---|---|
| Infrastructure / Network errors | `ECONNREFUSED`, `ETIMEDOUT`, `network`, `timeout` |
| API contract failures | `AssertionError`, `expected`, `to equal` |
| Wrong HTTP status code | Status code keywords in the error message |
| Schema / type mismatches | `is not`, `to be a`, `to include.keys` |
| Product defects | Any `failed` test not matched above |
| Test defects | Any `broken` test not matched above |

### Test metadata

Every test carries Allure labels visible in the report's sidebar:

- **Epic** → top-level grouping (e.g. `User Management`)
- **Feature** → suite-level grouping (e.g. `Users API`)
- **Story** → individual scenario (e.g. `List Users`)
- **Severity** → `blocker | critical | normal | minor | trivial`
- **Tags** → `@smoke`, `@regression`, `@schema`

---

## Scheduling daily runs

### macOS / Linux – cron

Run the suite every day at 06:00 and append logs to a file:

```bash
crontab -e
```

```cron
0 6 * * * cd /path/to/api-testing-suite && npm run test:daily >> logs/daily.log 2>&1
```

### GitHub Actions

```yaml
name: Daily API Tests

on:
  schedule:
    - cron: '0 6 * * *'   # 06:00 UTC every day
  workflow_dispatch:        # allow manual trigger

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Restore Allure history
        uses: actions/cache@v4
        with:
          path: allure-report/history
          key: allure-history-${{ github.run_id }}
          restore-keys: allure-history-

      - uses: actions/setup-node@v4
        with:
          node-version: 20

      - name: Install dependencies
        run: npm ci

      - name: Run daily pipeline
        env:
          BASE_URL: ${{ secrets.BASE_URL }}
          API_TOKEN: ${{ secrets.API_TOKEN }}
          TEST_ENV: staging
        run: npm run test:daily

      - name: Upload Allure report
        uses: actions/upload-artifact@v4
        if: always()
        with:
          name: allure-report-${{ github.run_number }}
          path: allure-report/
```

---

## Adding new tests

1. Create `test/specs/NN-<name>.test.js`
2. Use the helpers for consistent labelling and attachments:

```js
'use strict';

const { expect } = require('chai');
const apiClient = require('../helpers/api-client');
const { label, attachJson } = require('../helpers/allure-helper');

describe('Products API @regression', function () {
  describe('GET /products', function () {
    let response;

    before(async function () {
      label({
        epic: 'Catalogue',
        feature: 'Products API',
        story: 'List Products',
        severity: 'critical',
        tags: ['@regression', '@smoke']
      });
      response = await apiClient.get('/products');
      attachJson('Response', response.data);
    });

    it('returns HTTP 200', function () {
      expect(response.status).to.equal(200);
    });

    it('returns an array', function () {
      expect(response.data).to.be.an('array');
    });
  });
});
```

---

## Targeting a different API

Update `.env`:

```env
BASE_URL=https://api.myapp.com
TEST_ENV=staging
API_TOKEN=my-bearer-token
REQUEST_TIMEOUT_MS=15000
```

No code changes required — `api-client.js` reads all connection settings from the environment.
