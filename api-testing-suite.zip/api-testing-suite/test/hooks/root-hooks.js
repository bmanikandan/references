'use strict';

const { getAllure } = require('../helpers/allure-helper');

/**
 * Mocha root hooks.
 * These run once before/after the entire test suite per worker.
 */
exports.mochaHooks = {
  /**
   * Runs once before any test in the suite.
   * Sets global environment parameters visible in every Allure report.
   */
  beforeAll() {
    const allure = getAllure();
    try {
      allure.parameter('BASE_URL', process.env.BASE_URL || 'https://jsonplaceholder.typicode.com');
      allure.parameter('Environment', process.env.TEST_ENV || 'local');
      allure.parameter('Node', process.version);
      allure.parameter('Run Date', new Date().toISOString().split('T')[0]);
    } catch {
      // ignore if allure runtime unavailable
    }
  }
};
