'use strict';

const axios = require('axios');

/**
 * Pre-configured Axios instance for API testing.
 * Reads BASE_URL, API_TOKEN, and REQUEST_TIMEOUT_MS from .env
 */
const apiClient = axios.create({
  baseURL: process.env.BASE_URL || 'https://jsonplaceholder.typicode.com',
  timeout: Number(process.env.REQUEST_TIMEOUT_MS) || 10000,
  headers: {
    'Content-Type': 'application/json',
    Accept: 'application/json',
    ...(process.env.API_TOKEN && {
      Authorization: `Bearer ${process.env.API_TOKEN}`
    }),
    ...(process.env.API_KEY && {
      'X-API-Key': process.env.API_KEY
    })
  },
  // Don't throw on 4xx/5xx so tests can assert on status codes
  validateStatus: () => true
});

// ─── Request interceptor: log every outgoing call ─────────────────────────
apiClient.interceptors.request.use((config) => {
  config.metadata = { startTime: Date.now() };
  return config;
});

// ─── Response interceptor: attach duration ────────────────────────────────
apiClient.interceptors.response.use(
  (response) => {
    response.duration = Date.now() - response.config.metadata.startTime;
    return response;
  },
  (error) => {
    if (error.config?.metadata) {
      error.duration = Date.now() - error.config.metadata.startTime;
    }
    return Promise.reject(error);
  }
);

module.exports = apiClient;
