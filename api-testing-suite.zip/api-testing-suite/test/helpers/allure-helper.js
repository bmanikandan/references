'use strict';

/**
 * Thin wrapper around allure-mocha runtime.
 * Falls back to no-ops if allure runtime isn't loaded, so tests run fine
 * even without the Allure reporter configured.
 */

let _allure = null;

function getAllure() {
  if (_allure) return _allure;
  try {
    // allure-mocha v3 exposes a global `allure` object via its runtime module
    _allure = require('allure-mocha/runtime').allure;
  } catch {
    // Reporter not active – return a harmless no-op proxy
    _allure = new Proxy(
      {},
      {
        get: () => () => {},
        apply: () => {}
      }
    );
  }
  return _allure;
}

/**
 * Attach raw JSON to the Allure report for the current test.
 * @param {string} name     - Attachment name shown in the report
 * @param {object} payload  - Object to stringify and attach
 */
function attachJson(name, payload) {
  try {
    getAllure().attachment(name, JSON.stringify(payload, null, 2), {
      contentType: 'application/json',
      fileExtension: 'json'
    });
  } catch {
    // ignore attachment errors
  }
}

/**
 * Attach a plain-text string to the Allure report.
 */
function attachText(name, text) {
  try {
    getAllure().attachment(name, String(text), {
      contentType: 'text/plain',
      fileExtension: 'txt'
    });
  } catch {
    // ignore
  }
}

/**
 * Wrap a block of test code in a named Allure step.
 * Automatically attaches the HTTP response (status + body) when provided.
 *
 * @param {string}   name       - Step label shown in the report
 * @param {Function} fn         - Async or sync callback
 * @param {object}   [response] - Axios response to auto-attach
 */
async function step(name, fn, response) {
  const allure = getAllure();
  try {
    return await allure.step(name, async () => {
      if (response) {
        attachJson(`Response (${response.status})`, {
          status: response.status,
          statusText: response.statusText,
          duration: `${response.duration ?? '?'}ms`,
          data: response.data
        });
      }
      return fn();
    });
  } catch {
    // allure.step not available in this version – just run the fn
    return fn();
  }
}

/**
 * Apply a standard set of Allure labels to the current test.
 *
 * @param {{ epic, feature, story, severity, tags }} opts
 */
function label({ epic, feature, story, severity = 'normal', tags = [] } = {}) {
  const allure = getAllure();
  try {
    if (epic) allure.epic(epic);
    if (feature) allure.feature(feature);
    if (story) allure.story(story);
    allure.severity(severity);
    tags.forEach((t) => allure.tag(t));
  } catch {
    // ignore
  }
}

module.exports = { getAllure, attachJson, attachText, step, label };
