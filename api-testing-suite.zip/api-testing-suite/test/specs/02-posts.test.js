'use strict';

const { expect } = require('chai');
const apiClient = require('../helpers/api-client');
const { label, attachJson } = require('../helpers/allure-helper');

// ─────────────────────────────────────────────────────────────────────────────
// Posts API  –  /posts
// Target: https://jsonplaceholder.typicode.com/posts
// ─────────────────────────────────────────────────────────────────────────────

describe('Posts API @regression', function () {

  // ── LIST ALL ──────────────────────────────────────────────────────────────
  describe('GET /posts', function () {
    let response;

    before(async function () {
      label({ epic: 'Content Management', feature: 'Posts API', story: 'List Posts', severity: 'critical', tags: ['@regression', '@smoke'] });
      response = await apiClient.get('/posts');
      attachJson('Response (first 3 items)', response.data?.slice(0, 3));
    });

    it('returns HTTP 200', function () {
      expect(response.status).to.equal(200);
    });

    it('returns an array of posts', function () {
      expect(response.data).to.be.an('array').with.length.greaterThan(0);
    });

    it('each post has id, userId, title, body', function () {
      response.data.forEach((post) => {
        expect(post).to.include.keys('id', 'userId', 'title', 'body');
      });
    });

    it('post ids are positive integers', function () {
      response.data.forEach((post) => {
        expect(post.id).to.be.a('number').and.be.greaterThan(0);
      });
    });

    it('responds within 5 seconds', function () {
      expect(response.duration).to.be.lessThan(5000);
    });
  });

  // ── FILTER BY USER ────────────────────────────────────────────────────────
  describe('GET /posts?userId=1', function () {
    let response;

    before(async function () {
      label({ epic: 'Content Management', feature: 'Posts API', story: 'Filter Posts by User', severity: 'normal', tags: ['@regression'] });
      response = await apiClient.get('/posts', { params: { userId: 1 } });
      attachJson('Filtered Response', response.data);
    });

    it('returns HTTP 200', function () {
      expect(response.status).to.equal(200);
    });

    it('returns only posts for userId 1', function () {
      expect(response.data).to.be.an('array');
      response.data.forEach((post) => {
        expect(post.userId).to.equal(1);
      });
    });

    it('returns expected number of posts', function () {
      expect(response.data.length).to.be.greaterThan(0);
    });
  });

  // ── GET SINGLE ────────────────────────────────────────────────────────────
  describe('GET /posts/:id', function () {
    let response;

    before(async function () {
      label({ epic: 'Content Management', feature: 'Posts API', story: 'Get Single Post', severity: 'critical', tags: ['@regression', '@smoke'] });
      response = await apiClient.get('/posts/1');
      attachJson('Post Response', response.data);
    });

    it('returns HTTP 200', function () {
      expect(response.status).to.equal(200);
    });

    it('returns post with id 1', function () {
      expect(response.data.id).to.equal(1);
    });

    it('title is a non-empty string', function () {
      expect(response.data.title).to.be.a('string').and.have.length.greaterThan(0);
    });

    it('body is a non-empty string', function () {
      expect(response.data.body).to.be.a('string').and.have.length.greaterThan(0);
    });
  });

  // ── NOT FOUND ─────────────────────────────────────────────────────────────
  describe('GET /posts/:id – not found', function () {
    let response;

    before(async function () {
      label({ epic: 'Content Management', feature: 'Posts API', story: 'Post Not Found', severity: 'minor', tags: ['@regression'] });
      response = await apiClient.get('/posts/99999');
    });

    it('returns HTTP 404', function () {
      expect(response.status).to.equal(404);
    });
  });

  // ── CREATE ────────────────────────────────────────────────────────────────
  describe('POST /posts', function () {
    let response;
    const newPost = {
      title: 'Test Post Title',
      body: 'This is the body of the test post',
      userId: 1
    };

    before(async function () {
      label({ epic: 'Content Management', feature: 'Posts API', story: 'Create Post', severity: 'critical', tags: ['@regression'] });
      attachJson('Request Payload', newPost);
      response = await apiClient.post('/posts', newPost);
      attachJson('Created Post', response.data);
    });

    it('returns HTTP 201', function () {
      expect(response.status).to.equal(201);
    });

    it('echoes back title and body', function () {
      expect(response.data.title).to.equal(newPost.title);
      expect(response.data.body).to.equal(newPost.body);
    });

    it('assigns a new id', function () {
      expect(response.data.id).to.be.a('number').and.greaterThan(0);
    });
  });

  // ── FULL UPDATE ───────────────────────────────────────────────────────────
  describe('PUT /posts/:id', function () {
    let response;
    const update = {
      id: 1,
      title: 'Updated Title',
      body: 'Updated body content',
      userId: 1
    };

    before(async function () {
      label({ epic: 'Content Management', feature: 'Posts API', story: 'Full Update Post', severity: 'normal', tags: ['@regression'] });
      attachJson('Request Payload', update);
      response = await apiClient.put('/posts/1', update);
      attachJson('Updated Post', response.data);
    });

    it('returns HTTP 200', function () {
      expect(response.status).to.equal(200);
    });

    it('reflects all updated fields', function () {
      expect(response.data.title).to.equal(update.title);
      expect(response.data.body).to.equal(update.body);
      expect(response.data.id).to.equal(update.id);
    });
  });

  // ── PARTIAL UPDATE ────────────────────────────────────────────────────────
  describe('PATCH /posts/:id', function () {
    let response;
    const patch = { title: 'Patched Title Only' };

    before(async function () {
      label({ epic: 'Content Management', feature: 'Posts API', story: 'Partial Update Post', severity: 'normal', tags: ['@regression'] });
      attachJson('PATCH Payload', patch);
      response = await apiClient.patch('/posts/1', patch);
      attachJson('Patched Post', response.data);
    });

    it('returns HTTP 200', function () {
      expect(response.status).to.equal(200);
    });

    it('reflects patched title', function () {
      expect(response.data.title).to.equal(patch.title);
    });
  });

  // ── DELETE ────────────────────────────────────────────────────────────────
  describe('DELETE /posts/:id', function () {
    let response;

    before(async function () {
      label({ epic: 'Content Management', feature: 'Posts API', story: 'Delete Post', severity: 'normal', tags: ['@regression'] });
      response = await apiClient.delete('/posts/1');
    });

    it('returns HTTP 200', function () {
      expect(response.status).to.equal(200);
    });
  });
});
