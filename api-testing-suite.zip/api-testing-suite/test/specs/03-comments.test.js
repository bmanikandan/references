'use strict';

const { expect } = require('chai');
const apiClient = require('../helpers/api-client');
const { label, attachJson } = require('../helpers/allure-helper');

// ─────────────────────────────────────────────────────────────────────────────
// Comments API  –  /comments
// Target: https://jsonplaceholder.typicode.com/comments
// ─────────────────────────────────────────────────────────────────────────────

describe('Comments API @regression', function () {

  // ── LIST ALL ──────────────────────────────────────────────────────────────
  describe('GET /comments', function () {
    let response;

    before(async function () {
      label({ epic: 'Engagement', feature: 'Comments API', story: 'List Comments', severity: 'normal', tags: ['@regression'] });
      response = await apiClient.get('/comments');
      attachJson('Response (first 3)', response.data?.slice(0, 3));
    });

    it('returns HTTP 200', function () {
      expect(response.status).to.equal(200);
    });

    it('returns an array', function () {
      expect(response.data).to.be.an('array').with.length.greaterThan(0);
    });

    it('each comment has postId, id, name, email, body', function () {
      response.data.forEach((comment) => {
        expect(comment).to.include.keys('postId', 'id', 'name', 'email', 'body');
      });
    });
  });

  // ── FILTER BY POST ────────────────────────────────────────────────────────
  describe('GET /comments?postId=1', function () {
    let response;

    before(async function () {
      label({ epic: 'Engagement', feature: 'Comments API', story: 'Filter Comments by Post', severity: 'normal', tags: ['@regression'] });
      response = await apiClient.get('/comments', { params: { postId: 1 } });
      attachJson('Filtered Comments', response.data);
    });

    it('returns HTTP 200', function () {
      expect(response.status).to.equal(200);
    });

    it('returns only comments for postId 1', function () {
      expect(response.data).to.be.an('array');
      response.data.forEach((c) => {
        expect(c.postId).to.equal(1);
      });
    });
  });

  // ── GET SINGLE ────────────────────────────────────────────────────────────
  describe('GET /comments/:id', function () {
    let response;

    before(async function () {
      label({ epic: 'Engagement', feature: 'Comments API', story: 'Get Single Comment', severity: 'normal', tags: ['@regression', '@smoke'] });
      response = await apiClient.get('/comments/1');
      attachJson('Comment', response.data);
    });

    it('returns HTTP 200', function () {
      expect(response.status).to.equal(200);
    });

    it('has correct id', function () {
      expect(response.data.id).to.equal(1);
    });

    it('email field is a valid email format', function () {
      expect(response.data.email).to.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/);
    });

    it('body is a non-empty string', function () {
      expect(response.data.body).to.be.a('string').and.have.length.greaterThan(0);
    });
  });

  // ── NOT FOUND ─────────────────────────────────────────────────────────────
  describe('GET /comments/:id – not found', function () {
    let response;

    before(async function () {
      label({ epic: 'Engagement', feature: 'Comments API', story: 'Comment Not Found', severity: 'minor', tags: ['@regression'] });
      response = await apiClient.get('/comments/999999');
    });

    it('returns HTTP 404', function () {
      expect(response.status).to.equal(404);
    });
  });

  // ── SCHEMA VALIDATION ─────────────────────────────────────────────────────
  describe('Schema validation – GET /comments', function () {
    let comments;

    before(async function () {
      label({ epic: 'Engagement', feature: 'Comments API', story: 'Schema Validation', severity: 'blocker', tags: ['@regression', '@schema'] });
      const response = await apiClient.get('/comments');
      comments = response.data;
    });

    it('id is a positive integer', function () {
      comments.forEach((c) => {
        expect(c.id).to.be.a('number').and.satisfy((n) => Number.isInteger(n) && n > 0, 'id must be a positive integer');
      });
    });

    it('postId is a positive integer', function () {
      comments.forEach((c) => {
        expect(c.postId).to.be.a('number').and.satisfy((n) => Number.isInteger(n) && n > 0);
      });
    });

    it('name is a non-empty string', function () {
      comments.forEach((c) => {
        expect(c.name).to.be.a('string').and.have.length.greaterThan(0);
      });
    });

    it('email is a valid email', function () {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      comments.forEach((c) => {
        expect(c.email).to.match(emailRegex, `Invalid email: ${c.email}`);
      });
    });

    it('body is a non-empty string', function () {
      comments.forEach((c) => {
        expect(c.body).to.be.a('string').and.have.length.greaterThan(0);
      });
    });
  });
});
