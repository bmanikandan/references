'use strict';

const { expect } = require('chai');
const apiClient = require('../helpers/api-client');
const { label, step, attachJson } = require('../helpers/allure-helper');

// ─────────────────────────────────────────────────────────────────────────────
// Users API  –  /users
// Target: https://jsonplaceholder.typicode.com/users
// ─────────────────────────────────────────────────────────────────────────────

describe('Users API @regression', function () {

  // ── LIST ──────────────────────────────────────────────────────────────────
  describe('GET /users', function () {
    let response;

    before(async function () {
      label({ epic: 'User Management', feature: 'Users API', story: 'List Users', severity: 'critical', tags: ['@regression', '@smoke'] });
      response = await apiClient.get('/users');
      attachJson('Full Response', response.data);
    });

    it('returns HTTP 200', function () {
      expect(response.status).to.equal(200);
    });

    it('returns an array', function () {
      expect(response.data).to.be.an('array');
    });

    it('contains at least one user', function () {
      expect(response.data.length).to.be.greaterThan(0);
    });

    it('each user has required fields', function () {
      response.data.forEach((user) => {
        expect(user).to.include.keys('id', 'name', 'username', 'email');
      });
    });

    it('each user email is a valid format', function () {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      response.data.forEach((user) => {
        expect(user.email).to.match(emailRegex, `Invalid email: ${user.email}`);
      });
    });

    it('responds within acceptable time', function () {
      expect(response.duration).to.be.lessThan(5000);
    });
  });

  // ── GET SINGLE ────────────────────────────────────────────────────────────
  describe('GET /users/:id', function () {
    let response;

    before(async function () {
      label({ epic: 'User Management', feature: 'Users API', story: 'Get Single User', severity: 'critical', tags: ['@regression', '@smoke'] });
      response = await apiClient.get('/users/1');
      attachJson('User Response', response.data);
    });

    it('returns HTTP 200', function () {
      expect(response.status).to.equal(200);
    });

    it('returns correct user id', function () {
      expect(response.data.id).to.equal(1);
    });

    it('has name, username, email, phone, website', function () {
      expect(response.data).to.include.keys('name', 'username', 'email', 'phone', 'website');
    });

    it('has a nested address object', function () {
      expect(response.data.address).to.be.an('object');
      expect(response.data.address).to.include.keys('street', 'city', 'zipcode');
    });

    it('has a nested company object', function () {
      expect(response.data.company).to.be.an('object');
      expect(response.data.company).to.include.keys('name', 'catchPhrase');
    });
  });

  // ── NOT FOUND ─────────────────────────────────────────────────────────────
  describe('GET /users/:id – not found', function () {
    let response;

    before(async function () {
      label({ epic: 'User Management', feature: 'Users API', story: 'User Not Found', severity: 'normal', tags: ['@regression'] });
      response = await apiClient.get('/users/9999');
    });

    it('returns HTTP 404', function () {
      expect(response.status).to.equal(404);
    });
  });

  // ── CREATE ────────────────────────────────────────────────────────────────
  describe('POST /users', function () {
    let response;
    const newUser = { name: 'Jane Doe', username: 'janedoe', email: 'jane@example.com' };

    before(async function () {
      label({ epic: 'User Management', feature: 'Users API', story: 'Create User', severity: 'critical', tags: ['@regression'] });
      attachJson('Request Payload', newUser);
      response = await apiClient.post('/users', newUser);
      attachJson('Response', response.data);
    });

    it('returns HTTP 201', function () {
      expect(response.status).to.equal(201);
    });

    it('echoes back the created user fields', function () {
      expect(response.data).to.include({ name: newUser.name, username: newUser.username, email: newUser.email });
    });

    it('assigns an id to the new user', function () {
      expect(response.data).to.have.property('id');
      expect(response.data.id).to.be.a('number');
    });
  });

  // ── UPDATE ────────────────────────────────────────────────────────────────
  describe('PUT /users/:id', function () {
    let response;
    const update = { id: 1, name: 'Updated Name', username: 'updated', email: 'updated@example.com' };

    before(async function () {
      label({ epic: 'User Management', feature: 'Users API', story: 'Update User', severity: 'normal', tags: ['@regression'] });
      attachJson('Request Payload', update);
      response = await apiClient.put('/users/1', update);
      attachJson('Response', response.data);
    });

    it('returns HTTP 200', function () {
      expect(response.status).to.equal(200);
    });

    it('reflects the updated values', function () {
      expect(response.data.name).to.equal(update.name);
      expect(response.data.email).to.equal(update.email);
    });
  });

  // ── DELETE ────────────────────────────────────────────────────────────────
  describe('DELETE /users/:id', function () {
    let response;

    before(async function () {
      label({ epic: 'User Management', feature: 'Users API', story: 'Delete User', severity: 'normal', tags: ['@regression'] });
      response = await apiClient.delete('/users/1');
    });

    it('returns HTTP 200', function () {
      expect(response.status).to.equal(200);
    });
  });
});
