#!/usr/bin/env node
'use strict';

/**
 * daily-run.js
 * ────────────────────────────────────────────────────────────────────────────
 * Orchestrates the daily API test pipeline:
 *
 *  1. Preserve Allure history so trend graphs accumulate across runs
 *  2. Clear stale test results (keeping history)
 *  3. Write executor.json & environment.properties for the Allure report
 *  4. Run Mocha tests
 *  5. Generate the HTML Allure report
 *  6. Print a concise summary
 *
 * Usage:
 *   node scripts/daily-run.js          # run all tests
 *   node scripts/daily-run.js --open   # run tests + open report in browser
 *   npm run test:daily                  # alias
 * ────────────────────────────────────────────────────────────────────────────
 */

require('dotenv').config();
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

// ─── Paths ────────────────────────────────────────────────────────────────────
const ROOT          = process.cwd();
const RESULTS_DIR   = path.join(ROOT, 'allure-results');
const REPORT_DIR    = path.join(ROOT, 'allure-report');
const HISTORY_SRC   = path.join(REPORT_DIR, 'history');   // from previous report
const HISTORY_DST   = path.join(RESULTS_DIR, 'history');  // injected into new results

const OPEN_REPORT   = process.argv.includes('--open');
const RUN_DATE      = new Date().toISOString();

// ─── Utilities ────────────────────────────────────────────────────────────────
function log(msg)    { console.log(`  ${msg}`); }
function header(msg) { console.log(`\n${'─'.repeat(60)}\n  ${msg}\n${'─'.repeat(60)}`); }
function ok(msg)     { log(`✓  ${msg}`); }
function warn(msg)   { log(`⚠  ${msg}`); }
function fail(msg)   { log(`✗  ${msg}`); }

function ensureDir(dir) {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

function copyDir(src, dst) {
  ensureDir(dst);
  for (const file of fs.readdirSync(src)) {
    fs.copyFileSync(path.join(src, file), path.join(dst, file));
  }
}

// ─── Step 1: Preserve history for Allure trend graphs ─────────────────────────
function preserveHistory() {
  header('Step 1 – Preserve history');
  if (fs.existsSync(HISTORY_SRC)) {
    ensureDir(RESULTS_DIR);
    copyDir(HISTORY_SRC, HISTORY_DST);
    const files = fs.readdirSync(HISTORY_DST);
    ok(`Copied ${files.length} history file(s) → allure-results/history`);
    ok('Trend graphs will reflect previous runs');
  } else {
    warn('No previous report found – this may be the first run');
    warn('Trend graphs will appear from the 2nd daily run onward');
  }
}

// ─── Step 2: Clear old test results (NOT the history folder) ──────────────────
function clearOldResults() {
  header('Step 2 – Clear old results');
  ensureDir(RESULTS_DIR);

  let removed = 0;
  for (const entry of fs.readdirSync(RESULTS_DIR)) {
    // keep the history dir and categories.json
    if (entry === 'history' || entry === 'categories.json') continue;
    const full = path.join(RESULTS_DIR, entry);
    if (fs.statSync(full).isFile()) {
      fs.unlinkSync(full);
      removed++;
    }
  }
  ok(`Removed ${removed} stale result file(s)`);
}

// ─── Step 3: Write Allure meta-files ──────────────────────────────────────────
function writeMetaFiles() {
  header('Step 3 – Write Allure metadata');

  // executor.json – shown in the Allure executor widget
  const executor = {
    name: 'Daily API Run',
    type: 'local',
    buildName: `Run – ${RUN_DATE.split('T')[0]}`,
    buildOrder: Date.now(),   // monotonically increasing → correct sort in trend
    reportName: 'API Test Suite'
  };
  fs.writeFileSync(
    path.join(RESULTS_DIR, 'executor.json'),
    JSON.stringify(executor, null, 2)
  );
  ok('executor.json written');

  // environment.properties – shown in the Allure environment widget
  const envProps = [
    `BASE_URL=${process.env.BASE_URL || 'https://jsonplaceholder.typicode.com'}`,
    `Test_Environment=${process.env.TEST_ENV || 'local'}`,
    `Node_Version=${process.version}`,
    `Platform=${process.platform}`,
    `Run_Date=${RUN_DATE}`
  ].join('\n');
  fs.writeFileSync(path.join(RESULTS_DIR, 'environment.properties'), envProps);
  ok('environment.properties written');
}

// ─── Step 4: Run Mocha tests ───────────────────────────────────────────────────
function runTests() {
  header('Step 4 – Run tests');
  const start = Date.now();
  let passed = true;

  try {
    execSync('npx mocha', { stdio: 'inherit', cwd: ROOT });
  } catch {
    warn('One or more tests FAILED – report will still be generated');
    passed = false;
  }

  const elapsed = ((Date.now() - start) / 1000).toFixed(1);
  log(`   Finished in ${elapsed}s`);
  return { passed, elapsed };
}

// ─── Step 5: Generate HTML report ─────────────────────────────────────────────
function generateReport() {
  header('Step 5 – Generate Allure report');
  try {
    // --clean ensures a fresh HTML report; history is preserved via Step 1
    execSync(
      `npx allure generate ${RESULTS_DIR} -o ${REPORT_DIR} --clean`,
      { stdio: 'inherit', cwd: ROOT }
    );
    ok('HTML report generated → allure-report/');
    return true;
  } catch (err) {
    fail(`Failed to generate report: ${err.message}`);
    fail('Is allure-commandline installed? Run: npm install');
    return false;
  }
}

// ─── Step 6: Open report (optional) ───────────────────────────────────────────
function openReport() {
  if (!OPEN_REPORT) return;
  header('Step 6 – Open report');
  try {
    execSync(`npx allure open ${REPORT_DIR}`, { stdio: 'inherit', cwd: ROOT });
  } catch {
    warn('Could not auto-open report. Run: npm run report:open');
  }
}

// ─── Summary ──────────────────────────────────────────────────────────────────
function printSummary({ testResult, reportGenerated }) {
  header('Summary');
  log(`  Date        : ${new Date().toLocaleString()}`);
  log(`  Tests       : ${testResult.passed ? '✓ All passed' : '✗ Some failed'}`);
  log(`  Duration    : ${testResult.elapsed}s`);
  log(`  Report      : ${reportGenerated ? '✓ Generated' : '✗ Failed'}`);
  if (reportGenerated) {
    log(`  View report : npm run report:open`);
    log(`  Live serve  : npm run report:serve`);
  }
  log('');
  log('  Trend graphs show daily pass/fail rate, duration, and categories.');
  log('  They become richer after 3+ daily runs.');
  console.log('');
}

// ─── Main ─────────────────────────────────────────────────────────────────────
async function main() {
  console.log('\n' + '═'.repeat(60));
  console.log(`  API Testing Suite  –  Daily Run`);
  console.log(`  ${new Date().toLocaleString()}`);
  console.log('═'.repeat(60));

  preserveHistory();
  clearOldResults();
  writeMetaFiles();

  const testResult      = runTests();
  const reportGenerated = generateReport();
  openReport();
  printSummary({ testResult, reportGenerated });

  process.exit(testResult.passed ? 0 : 1);
}

main().catch((err) => {
  console.error('\nFatal error:', err);
  process.exit(1);
});
