'use strict';

module.exports = {
  // Test file discovery
  spec: 'test/specs/**/*.test.js',

  // Global hooks (must use --require for root hooks)
  require: [
    'dotenv/config',
    'test/hooks/root-hooks.js'
  ],

  // Allure reporter
  reporter: 'allure-mocha',
  reporterOptions: {
    resultsDir: 'allure-results',
    environmentInfo: {
      Node_Version: process.version,
      Platform: process.platform,
      Test_Environment: process.env.TEST_ENV || 'local'
    }
  },

  // Timeouts & retries
  timeout: 15000,
  retries: 1,

  // Parallel not used (keep test order deterministic for Allure steps)
  parallel: false,

  // Exit after all tests complete
  exit: true
};
