package com.tech.restAPI;

public enum RuleNamespace {
    LOAN,
    DEFAULT,
    INSURANCE
}
