#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
# Data Migration Script
# Simulates inserting records into a database in batches.
# The backend parses:
#   RUNNING_TOTAL: N   →  live counter updates during execution
#   RECORDS_INSERTED: N →  final confirmed count at the end
# ─────────────────────────────────────────────────────────────────────────────

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1"; }

log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
log "Starting Data Migration Script v1.0"
log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
sleep 0.5

log "Initializing environment variables..."
sleep 0.4
log "Loading configuration from /etc/migration.conf (simulated)..."
sleep 0.4
log "Configuration loaded successfully."

log "Connecting to source database (host: db-source.internal)..."
sleep 1
log "Source DB connection established. [postgres v15.3]"

log "Connecting to target database (host: db-target.internal)..."
sleep 0.8
log "Target DB connection established. [postgres v15.3]"

log "Running pre-migration checks..."
sleep 0.5
log "Schema validation: PASSED"
log "Constraint checks: PASSED"
log "Disk space check: PASSED (42.3 GB available)"

log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
log "Beginning data migration..."
log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

BATCHES=5
RECORDS_PER_BATCH=10
TOTAL=0

for batch in $(seq 1 $BATCHES); do
  log "▶ Processing batch $batch / $BATCHES  [table: orders_archive]"
  sleep 0.3

  for rec in $(seq 1 $RECORDS_PER_BATCH); do
    TOTAL=$((TOTAL + 1))
    RECORD_ID=$(printf "%06d" $TOTAL)
    log "  INSERT orders_archive → record #$RECORD_ID  (batch=$batch)"
    sleep 0.18
    # Emit running total so the frontend counter updates live
    echo "RUNNING_TOTAL: $TOTAL"
  done

  log "  Batch $batch committed to target DB. Subtotal: $TOTAL records."
  sleep 0.5
done

log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
log "Post-migration verification..."
sleep 0.8
log "Row count check   → source=$TOTAL  target=$TOTAL  ✓ MATCH"
log "Checksum verify   → SHA256 match on all rows      ✓ PASS"
log "Index rebuild     → Completed in 0.23 s"
log "Vacuum analyze    → Done"

log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
# Final record count signal — parsed by the backend
echo "RECORDS_INSERTED: $TOTAL"
log "Migration completed successfully. Total records inserted: $TOTAL"
log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
exit 0
