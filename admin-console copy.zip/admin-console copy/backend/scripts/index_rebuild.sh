#!/bin/bash
# Job: Index Rebuild — rebuilds stale/bloated DB indexes
log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1"; }

log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
log "JOB: Index Rebuild  v2.0.1"
log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
sleep 0.3

log "Connecting to postgres://db.internal:5432/main..."
sleep 0.5
log "Connection OK. Scanning for bloated indexes (threshold: 30%)..."
sleep 0.4
log "Found 30 indexes requiring rebuild."

TABLES=("orders" "users" "products" "inventory" "sessions" "audit_log" "payments" "shipments" "reviews" "categories")
IDX_PER_TABLE=3
TOTAL=0

log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
log "Rebuilding indexes CONCURRENTLY..."
log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

for tbl in "${TABLES[@]}"; do
  for i in $(seq 1 $IDX_PER_TABLE); do
    TOTAL=$((TOTAL + 1))
    IDX="idx_${tbl}_$(printf '%02d' $i)"
    OLD_SIZE=$(( RANDOM % 400 + 100 ))
    NEW_SIZE=$(( OLD_SIZE * 60 / 100 ))
    log "  REINDEX CONCURRENTLY $IDX  [${OLD_SIZE}MB → ${NEW_SIZE}MB, -$(( 100 - NEW_SIZE*100/OLD_SIZE ))%]"
    sleep 0.22
    echo "RUNNING_TOTAL: $TOTAL"
  done
done

log "Running VACUUM ANALYZE on affected tables..."
sleep 0.6
log "VACUUM complete. Dead tuples reclaimed."

echo "RECORDS_INSERTED: $TOTAL"
log "$TOTAL indexes rebuilt successfully."
log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
exit 0
