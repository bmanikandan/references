#!/bin/bash
# Job: S3 Asset Sync — syncs media/static assets to CDN bucket
log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1"; }

log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
log "JOB: S3 Asset Sync  v1.8.2"
log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
sleep 0.3

log "Source: assets.internal:/var/media"
log "Target: s3://cdn-assets-prod/media/"
log "Authenticating with AWS STS..."
sleep 0.5
log "Credentials OK  [TTL: 3600s]"
log "Computing diff between source and S3..."
sleep 0.6
log "Changes detected: 35 files to sync (12 new, 18 modified, 5 deleted)."

FOLDERS=("images/products" "images/banners" "images/avatars" "videos/promos" "docs/pdfs" "fonts/web" "icons/svg")
TOTAL=0

log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
log "Syncing folders..."
log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

for folder in "${FOLDERS[@]}"; do
  FILES=$(( RANDOM % 7 + 3 ))
  log "▶ $folder  ($FILES files)"
  sleep 0.2
  for f in $(seq 1 $FILES); do
    TOTAL=$((TOTAL + 1))
    SIZE=$(( RANDOM % 2000 + 50 ))
    log "  PUT $folder/asset_$(printf '%03d' $TOTAL).$([ $((RANDOM%2)) -eq 0 ] && echo 'jpg' || echo 'webp')  [${SIZE}KB]"
    sleep 0.18
    echo "RUNNING_TOTAL: $TOTAL"
  done
  log "  Folder '$folder' synced."
  sleep 0.25
done

log "Invalidating CloudFront distribution (EXXXXXXXX)..."
sleep 0.5
log "CDN invalidation submitted  ✓"

echo "RECORDS_INSERTED: $TOTAL"
log "$TOTAL assets synced to S3. CDN cache invalidated."
log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
exit 0
