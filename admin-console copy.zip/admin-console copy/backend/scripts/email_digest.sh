#!/bin/bash
# Job: Email Digest — sends daily digest emails via SES
log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1"; }

SEND_DATE=$(date '+%A, %B %-d %Y')

log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
log "JOB: Email Digest  v2.1.0"
log "Sending digest for: $SEND_DATE"
log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
sleep 0.3

log "Connecting to SES (us-east-1)..."
sleep 0.5
log "SES ready  [sending quota: 50,000/day, used: 12,430]"
log "Fetching subscriber list (digest_opt_in=true)..."
sleep 0.4
log "40 subscribers found."

SEGMENTS=("premium" "standard" "trial" "enterprise" "internal")
TOTAL=0

log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
log "Sending digest by segment..."
log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

for seg in "${SEGMENTS[@]}"; do
  COUNT=$(( RANDOM % 10 + 5 ))
  log "▶ Segment: $seg  ($COUNT recipients)"
  sleep 0.2
  for i in $(seq 1 $COUNT); do
    TOTAL=$((TOTAL + 1))
    MID="msg-$(printf '%06d' $TOTAL)@ses.amazonaws.com"
    log "  SES SendEmail → user_$(printf '%04d' $TOTAL)@example.com  [$MID]"
    sleep 0.12
    echo "RUNNING_TOTAL: $TOTAL"
  done
  log "  Segment '$seg': $COUNT emails queued."
  sleep 0.2
done

log "Updating send log in DB..."
sleep 0.3

echo "RECORDS_INSERTED: $TOTAL"
log "$TOTAL digest emails sent. Bounce/complaint tracking active."
log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
exit 0
