#!/bin/bash
# ─────────────────────────────────────────────────────
# Job: Cache Warm-up
# Pre-populates Redis with product catalog & pricing
# ─────────────────────────────────────────────────────
log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1"; }

log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
log "JOB: Cache Warm-up  v1.4.2"
log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
sleep 0.3

log "Connecting to Redis cluster (redis.internal:6379)..."
sleep 0.7
log "Redis connected  [v7.2  —  2.1 GB / 8 GB used  —  cluster: 3 nodes]"
log "Flushing stale product keys (prefix: products:*)..."
sleep 0.4
log "  Flushed 1,204 stale keys."

CATEGORIES=("electronics" "clothing" "books" "home-garden" "sports")
ITEMS_PER_CAT=8
TOTAL=0

log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
log "Loading product catalog by category..."
log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

for cat in "${CATEGORIES[@]}"; do
  log "▶ Category: $cat  ($ITEMS_PER_CAT items)"
  sleep 0.25
  for i in $(seq 1 $ITEMS_PER_CAT); do
    TOTAL=$((TOTAL + 1))
    SKU="SKU-$(printf '%04d' $TOTAL)"
    log "  HSET products:${cat}:${SKU}  {name, price, stock, imageUrl}"
    sleep 0.15
    echo "RUNNING_TOTAL: $TOTAL"
  done
  log "  Category '$cat' cached — $ITEMS_PER_CAT keys written."
  sleep 0.3
done

log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
log "Setting TTL on all product keys (86400s = 24h)..."
sleep 0.5
log "  TTL applied to $TOTAL keys."
log "Loading pricing rules (PRICESET:global)..."
sleep 0.4
log "  42 pricing rules cached."
log "Loading featured banners (BANNERS:homepage)..."
sleep 0.3
log "  8 banner entries cached."

log "Cache stats  →  total=$TOTAL keys  errors=0  hit-rate=0% (cold)"
echo "RECORDS_INSERTED: $TOTAL"
log "Cache warm-up completed successfully."
log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
exit 0
