#!/bin/bash
# Job: Log Archival — compresses & archives app logs older than 30d
log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1"; }

CUTOFF=$(date '+%Y-%m-%d')

log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
log "JOB: Log Archival  v1.5.0"
log "Archiving logs older than 30 days (cutoff: $CUTOFF)"
log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
sleep 0.3

log "Scanning /var/log/app for eligible files..."
sleep 0.5
log "Found 22 log files totaling 4.7 GB to archive."

SERVICES=("api-gateway" "auth-service" "user-service" "payment-service" "notification-service"
          "worker" "scheduler" "websocket" "metrics-exporter" "audit")
TOTAL=0
LOG_IDX=0

for svc in "${SERVICES[@]}"; do
  FILES=$(( RANDOM % 3 + 1 ))
  log "▶ $svc  ($FILES log files)"
  sleep 0.2
  for f in $(seq 1 $FILES); do
    TOTAL=$((TOTAL + 1))
    LOG_IDX=$((LOG_IDX + 1))
    SIZE=$(( RANDOM % 500 + 50 ))
    COMP=$(( SIZE * 15 / 100 ))
    log "  gzip ${svc}.$(date '+%Y%m').log  [${SIZE}MB → ${COMP}MB, -$(( 100 - COMP*100/SIZE ))%]"
    sleep 0.22
    log "  s3 cp ${svc}.$(date '+%Y%m').log.gz s3://log-archive/$(date '+%Y/%m')/"
    echo "RUNNING_TOTAL: $TOTAL"
    sleep 0.1
  done
  sleep 0.2
done

log "Removing local compressed copies..."
sleep 0.4
log "Updating retention index in DynamoDB..."
sleep 0.3

echo "RECORDS_INSERTED: $TOTAL"
log "$TOTAL log files archived to S3. Local copies removed."
log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
exit 0
