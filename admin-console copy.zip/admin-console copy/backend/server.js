const express = require('express');
const cors = require('cors');
const { spawn } = require('child_process');
const jwt = require('jsonwebtoken');
const path = require('path');
const fs = require('fs');
const os = require('os');

const app = express();
app.use(express.json());

const JWT_SECRET = 'admin-console-secret-2024';
const USERS = {
  admin:  { password: 'admin123', role: 'admin'  },
  viewer: { password: 'viewer123', role: 'viewer' },
};

// ── Jobs configuration (10 jobs) ─────────────────────────────────────────────
// rerunnable: true  → can be re-run even after completion
// rerunnable: false → runs exactly once (re-run blocked after completion)
const JOBS_CONFIG = [
  { id: 'schema-validation', name: 'Schema Validation',  description: 'Validate DB schema integrity, constraints, and index health.',      script: 'schema_validation.sh', icon: 'check-circle', rerunnable: true  },
  { id: 'data-migration',    name: 'Data Migration',     description: 'Migrate orders from legacy PostgreSQL schema to new tables.',        script: 'data_migration.sh',    icon: 'database',     rerunnable: false },
  { id: 'index-rebuild',     name: 'Index Rebuild',      description: 'Rebuild bloated DB indexes concurrently to reclaim space.',          script: 'index_rebuild.sh',     icon: 'layers',       rerunnable: true  },
  { id: 'cache-warmup',      name: 'Cache Warm-up',      description: 'Pre-populate Redis cache with product catalog and pricing rules.',   script: 'cache_warmup.sh',      icon: 'zap',          rerunnable: true  },
  { id: 'db-backup',         name: 'DB Backup',          description: 'Full pg_dump encrypted and uploaded to S3 backup bucket.',          script: 'db_backup.sh',         icon: 'archive',      rerunnable: false },
  { id: 'user-export',       name: 'User Data Export',   description: 'GDPR-compliant export of user records to encrypted ZIP archives.',   script: 'user_export.sh',       icon: 'users',        rerunnable: true  },
  { id: 's3-sync',           name: 'S3 Asset Sync',      description: 'Sync media and static assets to CDN bucket, invalidate CloudFront.', script: 's3_sync.sh',           icon: 'cloud',        rerunnable: true  },
  { id: 'log-archival',      name: 'Log Archival',       description: 'Compress and archive app logs older than 30 days to S3.',           script: 'log_archival.sh',      icon: 'file-text',    rerunnable: false },
  { id: 'email-digest',      name: 'Email Digest',       description: 'Send daily digest emails to opted-in subscribers via SES.',         script: 'email_digest.sh',      icon: 'mail',         rerunnable: true  },
  { id: 'report-gen',        name: 'Report Generation',  description: 'Generate monthly analytics reports and export CSV files to S3.',    script: 'report_gen.sh',        icon: 'bar-chart',    rerunnable: false },
];

// ── Runtime path resolution ───────────────────────────────────────────────────
// When packaged with `pkg`, process.pkg is defined.
// - state.json must be on the real FS (writable) → next to the binary
// - shell scripts must be extracted from snapshot to a real tmpdir (bash needs a real path)
// - frontend static files can be read directly from the pkg snapshot
const isPkg = typeof process.pkg !== 'undefined';

// Writable state file — lives next to the binary in pkg mode, or in __dirname in dev
const STATE_FILE = isPkg
  ? path.join(path.dirname(process.execPath), 'state.json')
  : path.join(__dirname, 'state.json');

// Shell scripts — must be real filesystem paths so bash can execute them
const SCRIPTS_DIR = isPkg
  ? path.join(os.tmpdir(), 'admin-console-scripts')
  : path.join(__dirname, 'scripts');

if (isPkg) {
  // Extract all scripts from the pkg snapshot to OS tmpdir at startup
  fs.mkdirSync(SCRIPTS_DIR, { recursive: true });
  for (const job of JOBS_CONFIG) {
    const src = path.join(__dirname, 'scripts', job.script);
    const dst = path.join(SCRIPTS_DIR, job.script);
    try {
      fs.writeFileSync(dst, fs.readFileSync(src));
      fs.chmodSync(dst, 0o755);
    } catch (e) {
      console.error(`[init] Failed to extract ${job.script}: ${e.message}`);
    }
  }
  console.log(`[init] Scripts extracted to ${SCRIPTS_DIR}`);
}

// CORS — only needed in dev (separate Vite server). In pkg mode everything is same-origin.
if (!isPkg) {
  app.use(cors({ origin: ['http://localhost:5173', 'http://127.0.0.1:5173', 'http://0.0.0.0:5173'] }));
}

// Serve built frontend from backend/public (populated by build.sh)
const FRONTEND_DIST = path.join(__dirname, 'public');
if (fs.existsSync(FRONTEND_DIST)) {
  app.use(express.static(FRONTEND_DIST));
}

// ── State helpers ─────────────────────────────────────────────────────────────
const defaultState = () => ({ status: 'idle', logs: [], recordsInserted: 0, startedAt: null, completedAt: null });

function loadState() {
  try {
    if (fs.existsSync(STATE_FILE)) {
      const raw = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
      if (JOBS_CONFIG.every(j => raw[j.id]?.status)) return raw;
    }
  } catch (e) { console.error('Could not load state:', e.message); }
  return {};
}

function saveState() {
  try { fs.writeFileSync(STATE_FILE, JSON.stringify(jobStates, null, 2)); }
  catch (e) { console.error('Could not save state:', e.message); }
}

const saved = loadState();
const jobStates = {};
JOBS_CONFIG.forEach(job => {
  jobStates[job.id] = saved[job.id] || defaultState();
  if (jobStates[job.id].status === 'running') {
    jobStates[job.id].status = 'failed';
    jobStates[job.id].logs.push({ timestamp: new Date().toISOString(), message: 'Server restarted during execution — marked as failed.', type: 'error' });
  }
});

// ── Auto-run queue state ──────────────────────────────────────────────────────
const autoRun = { active: false, queue: [], currentJobId: null, totalQueued: 0, doneCount: 0 };

// ── SSE ───────────────────────────────────────────────────────────────────────
const sseClients = new Set();
function broadcast(event) {
  const data = `data: ${JSON.stringify(event)}\n\n`;
  sseClients.forEach(c => { try { c.write(data); } catch (_) {} });
}
function broadcastAutoRun() {
  broadcast({ type: 'auto-run-status', active: autoRun.active, currentJobId: autoRun.currentJobId, totalQueued: autoRun.totalQueued, doneCount: autoRun.doneCount, remaining: autoRun.queue.length });
}

// ── Auth ──────────────────────────────────────────────────────────────────────
function auth(req, res, next) {
  const token = (req.headers.authorization || '').replace('Bearer ', '') || req.query.token;
  if (!token) return res.status(401).json({ error: 'Unauthorized' });
  try { req.user = jwt.verify(token, JWT_SECRET); next(); }
  catch { res.status(401).json({ error: 'Invalid or expired token' }); }
}

function requireAdmin(req, res, next) {
  if (req.user?.role !== 'admin') return res.status(403).json({ error: 'Admin access required' });
  next();
}

// ── Core job execution (shared by manual + auto-run) ─────────────────────────
function startAndSpawn(jobId, onClose) {
  jobStates[jobId] = { status: 'running', logs: [], recordsInserted: 0, startedAt: new Date().toISOString(), completedAt: null };
  saveState();
  broadcast({ type: 'job-status', jobId, state: jobStates[jobId] });

  const jobConfig = JOBS_CONFIG.find(j => j.id === jobId);
  const scriptPath = path.join(SCRIPTS_DIR, jobConfig.script);
  if (!isPkg) { try { fs.chmodSync(scriptPath, '755'); } catch (_) {} }

  const child = spawn('bash', [scriptPath], { cwd: SCRIPTS_DIR, env: { ...process.env } });

  function handleOutput(text, logType) {
    text.toString().split('\n').forEach(line => {
      const msg = line.trim();
      if (!msg) return;
      const entry = { timestamp: new Date().toISOString(), message: msg, type: logType };
      jobStates[jobId].logs.push(entry);
      broadcast({ type: 'job-log', jobId, entry });
      const run = msg.match(/RUNNING_TOTAL:\s*(\d+)/);
      if (run) { jobStates[jobId].recordsInserted = parseInt(run[1]); broadcast({ type: 'job-records', jobId, count: jobStates[jobId].recordsInserted }); }
      const fin = msg.match(/RECORDS_INSERTED:\s*(\d+)/);
      if (fin) { jobStates[jobId].recordsInserted = parseInt(fin[1]); broadcast({ type: 'job-records', jobId, count: jobStates[jobId].recordsInserted }); }
    });
    saveState();
  }

  child.stdout.on('data', d => handleOutput(d, 'info'));
  child.stderr.on('data', d => handleOutput(d, 'error'));

  child.on('close', code => {
    jobStates[jobId].status = code === 0 ? 'completed' : 'failed';
    jobStates[jobId].completedAt = new Date().toISOString();
    saveState();
    broadcast({ type: 'job-status', jobId, state: jobStates[jobId] });
    console.log(`[${jobId}] exited with code ${code}`);
    if (onClose) onClose(code);
  });

  child.on('error', err => {
    const entry = { timestamp: new Date().toISOString(), message: `Spawn error: ${err.message}`, type: 'error' };
    jobStates[jobId].logs.push(entry);
    jobStates[jobId].status = 'failed';
    jobStates[jobId].completedAt = new Date().toISOString();
    saveState();
    broadcast({ type: 'job-log', jobId, entry });
    broadcast({ type: 'job-status', jobId, state: jobStates[jobId] });
    if (onClose) onClose(1);
  });
}

// ── Auto-run queue processor ──────────────────────────────────────────────────
function processAutoRunQueue() {
  if (!autoRun.active || autoRun.queue.length === 0) {
    autoRun.active = false;
    autoRun.currentJobId = null;
    broadcastAutoRun();
    return;
  }

  const jobId = autoRun.queue.shift();
  const jobConfig = JOBS_CONFIG.find(j => j.id === jobId);

  if (!jobConfig || jobStates[jobId]?.status === 'running') {
    autoRun.doneCount++;
    broadcastAutoRun();
    setTimeout(processAutoRunQueue, 100);
    return;
  }

  autoRun.currentJobId = jobId;
  broadcastAutoRun();

  startAndSpawn(jobId, (_code) => {
    autoRun.doneCount++;
    broadcastAutoRun();
    setTimeout(processAutoRunQueue, 800);
  });
}

// ── Routes ────────────────────────────────────────────────────────────────────

app.post('/api/login', (req, res) => {
  const { username, password } = req.body || {};
  const user = USERS[username];
  if (user && user.password === password) {
    const token = jwt.sign({ username, role: user.role }, JWT_SECRET, { expiresIn: '24h' });
    return res.json({ token, username, role: user.role });
  }
  res.status(401).json({ error: 'Invalid username or password' });
});

app.get('/api/jobs', auth, (req, res) => {
  res.json(JOBS_CONFIG.map(j => ({ ...j, state: jobStates[j.id] })));
});

app.get('/api/stream', auth, (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders();
  res.write(`data: ${JSON.stringify({
    type: 'init',
    jobs: JOBS_CONFIG.map(j => ({ ...j, state: jobStates[j.id] })),
    autoRun: { active: autoRun.active, currentJobId: autoRun.currentJobId, totalQueued: autoRun.totalQueued, doneCount: autoRun.doneCount, remaining: autoRun.queue.length },
  })}\n\n`);
  const hb = setInterval(() => { try { res.write(': heartbeat\n\n'); } catch (_) {} }, 20000);
  sseClients.add(res);
  req.on('close', () => { clearInterval(hb); sseClients.delete(res); });
});

// Manual run — supports rerunnable jobs
app.post('/api/jobs/:jobId/run', auth, requireAdmin, (req, res) => {
  const { jobId } = req.params;
  const jobConfig = JOBS_CONFIG.find(j => j.id === jobId);
  if (!jobConfig) return res.status(404).json({ error: 'Job not found' });

  const st = jobStates[jobId];
  if (st.status === 'running') return res.status(409).json({ error: 'Job is already running' });
  if (st.status === 'completed' && !jobConfig.rerunnable)
    return res.status(409).json({ error: 'Job already completed and cannot be re-run' });

  res.json({ message: 'Job started' });
  startAndSpawn(jobId);
});

// Auto-run: sequential execution of all eligible jobs
app.post('/api/run-all', auth, requireAdmin, (req, res) => {
  if (autoRun.active) return res.status(409).json({ error: 'Auto-run is already in progress' });

  const { jobIds } = req.body || {};
  const candidateIds = jobIds || JOBS_CONFIG.map(j => j.id);

  const queue = candidateIds.filter(id => {
    const cfg = JOBS_CONFIG.find(j => j.id === id);
    if (!cfg) return false;
    const st = jobStates[id];
    if (st.status === 'running') return false;
    if (st.status === 'completed' && !cfg.rerunnable) return false;
    return true;
  });

  if (queue.length === 0)
    return res.status(400).json({ error: 'No eligible jobs to run (all are completed or running)' });

  autoRun.active = true;
  autoRun.queue = queue;
  autoRun.currentJobId = null;
  autoRun.totalQueued = queue.length;
  autoRun.doneCount = 0;

  res.json({ message: `Auto-run started: ${queue.length} jobs queued` });
  broadcastAutoRun();
  processAutoRunQueue();
});

// Stop auto-run (does not kill the currently running job — lets it finish)
app.post('/api/run-all/stop', auth, requireAdmin, (req, res) => {
  autoRun.active = false;
  autoRun.queue = [];
  broadcastAutoRun();
  res.json({ message: 'Auto-run stopped. Current job will finish.' });
});

// Reset a job (idle/completed/failed only)
app.post('/api/jobs/:jobId/reset', auth, requireAdmin, (req, res) => {
  const { jobId } = req.params;
  if (!jobStates[jobId]) return res.status(404).json({ error: 'Job not found' });
  if (jobStates[jobId].status === 'running') return res.status(409).json({ error: 'Cannot reset a running job' });
  jobStates[jobId] = defaultState();
  saveState();
  broadcast({ type: 'job-status', jobId, state: jobStates[jobId] });
  res.json({ message: `Job ${jobId} reset` });
});

// SPA catch-all — must be after all /api routes
if (fs.existsSync(FRONTEND_DIST)) {
  app.get('*', (_req, res) => res.sendFile(path.join(FRONTEND_DIST, 'index.html')));
}

const PORT = process.env.PORT || 3001;
app.listen(PORT, '0.0.0.0', () => {
  if (isPkg) {
    console.log(`Admin Console → http://localhost:${PORT}`);
    console.log(`State file    → ${STATE_FILE}`);
    console.log(`Scripts dir   → ${SCRIPTS_DIR}`);
  } else {
    console.log(`Admin Console Backend → http://localhost:${PORT}`);
  }
});
