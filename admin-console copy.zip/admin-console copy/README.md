# Admin Console

A full-stack web admin console for running and monitoring shell script jobs in real time.

## Features

- JWT-based login with **admin** and **viewer** roles
- 10 configurable jobs with real-time log streaming (SSE)
- Sequential auto-run queue with stop support
- Re-runnable and run-once job policies
- PDF export of job run status report
- Live record count and duration tracking per job

## Prerequisites

- [Node.js](https://nodejs.org/) v18 or later
- npm v9 or later

---

## Project Structure

```
admin-console/
├── backend/
│   ├── server.js          # Express API server
│   ├── package.json
│   └── scripts/           # 10 shell scripts executed by jobs
│       ├── data_migration.sh
│       ├── cache_warmup.sh
│       ├── report_gen.sh
│       ├── schema_validation.sh
│       ├── index_rebuild.sh
│       ├── db_backup.sh
│       ├── user_export.sh
│       ├── s3_sync.sh
│       ├── log_archival.sh
│       └── email_digest.sh
└── frontend/
    ├── src/
    │   ├── App.jsx
    │   └── components/
    │       ├── Login.jsx
    │       └── AdminConsole.jsx
    ├── index.html
    ├── vite.config.js
    └── package.json
```

---

## Running the Backend

```bash
cd admin-console/backend
npm install
node server.js
```

The backend starts on **http://localhost:3001**.

### Backend environment

| Variable | Default | Description |
|---|---|---|
| `PORT` | `3001` | HTTP port |

State is persisted to `backend/state.json` between restarts. Delete it to reset all job states.

---

## Running the Frontend

```bash
cd admin-console/frontend
npm install
npm run dev
```

The dev server starts on **http://localhost:5173**.

> Both backend and frontend must be running at the same time. The frontend proxies all `/api` requests to the backend on port 3001.

---

## Login Credentials

| Role | Username | Password | Permissions |
|---|---|---|---|
| Admin | `admin` | `admin123` | View + run jobs, export PDF |
| Viewer | `viewer` | `viewer123` | View job status and logs only |

---

## Building a Self-Contained Native Binary

Run the single build script from the `admin-console/` directory:

```bash
chmod +x build.sh
./build.sh
```

This will:
1. Build the React frontend with Vite (`frontend/dist/`)
2. Copy the frontend build into `backend/public/`
3. Package everything (backend + frontend + shell scripts + Node.js runtime) into two binaries:

| File | Runs on |
|---|---|
| `backend/dist/admin-console-arm64` | Apple Silicon (M1/M2/M3) |
| `backend/dist/admin-console-x64` | Intel Mac |

> **First run** downloads ~80 MB of precompiled Node.js base binaries (cached at `~/.pkg-cache`). Subsequent builds are fast.

### Running the binary

```bash
# Apple Silicon
./backend/dist/admin-console-arm64

# Intel
./backend/dist/admin-console-x64
```

Then open **http://localhost:3001** in your browser. No Node.js installation required.

`state.json` (job run history) is saved next to the binary and persists across restarts.

### Custom port

```bash
PORT=8080 ./backend/dist/admin-console-arm64
```

---

## Building for Development (with hot reload)

```bash
cd admin-console/frontend
npm run build
```

The compiled static files are output to `frontend/dist/`. Serve them with any static file server or configure Express to serve them directly.

---

## API Endpoints

| Method | Path | Auth | Description |
|---|---|---|---|
| `POST` | `/api/login` | — | Authenticate, returns JWT |
| `GET` | `/api/jobs` | Any | List all jobs with current state |
| `GET` | `/api/stream` | Any | SSE stream for real-time updates |
| `POST` | `/api/jobs/:id/run` | Admin | Start a specific job |
| `POST` | `/api/run-all` | Admin | Start sequential auto-run |
| `POST` | `/api/run-all/stop` | Admin | Stop the auto-run queue |
| `POST` | `/api/jobs/:id/reset` | Admin | Reset a job to idle state |
