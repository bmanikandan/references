#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# build.sh — Produce a self-contained native binary of Admin Console
#
# Output: backend/dist/admin-console-x64  (Intel Mac)
#         backend/dist/admin-console-arm64 (Apple Silicon)
#
# Requirements: Node.js 18+ and npm must be installed to build.
# The resulting binary runs WITHOUT Node.js.
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
FRONTEND_DIR="$SCRIPT_DIR/frontend"
BACKEND_DIR="$SCRIPT_DIR/backend"
DIST_DIR="$BACKEND_DIR/dist"

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Admin Console — Native Binary Build"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# ── Step 1: Build the React frontend ─────────────────────────────────────────
echo ""
echo "[1/4] Installing frontend dependencies..."
cd "$FRONTEND_DIR"
npm install --silent

echo "[2/4] Building frontend (Vite)..."
npm run build

# ── Step 2: Copy frontend dist into backend/public ───────────────────────────
echo "[3/4] Copying frontend build → backend/public..."
rm -rf "$BACKEND_DIR/public"
cp -r "$FRONTEND_DIR/dist" "$BACKEND_DIR/public"

# ── Step 3: Package binary with pkg ──────────────────────────────────────────
echo "[4/4] Packaging binary (this downloads ~80 MB Node.js base on first run)..."
cd "$BACKEND_DIR"
npm install --silent

mkdir -p "$DIST_DIR"

# Detect current architecture to build the matching binary first
ARCH=$(uname -m)
if [ "$ARCH" = "arm64" ]; then
  PRIMARY_TARGET="node18-macos-arm64"
  PRIMARY_OUT="$DIST_DIR/admin-console-arm64"
  OTHER_TARGET="node18-macos-x64"
  OTHER_OUT="$DIST_DIR/admin-console-x64"
else
  PRIMARY_TARGET="node18-macos-x64"
  PRIMARY_OUT="$DIST_DIR/admin-console-x64"
  OTHER_TARGET="node18-macos-arm64"
  OTHER_OUT="$DIST_DIR/admin-console-arm64"
fi

echo "  → Building for current arch ($ARCH)..."
npx pkg . --target "$PRIMARY_TARGET" --output "$PRIMARY_OUT" --compress GZip

echo "  → Building for other arch..."
npx pkg . --target "$OTHER_TARGET" --output "$OTHER_OUT" --compress GZip

# ── Done ─────────────────────────────────────────────────────────────────────
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  ✓ Build complete!"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
ls -lh "$DIST_DIR"
echo ""
echo "  Run on Apple Silicon:  ./backend/dist/admin-console-arm64"
echo "  Run on Intel Mac:      ./backend/dist/admin-console-x64"
echo ""
echo "  Then open http://localhost:3001 in your browser."
echo ""
echo "  The binary is fully self-contained — no Node.js required."
echo "  state.json (job run history) is saved next to the binary."
