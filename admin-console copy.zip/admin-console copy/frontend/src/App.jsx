import { useState, useEffect } from 'react';
import Login from './components/Login.jsx';
import AdminConsole from './components/AdminConsole.jsx';

export default function App() {
  const [authData, setAuthData] = useState(null);

  useEffect(() => {
    const token = localStorage.getItem('ac_token');
    const username = localStorage.getItem('ac_username');
    const role = localStorage.getItem('ac_role');
    if (token && username) setAuthData({ token, username, role: role || 'admin' });
  }, []);

  const handleLogin = (data) => {
    localStorage.setItem('ac_token', data.token);
    localStorage.setItem('ac_username', data.username);
    localStorage.setItem('ac_role', data.role);
    setAuthData(data);
  };

  const handleLogout = () => {
    localStorage.removeItem('ac_token');
    localStorage.removeItem('ac_username');
    localStorage.removeItem('ac_role');
    setAuthData(null);
  };

  return authData
    ? <AdminConsole authData={authData} onLogout={handleLogout} />
    : <Login onLogin={handleLogin} />;
}
