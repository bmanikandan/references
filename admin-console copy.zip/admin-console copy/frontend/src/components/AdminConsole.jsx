import { useState, useEffect, useRef, useCallback } from 'react';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

// ── Status config ─────────────────────────────────────────────────────────────
const STATUS = {
  idle:      { label: 'Ready',     color: '#64748b', bg: '#f8fafc', border: '#e2e8f0', dot: '#94a3b8',  pill: '#f1f5f9' },
  running:   { label: 'Running',   color: '#d97706', bg: '#fffbeb', border: '#fde68a', dot: '#f59e0b',  pill: '#fef3c7' },
  completed: { label: 'Completed', color: '#059669', bg: '#ecfdf5', border: '#6ee7b7', dot: '#10b981',  pill: '#d1fae5' },
  failed:    { label: 'Failed',    color: '#dc2626', bg: '#fef2f2', border: '#fca5a5', dot: '#ef4444',  pill: '#fee2e2' },
};

// ── SVG icons map ─────────────────────────────────────────────────────────────
function Icon({ name, size = 16 }) {
  const p = { fill: 'none', stroke: 'currentColor', strokeWidth: 2, strokeLinecap: 'round', strokeLinejoin: 'round' };
  const paths = {
    'check-circle': <><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></>,
    'database':     <><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/></>,
    'layers':       <><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></>,
    'zap':          <><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></>,
    'archive':      <><polyline points="21 8 21 21 3 21 3 8"/><rect x="1" y="3" width="22" height="5"/><line x1="10" y1="12" x2="14" y2="12"/></>,
    'users':        <><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></>,
    'cloud':        <><path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"/></>,
    'file-text':    <><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></>,
    'mail':         <><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></>,
    'bar-chart':    <><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/><line x1="2" y1="20" x2="22" y2="20"/></>,
    'play':         <><polygon points="5 3 19 12 5 21 5 3"/></>,
    'stop-circle':  <><circle cx="12" cy="12" r="10"/><rect x="9" y="9" width="6" height="6"/></>,
    'refresh-cw':   <><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></>,
  };
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" {...p} style={{ flexShrink: 0 }}>
      {paths[name] || null}
    </svg>
  );
}

// ── Helpers ───────────────────────────────────────────────────────────────────
const fmtTime = iso => iso ? new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : '—';
const fmtDur  = (start, end) => {
  if (!start) return '—';
  const s = Math.floor(((end ? new Date(end) : new Date()) - new Date(start)) / 1000);
  return s < 60 ? `${s}s` : `${Math.floor(s / 60)}m ${s % 60}s`;
};

// ── Main component ────────────────────────────────────────────────────────────
export default function AdminConsole({ authData, onLogout }) {
  const isAdmin = authData.role === 'admin';
  const [jobs, setJobs] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [jobErrors, setJobErrors] = useState({});
  const [jobStarting, setJobStarting] = useState({});
  const [autoRun, setAutoRun] = useState({ active: false, currentJobId: null, totalQueued: 0, doneCount: 0, remaining: 0 });
  const [autoRunError, setAutoRunError] = useState('');
  const [, setTick] = useState(0);
  const logsRef = useRef(null);

  // ── SSE ───────────────────────────────────────────────────────────────────
  useEffect(() => {
    const es = new EventSource(`/api/stream?token=${authData.token}`);
    es.onmessage = e => {
      const msg = JSON.parse(e.data);
      if (msg.type === 'init') {
        setJobs(msg.jobs);
        setAutoRun(msg.autoRun || {});
        const first = msg.jobs[0];
        if (first) setSelectedId(id => id || first.id);
      } else if (msg.type === 'job-status') {
        setJobs(prev => prev.map(j => j.id === msg.jobId ? { ...j, state: msg.state } : j));
      } else if (msg.type === 'job-log') {
        setJobs(prev => prev.map(j =>
          j.id === msg.jobId ? { ...j, state: { ...j.state, logs: [...j.state.logs, msg.entry] } } : j
        ));
      } else if (msg.type === 'job-records') {
        setJobs(prev => prev.map(j =>
          j.id === msg.jobId ? { ...j, state: { ...j.state, recordsInserted: msg.count } } : j
        ));
      } else if (msg.type === 'auto-run-status') {
        setAutoRun({ active: msg.active, currentJobId: msg.currentJobId, totalQueued: msg.totalQueued, doneCount: msg.doneCount, remaining: msg.remaining });
        // Auto-select the currently running job in the console
        if (msg.currentJobId) setSelectedId(msg.currentJobId);
      }
    };
    return () => es.close();
  }, [authData.token]);

  // ── Live duration tick ────────────────────────────────────────────────────
  useEffect(() => {
    const id = setInterval(() => setTick(t => t + 1), 1000);
    return () => clearInterval(id);
  }, []);

  // ── Auto-scroll console ───────────────────────────────────────────────────
  useEffect(() => {
    if (logsRef.current) logsRef.current.scrollTop = logsRef.current.scrollHeight;
  }, [jobs, selectedId]);

  // ── Manual run ────────────────────────────────────────────────────────────
  const runJob = useCallback(async jobId => {
    setJobErrors(e => ({ ...e, [jobId]: '' }));
    setJobStarting(s => ({ ...s, [jobId]: true }));
    setSelectedId(jobId);
    try {
      const res = await fetch(`/api/jobs/${jobId}/run`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${authData.token}` },
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to start job');
    } catch (err) {
      setJobErrors(e => ({ ...e, [jobId]: err.message }));
    } finally {
      setJobStarting(s => ({ ...s, [jobId]: false }));
    }
  }, [authData.token]);

  // ── Auto-run all ──────────────────────────────────────────────────────────
  const runAll = useCallback(async () => {
    setAutoRunError('');
    try {
      const res = await fetch('/api/run-all', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${authData.token}` },
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to start auto-run');
    } catch (err) {
      setAutoRunError(err.message);
    }
  }, [authData.token]);

  const stopAutoRun = useCallback(async () => {
    await fetch('/api/run-all/stop', {
      method: 'POST',
      headers: { Authorization: `Bearer ${authData.token}` },
    });
  }, [authData.token]);

  // ── PDF Export ────────────────────────────────────────────────────────────
  const exportPDF = useCallback(() => {
    const doc = new jsPDF({ orientation: 'landscape', unit: 'pt', format: 'a4' });
    const pageW = doc.internal.pageSize.getWidth();
    const now = new Date();
    const ts = now.toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' });

    // Header band
    doc.setFillColor(37, 99, 235);
    doc.rect(0, 0, pageW, 52, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(16);
    doc.text('Admin Console — Job Execution Report', 36, 28);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.text(`Generated: ${ts}   ·   User: ${authData.username} (${authData.role})`, 36, 44);

    // Summary row
    const total     = jobs.length;
    const completed = jobs.filter(j => j.state.status === 'completed').length;
    const failed    = jobs.filter(j => j.state.status === 'failed').length;
    const running   = jobs.filter(j => j.state.status === 'running').length;
    const idle      = jobs.filter(j => j.state.status === 'idle').length;
    const totalRecs = jobs.reduce((a, j) => a + (j.state.recordsInserted || 0), 0);

    const summaryY = 68;
    const pills = [
      { label: 'Total Jobs',      value: total,     color: [37, 99, 235] },
      { label: 'Completed',       value: completed, color: [5, 150, 105] },
      { label: 'Failed',          value: failed,    color: [220, 38, 38]  },
      { label: 'Running / Idle',  value: `${running} / ${idle}`, color: [100, 116, 139] },
      { label: 'Total Records',   value: totalRecs.toLocaleString(), color: [124, 58, 237] },
    ];
    const pillW = (pageW - 72) / pills.length;
    pills.forEach(({ label, value, color }, i) => {
      const x = 36 + i * (pillW + 6);
      doc.setFillColor(color[0], color[1], color[2], 0.08);
      doc.setDrawColor(...color);
      doc.setLineWidth(0.5);
      doc.roundedRect(x, summaryY, pillW, 36, 4, 4, 'FD');
      doc.setTextColor(...color);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(14);
      doc.text(String(value), x + pillW / 2, summaryY + 17, { align: 'center' });
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7.5);
      doc.text(label, x + pillW / 2, summaryY + 29, { align: 'center' });
    });

    // Table
    const rows = jobs.map(job => {
      const st = job.state;
      const dur = st.startedAt
        ? (() => {
            const sec = Math.floor(((st.completedAt ? new Date(st.completedAt) : new Date()) - new Date(st.startedAt)) / 1000);
            return sec < 60 ? `${sec}s` : `${Math.floor(sec / 60)}m ${sec % 60}s`;
          })()
        : '—';
      // Extract failure reason from last error log line, if any
      const failLog = st.status === 'failed'
        ? [...st.logs].reverse().find(l => l.type === 'error')?.message || 'Script exited with non-zero code'
        : '';
      return [
        job.name,
        st.status.charAt(0).toUpperCase() + st.status.slice(1),
        st.recordsInserted?.toLocaleString() ?? '0',
        dur,
        failLog || '—',
      ];
    });

    autoTable(doc, {
      startY: summaryY + 48,
      head: [['Job Name', 'Status', 'Records', 'Duration', 'Failure Reason']],
      body: rows,
      styles:       { fontSize: 9, cellPadding: { top: 6, bottom: 6, left: 8, right: 8 }, overflow: 'linebreak' },
      headStyles:   { fillColor: [15, 23, 42], textColor: 255, fontStyle: 'bold', fontSize: 9 },
      columnStyles: {
        0: { cellWidth: 150 },
        1: { cellWidth: 72,  halign: 'center' },
        2: { cellWidth: 70,  halign: 'right'  },
        3: { cellWidth: 70,  halign: 'right'  },
        4: { cellWidth: 'auto' },
      },
      alternateRowStyles: { fillColor: [248, 250, 252] },
      didParseCell(data) {
        if (data.section === 'body' && data.column.index === 1) {
          const v = data.cell.raw;
          if (v === 'Completed') data.cell.styles.textColor = [5, 150, 105];
          else if (v === 'Failed')    data.cell.styles.textColor = [220, 38, 38];
          else if (v === 'Running')   data.cell.styles.textColor = [217, 119, 6];
          else                        data.cell.styles.textColor = [100, 116, 139];
        }
      },
    });

    // Footer
    const footerY = doc.internal.pageSize.getHeight() - 18;
    doc.setDrawColor(226, 232, 240);
    doc.setLineWidth(0.5);
    doc.line(36, footerY - 6, pageW - 36, footerY - 6);
    doc.setTextColor(148, 163, 184);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.text('Admin Console · Confidential', 36, footerY);
    doc.text(`Page 1`, pageW - 36, footerY, { align: 'right' });

    doc.save(`job-report-${now.toISOString().slice(0, 10)}.pdf`);
  }, [jobs, authData]);

  // ── Derived stats ─────────────────────────────────────────────────────────
  const stats = {
    total:     jobs.length,
    idle:      jobs.filter(j => j.state.status === 'idle').length,
    running:   jobs.filter(j => j.state.status === 'running').length,
    completed: jobs.filter(j => j.state.status === 'completed').length,
    failed:    jobs.filter(j => j.state.status === 'failed').length,
  };

  const selectedJob = jobs.find(j => j.id === selectedId);
  const autoRunProgress = autoRun.totalQueued > 0 ? Math.round((autoRun.doneCount / autoRun.totalQueued) * 100) : 0;
  const autoRunCurrentJob = jobs.find(j => j.id === autoRun.currentJobId);

  return (
    <div style={s.shell}>
      {/* ── Header ──────────────────────────────────────────────────────── */}
      <header style={s.header}>
        <div style={s.headerLeft}>
          <div style={s.headerLogo}>
            <Icon name="database" size={18} />
          </div>
          <div>
            <div style={s.headerTitle}>Admin Console</div>
            <div style={s.headerSub}>Job Execution &amp; Monitoring</div>
          </div>
        </div>
        <div style={s.headerRight}>
          <button onClick={exportPDF} style={s.exportBtn} title="Export run status as PDF">
            <Icon name="file-text" size={14} />
            Export PDF
          </button>
          <div style={s.userChip}>
            <span style={s.onlineDot} />
            {authData.username}
            <span style={{ ...s.roleBadge, ...(isAdmin ? s.roleBadgeAdmin : s.roleBadgeViewer) }}>
              {authData.role}
            </span>
          </div>
          <button onClick={onLogout} style={s.logoutBtn}>Sign Out</button>
        </div>
      </header>

      <main style={s.main}>

        {/* ── Summary ───────────────────────────────────────────────────── */}
        <div style={s.summaryRow}>
          {[
            { label: 'Total',     value: stats.total,     color: '#2563eb', bg: '#eff6ff', border: '#bfdbfe' },
            { label: 'Idle',      value: stats.idle,      color: '#64748b', bg: '#f8fafc', border: '#e2e8f0' },
            { label: 'Running',   value: stats.running,   color: '#d97706', bg: '#fffbeb', border: '#fde68a' },
            { label: 'Completed', value: stats.completed, color: '#059669', bg: '#ecfdf5', border: '#6ee7b7' },
            { label: 'Failed',    value: stats.failed,    color: '#dc2626', bg: '#fef2f2', border: '#fca5a5' },
          ].map(({ label, value, color, bg, border }) => (
            <div key={label} style={{ ...s.summaryCard, background: bg, borderColor: border }}>
              <div style={{ ...s.summaryValue, color }}>{value}</div>
              <div style={{ ...s.summaryLabel, color }}>{label}</div>
            </div>
          ))}
        </div>

        {/* ── Auto-run control bar ──────────────────────────────────────── */}
        <div style={s.controlBar}>
          <div style={s.controlLeft}>
            <span style={s.controlTitle}>Jobs ({jobs.length})</span>
            <span style={s.controlHint}>
              {jobs.filter(j => j.rerunnable).length} re-runnable &middot; {jobs.filter(j => !j.rerunnable).length} run-once
            </span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            {autoRunError && <span style={s.autoRunErr}>{autoRunError}</span>}
            {isAdmin && (autoRun.active ? (
              <button onClick={stopAutoRun} style={s.stopBtn}>
                <Icon name="stop-circle" size={14} />
                Stop Auto-Run
              </button>
            ) : (
              <button onClick={runAll} style={s.runAllBtn}>
                <Icon name="play" size={14} />
                Run All (Sequential)
              </button>
            ))}
          </div>
        </div>

        {/* ── Auto-run progress banner ──────────────────────────────────── */}
        {autoRun.active && (
          <div style={s.autoRunBanner}>
            <div style={s.autoRunLeft}>
              <BtnSpinner color="#d97706" />
              <div>
                <div style={s.autoRunTitle}>
                  Auto-running job {autoRun.doneCount + 1} of {autoRun.totalQueued}
                  {autoRunCurrentJob && <> — <strong>{autoRunCurrentJob.name}</strong></>}
                </div>
                <div style={s.autoRunSub}>{autoRun.remaining} job{autoRun.remaining !== 1 ? 's' : ''} remaining in queue</div>
              </div>
            </div>
            <div style={s.progressWrap}>
              <div style={s.progressTrack}>
                <div style={{ ...s.progressFill, width: `${autoRunProgress}%` }} />
              </div>
              <span style={s.progressLabel}>{autoRunProgress}%</span>
            </div>
          </div>
        )}

        {/* ── Job cards grid (5 columns) ────────────────────────────────── */}
        <div style={s.jobsGrid}>
          {jobs.map(job => (
            <JobCard
              key={job.id}
              job={job}
              isSelected={job.id === selectedId}
              isAutoRunCurrent={job.id === autoRun.currentJobId}
              error={jobErrors[job.id]}
              starting={jobStarting[job.id]}
              isAdmin={isAdmin}
              onSelect={() => setSelectedId(job.id)}
              onRun={() => runJob(job.id)}
            />
          ))}
        </div>

        {/* ── Console ───────────────────────────────────────────────────── */}
        {selectedJob && (
          <section style={{ animation: 'slide-down 0.2s ease' }}>
            <div style={s.consoleSectionHeader}>
              <h2 style={s.sectionTitle}>
                Console — <span style={{ color: '#2563eb' }}>{selectedJob.name}</span>
              </h2>
              <div style={{ display: 'flex', gap: 6 }}>
                {jobs.map(j => (
                  <button
                    key={j.id}
                    onClick={() => setSelectedId(j.id)}
                    title={j.name}
                    style={{
                      ...s.consoleTab,
                      background: j.id === selectedId ? '#2563eb' : '#ffffff',
                      color:      j.id === selectedId ? '#ffffff'  : '#64748b',
                      borderColor: j.id === selectedId ? '#2563eb' : '#e2e8f0',
                    }}
                  >
                    <span style={{
                      width: 6, height: 6, borderRadius: '50%', flexShrink: 0,
                      background: STATUS[j.state.status]?.dot || '#94a3b8',
                      animation: j.state.status === 'running' ? 'pulse-dot 1s ease-in-out infinite' : 'none',
                    }} />
                    {j.name.split(' ')[0]}
                  </button>
                ))}
              </div>
            </div>
            <JobConsole job={selectedJob} logsRef={logsRef} />
          </section>
        )}
      </main>
    </div>
  );
}

// ── Job Card ──────────────────────────────────────────────────────────────────
function JobCard({ job, isSelected, isAutoRunCurrent, error, starting, isAdmin, onSelect, onRun }) {
  const cfg = STATUS[job.state.status] || STATUS.idle;
  const isRunning   = job.state.status === 'running';
  const isCompleted = job.state.status === 'completed';
  const isFailed    = job.state.status === 'failed';
  const canRerun    = job.rerunnable && isCompleted;
  const canRun      = (job.state.status === 'idle' || canRerun || isFailed) && !starting && !isRunning;

  return (
    <div
      onClick={onSelect}
      style={{
        ...s.jobCard,
        borderColor: isAutoRunCurrent ? '#d97706'
                   : isSelected       ? '#2563eb'
                   : '#e2e8f0',
        boxShadow: isAutoRunCurrent
          ? '0 0 0 3px rgba(217,119,6,0.15), 0 2px 8px rgba(15,23,42,0.06)'
          : isSelected
          ? '0 0 0 3px rgba(37,99,235,0.1), 0 2px 8px rgba(15,23,42,0.06)'
          : '0 1px 4px rgba(15,23,42,0.04)',
        cursor: 'pointer',
      }}
    >
      {/* Header */}
      <div style={s.cardTop}>
        <div style={{ ...s.cardIcon, background: cfg.bg, border: `1px solid ${cfg.border}`, color: cfg.color }}>
          <Icon name={job.icon} size={16} />
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={s.cardName} title={job.name}>{job.name}</div>
          <StatusBadge status={job.state.status} />
        </div>
        {job.rerunnable && (
          <span title="Re-runnable" style={s.rerunnablePill}>↺</span>
        )}
      </div>

      {/* Metrics */}
      <div style={s.cardMetrics}>
        <Metric label="Records" value={job.state.recordsInserted.toLocaleString()} highlight={isCompleted} />
        <div style={s.metricDiv} />
        <Metric label="Duration" value={job.state.status !== 'idle' ? fmtDur(job.state.startedAt, job.state.completedAt) : '—'} />
      </div>

      {error && <div style={s.cardError}>{error}</div>}

      {/* Actions */}
      <div style={s.cardActions} onClick={e => e.stopPropagation()}>
        {isAdmin ? (
          <button
            onClick={() => canRun && onRun()}
            disabled={!canRun}
            style={{
              ...s.runBtn,
              ...(isRunning   ? s.runBtnRunning  : {}),
              ...(isCompleted && !canRerun ? s.runBtnDone : {}),
              ...(canRerun    ? s.runBtnRerun  : {}),
              ...(isFailed    ? s.runBtnFailed : {}),
              opacity: canRun || isRunning ? 1 : 0.55,
              cursor: canRun ? 'pointer' : 'not-allowed',
              width: '100%',
            }}
          >
            {starting             && <><BtnSpinner />Starting…</>}
            {!starting && isRunning   && <><BtnSpinner color="#d97706" />Running…</>}
            {!starting && isCompleted && !canRerun && <>&#10003; Done</>}
            {!starting && canRerun    && <><Icon name="refresh-cw" size={12} />&nbsp;Re-run</>}
            {!starting && isFailed    && <>&#9888; Retry</>}
            {!starting && job.state.status === 'idle' && <><Icon name="play" size={12} />&nbsp;Run Job</>}
          </button>
        ) : (
          <div style={s.viewerStatusRow}>
            {isRunning   && <><BtnSpinner color="#d97706" /><span style={{ color: '#d97706', fontSize: 11, fontWeight: 600 }}>Running…</span></>}
            {isCompleted && <span style={{ color: '#059669', fontSize: 11, fontWeight: 600 }}>&#10003; Done</span>}
            {isFailed    && <span style={{ color: '#dc2626', fontSize: 11, fontWeight: 600 }}>&#9888; Failed</span>}
            {job.state.status === 'idle' && <span style={{ color: '#94a3b8', fontSize: 11 }}>Idle</span>}
          </div>
        )}
      </div>
    </div>
  );
}

function Metric({ label, value, highlight }) {
  return (
    <div style={{ flex: 1, minWidth: 0 }}>
      <div style={s.metricLabel}>{label}</div>
      <div style={{ ...s.metricValue, color: highlight ? '#059669' : '#0f172a' }}>{value}</div>
    </div>
  );
}

function StatusBadge({ status }) {
  const cfg = STATUS[status] || STATUS.idle;
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, background: cfg.pill, color: cfg.color, borderRadius: 20, padding: '2px 8px', fontSize: 10, fontWeight: 600, marginTop: 3 }}>
      <span style={{ width: 5, height: 5, borderRadius: '50%', background: cfg.dot, flexShrink: 0, animation: status === 'running' ? 'pulse-dot 1.1s ease-in-out infinite' : 'none' }} />
      {cfg.label}
    </span>
  );
}

// ── Console ───────────────────────────────────────────────────────────────────
function JobConsole({ job, logsRef }) {
  const isRunning = job.state.status === 'running';
  return (
    <div style={s.console}>
      <div style={s.consoleBar}>
        <div style={s.macDots}>
          <span style={{ ...s.macDot, background: '#f87171' }} />
          <span style={{ ...s.macDot, background: '#fbbf24' }} />
          <span style={{ ...s.macDot, background: '#34d399' }} />
        </div>
        <span style={s.consoleBarTitle}>bash — {job.id}.sh</span>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, flexShrink: 0 }}>
          {isRunning && (
            <span style={s.liveChip}>
              <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#f59e0b', animation: 'pulse-dot 1s ease-in-out infinite' }} />
              LIVE
            </span>
          )}
          <span style={s.lineCount}>{job.state.logs.length} lines</span>
        </div>
      </div>
      <div ref={logsRef} className="console-body" style={s.consoleBody}>
        {job.state.logs.length === 0 ? (
          <div style={{ padding: '0 16px', color: '#334155', fontFamily: 'JetBrains Mono, monospace', fontSize: 12 }}>
            <span style={{ color: '#60a5fa' }}>admin@console</span>
            <span style={{ color: '#475569' }}>:~$ </span>
            <span style={{ color: '#475569' }}>{job.state.status === 'idle' ? 'Waiting for job execution…' : 'Loading…'}</span>
          </div>
        ) : (
          job.state.logs.map((log, i) => <LogLine key={i} log={log} index={i} />)
        )}
      </div>
    </div>
  );
}

function LogLine({ log, index }) {
  const isErr    = log.type === 'error';
  const isMeta   = /RECORDS_INSERTED:|RUNNING_TOTAL:/.test(log.message);
  const isHeader = log.message.includes('━');
  const color = isErr ? '#f87171' : isMeta ? '#fbbf24' : isHeader ? '#60a5fa' : '#86efac';
  return (
    <div style={{
      display: 'flex', alignItems: 'baseline', gap: 8, padding: '1px 16px',
      background: isErr ? 'rgba(248,113,113,0.07)' : isHeader ? 'rgba(255,255,255,0.03)' : 'transparent',
      borderLeft: `2px solid ${isErr ? '#f8717150' : isHeader ? '#334155' : 'transparent'}`,
      animation: 'fade-in 0.15s ease',
    }}>
      <span style={{ color: '#334155', fontSize: 10, minWidth: 24, flexShrink: 0, userSelect: 'none', fontFamily: 'JetBrains Mono, monospace' }}>
        {String(index + 1).padStart(3, '0')}
      </span>
      <span style={{ color: '#475569', fontSize: 10, minWidth: 76, flexShrink: 0, fontFamily: 'JetBrains Mono, monospace' }}>
        {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
      </span>
      <span style={{ color: '#60a5fa', flexShrink: 0, fontFamily: 'JetBrains Mono, monospace' }}>$</span>
      <span style={{ color, wordBreak: 'break-word', whiteSpace: 'pre-wrap', flex: 1, fontFamily: 'JetBrains Mono, monospace', fontSize: 12, lineHeight: 1.7 }}>
        {log.message}
      </span>
    </div>
  );
}

function BtnSpinner({ color = '#fff' }) {
  return <span style={{ display: 'inline-block', width: 11, height: 11, border: `2px solid ${color}40`, borderTopColor: color, borderRadius: '50%', animation: 'spin 0.7s linear infinite', marginRight: 5, flexShrink: 0 }} />;
}

// ── Styles ────────────────────────────────────────────────────────────────────
const s = {
  shell:       { minHeight: '100vh', display: 'flex', flexDirection: 'column', background: '#f1f5f9' },

  header:      { background: '#fff', borderBottom: '1px solid #e2e8f0', padding: '12px 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 20, boxShadow: '0 1px 4px rgba(15,23,42,0.06)' },
  headerLeft:  { display: 'flex', alignItems: 'center', gap: 10 },
  headerLogo:  { width: 36, height: 36, background: '#eff6ff', border: '1px solid #bfdbfe', borderRadius: 9, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#2563eb' },
  headerTitle: { fontSize: 15, fontWeight: 700, color: '#0f172a' },
  headerSub:   { fontSize: 11, color: '#94a3b8' },
  headerRight: { display: 'flex', alignItems: 'center', gap: 10 },
  userChip:       { display: 'flex', alignItems: 'center', gap: 7, background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: 20, padding: '5px 14px', fontSize: 13, color: '#374151' },
  onlineDot:      { width: 7, height: 7, borderRadius: '50%', background: '#10b981', flexShrink: 0 },
  roleBadge:      { fontSize: 10, fontWeight: 700, borderRadius: 20, padding: '1px 7px', letterSpacing: '0.04em', textTransform: 'uppercase' },
  roleBadgeAdmin: { background: '#eff6ff', color: '#2563eb', border: '1px solid #bfdbfe' },
  roleBadgeViewer:{ background: '#f1f5f9', color: '#64748b', border: '1px solid #cbd5e1' },
  exportBtn:      { display: 'flex', alignItems: 'center', gap: 6, background: 'linear-gradient(135deg, #0f172a, #1e293b)', border: 'none', borderRadius: 8, padding: '6px 14px', color: '#fff', fontSize: 12, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit', boxShadow: '0 1px 4px rgba(15,23,42,0.2)' },
  logoutBtn:      { background: 'transparent', border: '1px solid #e2e8f0', borderRadius: 8, padding: '5px 14px', color: '#dc2626', fontSize: 13, cursor: 'pointer', fontFamily: 'inherit' },

  main:        { flex: 1, padding: '20px 24px', maxWidth: 1440, margin: '0 auto', width: '100%', display: 'flex', flexDirection: 'column', gap: 18 },

  summaryRow:  { display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 12 },
  summaryCard: { border: '1px solid', borderRadius: 12, padding: '14px 18px', display: 'flex', flexDirection: 'column', gap: 2 },
  summaryValue:{ fontSize: 26, fontWeight: 700, lineHeight: 1.1 },
  summaryLabel:{ fontSize: 11, fontWeight: 500, opacity: 0.75 },

  controlBar:  { display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: '#fff', border: '1px solid #e2e8f0', borderRadius: 10, padding: '10px 16px' },
  controlLeft: { display: 'flex', alignItems: 'baseline', gap: 10 },
  controlTitle:{ fontSize: 14, fontWeight: 600, color: '#0f172a' },
  controlHint: { fontSize: 12, color: '#94a3b8' },
  autoRunErr:  { fontSize: 12, color: '#dc2626' },
  runAllBtn:   { display: 'flex', alignItems: 'center', gap: 6, background: 'linear-gradient(135deg, #2563eb, #3b82f6)', border: 'none', borderRadius: 8, padding: '8px 18px', color: '#fff', fontSize: 13, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit', boxShadow: '0 2px 8px rgba(37,99,235,0.3)' },
  stopBtn:     { display: 'flex', alignItems: 'center', gap: 6, background: 'linear-gradient(135deg, #dc2626, #ef4444)', border: 'none', borderRadius: 8, padding: '8px 18px', color: '#fff', fontSize: 13, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit', boxShadow: '0 2px 8px rgba(220,38,38,0.3)' },

  autoRunBanner: { background: '#fffbeb', border: '1px solid #fde68a', borderRadius: 10, padding: '14px 18px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 20 },
  autoRunLeft:   { display: 'flex', alignItems: 'center', gap: 12 },
  autoRunTitle:  { fontSize: 13, color: '#92400e', fontWeight: 500 },
  autoRunSub:    { fontSize: 11, color: '#b45309', marginTop: 2 },
  progressWrap:  { display: 'flex', alignItems: 'center', gap: 8, minWidth: 180, flexShrink: 0 },
  progressTrack: { flex: 1, height: 6, background: '#fde68a', borderRadius: 3, overflow: 'hidden' },
  progressFill:  { height: '100%', background: 'linear-gradient(90deg, #d97706, #f59e0b)', borderRadius: 3, transition: 'width 0.5s ease' },
  progressLabel: { fontSize: 12, fontWeight: 600, color: '#92400e', minWidth: 32, textAlign: 'right' },

  jobsGrid:    { display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 12 },

  jobCard:     { background: '#fff', border: '1.5px solid', borderRadius: 12, padding: '14px', display: 'flex', flexDirection: 'column', gap: 10, transition: 'border-color 0.15s, box-shadow 0.15s' },
  cardTop:     { display: 'flex', alignItems: 'flex-start', gap: 10 },
  cardIcon:    { width: 34, height: 34, borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  cardName:    { fontSize: 12, fontWeight: 600, color: '#0f172a', lineHeight: 1.3, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' },
  rerunnablePill: { fontSize: 11, background: '#eff6ff', color: '#2563eb', border: '1px solid #bfdbfe', borderRadius: 20, padding: '2px 7px', flexShrink: 0, fontWeight: 600 },

  cardMetrics: { display: 'flex', alignItems: 'center', background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: 8, padding: '8px 10px', gap: 0 },
  metricDiv:   { width: 1, alignSelf: 'stretch', background: '#e2e8f0', margin: '0 10px' },
  metricLabel: { fontSize: 9, fontWeight: 600, color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.06em' },
  metricValue: { fontSize: 13, fontWeight: 600, color: '#0f172a', marginTop: 1 },

  cardError:      { background: '#fef2f2', border: '1px solid #fecaca', borderRadius: 6, padding: '6px 10px', color: '#dc2626', fontSize: 11 },
  cardActions:    { marginTop: 'auto' },
  viewerStatusRow:{ display: 'flex', alignItems: 'center', gap: 5, justifyContent: 'center', background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: 7, padding: '7px 10px', minHeight: 33 },

  runBtn:        { display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4, background: 'linear-gradient(135deg, #2563eb, #3b82f6)', border: 'none', borderRadius: 7, padding: '7px 10px', color: '#fff', fontSize: 11, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit', transition: 'opacity 0.15s', boxShadow: '0 1px 4px rgba(37,99,235,0.2)' },
  runBtnRunning: { background: 'linear-gradient(135deg, #d97706, #f59e0b)', boxShadow: '0 1px 4px rgba(217,119,6,0.2)' },
  runBtnDone:    { background: 'linear-gradient(135deg, #059669, #10b981)', boxShadow: '0 1px 4px rgba(5,150,105,0.2)' },
  runBtnRerun:   { background: 'linear-gradient(135deg, #7c3aed, #8b5cf6)', boxShadow: '0 1px 4px rgba(124,58,237,0.2)' },
  runBtnFailed:  { background: 'linear-gradient(135deg, #dc2626, #ef4444)', boxShadow: '0 1px 4px rgba(220,38,38,0.2)' },

  consoleSectionHeader: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10, flexWrap: 'wrap', gap: 8 },
  sectionTitle:  { fontSize: 13, fontWeight: 600, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.06em' },
  consoleTab:    { display: 'flex', alignItems: 'center', gap: 5, border: '1px solid', borderRadius: 6, padding: '3px 10px', fontSize: 11, fontWeight: 500, cursor: 'pointer', fontFamily: 'inherit', transition: 'all 0.15s' },

  console:       { background: '#0f172a', border: '1px solid #1e293b', borderRadius: 12, overflow: 'hidden' },
  consoleBar:    { background: '#1e293b', borderBottom: '1px solid #334155', padding: '9px 14px', display: 'flex', alignItems: 'center', gap: 10 },
  macDots:       { display: 'flex', gap: 5, flexShrink: 0 },
  macDot:        { width: 11, height: 11, borderRadius: '50%', display: 'inline-block' },
  consoleBarTitle: { flex: 1, textAlign: 'center', fontSize: 11, color: '#475569', fontFamily: 'JetBrains Mono, monospace' },
  liveChip:      { display: 'flex', alignItems: 'center', gap: 5, background: '#451a03', border: '1px solid #78350f', borderRadius: 5, padding: '2px 7px', fontSize: 9, fontWeight: 700, color: '#fbbf24', letterSpacing: '0.06em' },
  lineCount:     { fontSize: 10, color: '#334155', fontFamily: 'JetBrains Mono, monospace' },
  consoleBody:   { padding: '10px 0', height: 340, overflowY: 'auto', display: 'flex', flexDirection: 'column' },
};
