import { useState } from 'react';

export default function Login({ onLogin }) {
  const [form, setForm] = useState({ username: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = e => setForm(f => ({ ...f, [e.target.name]: e.target.value }));

  const handleSubmit = async e => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const res = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Login failed');
      onLogin(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={s.page}>
      <div style={s.card}>
        {/* Logo */}
        <div style={s.logoArea}>
          <div style={s.logoBox}>
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
              <rect x="2" y="3" width="20" height="14" rx="2" stroke="#2563eb" strokeWidth="2"/>
              <path d="M8 21h8M12 17v4" stroke="#2563eb" strokeWidth="2" strokeLinecap="round"/>
              <path d="M6 8h4M6 11h8" stroke="#2563eb" strokeWidth="2" strokeLinecap="round"/>
              <circle cx="17" cy="9" r="2" fill="#2563eb"/>
            </svg>
          </div>
          <h1 style={s.title}>Admin Console</h1>
          <p style={s.subtitle}>Script Execution &amp; Monitoring</p>
        </div>

        <form onSubmit={handleSubmit} style={s.form}>
          {error && (
            <div style={s.errorBox}>
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" style={{ flexShrink: 0 }}>
                <circle cx="12" cy="12" r="10" stroke="#dc2626" strokeWidth="2"/>
                <line x1="12" y1="8" x2="12" y2="12" stroke="#dc2626" strokeWidth="2" strokeLinecap="round"/>
                <circle cx="12" cy="16" r="1" fill="#dc2626"/>
              </svg>
              {error}
            </div>
          )}

          <div style={s.field}>
            <label style={s.label} htmlFor="username">Username</label>
            <input
              id="username" name="username" type="text" autoComplete="username"
              value={form.username} onChange={handleChange}
              placeholder="admin" required style={s.input}
            />
          </div>

          <div style={s.field}>
            <label style={s.label} htmlFor="password">Password</label>
            <input
              id="password" name="password" type="password" autoComplete="current-password"
              value={form.password} onChange={handleChange}
              placeholder="••••••••" required style={s.input}
            />
          </div>

          <button type="submit" disabled={loading} style={{ ...s.btn, opacity: loading ? 0.7 : 1 }}>
            {loading ? <><Spinner />Signing in...</> : 'Sign In'}
          </button>
        </form>

        <div style={s.hintBox}>
          <div style={s.hintRow}>
            <span style={{ ...s.hintBadge, background: '#eff6ff', color: '#2563eb', border: '1px solid #bfdbfe' }}>admin</span>
            <code style={s.code}>admin</code> / <code style={s.code}>admin123</code>
          </div>
          <div style={s.hintRow}>
            <span style={{ ...s.hintBadge, background: '#f1f5f9', color: '#64748b', border: '1px solid #cbd5e1' }}>viewer</span>
            <code style={s.code}>viewer</code> / <code style={s.code}>viewer123</code>
          </div>
        </div>
      </div>
    </div>
  );
}

function Spinner() {
  return <span style={{
    display: 'inline-block', width: 14, height: 14,
    border: '2px solid #fff', borderTopColor: 'transparent',
    borderRadius: '50%', animation: 'spin 0.7s linear infinite',
    marginRight: 8, verticalAlign: 'middle',
  }} />;
}

const s = {
  page: {
    minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center',
    background: 'linear-gradient(135deg, #eff6ff 0%, #f1f5f9 50%, #f0fdf4 100%)',
    padding: 20,
  },
  card: {
    background: '#ffffff', border: '1px solid #e2e8f0',
    borderRadius: 20, padding: '44px 40px 36px',
    width: '100%', maxWidth: 420,
    boxShadow: '0 20px 60px rgba(15,23,42,0.08), 0 4px 16px rgba(15,23,42,0.04)',
    animation: 'fade-in 0.3s ease',
  },
  logoArea: { textAlign: 'center', marginBottom: 32 },
  logoBox: {
    width: 60, height: 60,
    background: '#eff6ff', border: '1px solid #bfdbfe',
    borderRadius: 14, display: 'inline-flex',
    alignItems: 'center', justifyContent: 'center', marginBottom: 16,
  },
  title: { fontSize: 24, fontWeight: 700, color: '#0f172a', marginBottom: 4 },
  subtitle: { fontSize: 13, color: '#64748b' },
  form: { display: 'flex', flexDirection: 'column', gap: 16 },
  errorBox: {
    display: 'flex', alignItems: 'center', gap: 10,
    background: '#fef2f2', border: '1px solid #fecaca',
    borderRadius: 10, padding: '10px 14px',
    color: '#dc2626', fontSize: 13, lineHeight: 1.5,
  },
  field: { display: 'flex', flexDirection: 'column', gap: 5 },
  label: { fontSize: 13, fontWeight: 500, color: '#374151' },
  input: {
    background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: 10,
    padding: '11px 14px', color: '#0f172a', fontSize: 14,
    outline: 'none', fontFamily: 'inherit',
    transition: 'border-color 0.15s, box-shadow 0.15s',
  },
  btn: {
    marginTop: 6,
    background: 'linear-gradient(135deg, #2563eb, #3b82f6)',
    border: 'none', borderRadius: 10, padding: '13px 0',
    color: '#fff', fontSize: 14, fontWeight: 600,
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    cursor: 'pointer', fontFamily: 'inherit',
    boxShadow: '0 4px 14px rgba(37,99,235,0.3)',
    transition: 'opacity 0.2s',
  },
  hintBox: { marginTop: 20, display: 'flex', flexDirection: 'column', gap: 6, background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: 10, padding: '12px 16px' },
  hintRow: { display: 'flex', alignItems: 'center', gap: 8, fontSize: 12, color: '#64748b' },
  hintBadge: { fontSize: 10, fontWeight: 700, borderRadius: 20, padding: '1px 7px', letterSpacing: '0.04em', textTransform: 'uppercase', flexShrink: 0 },
  code: {
    background: '#f1f5f9', borderRadius: 4, padding: '1px 6px',
    fontFamily: 'JetBrains Mono, monospace', color: '#0f172a', fontSize: 11,
  },
};
